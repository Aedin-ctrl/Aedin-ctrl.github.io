// Windows implementation of SetupChecker.h. Same checklist as macOS minus
// BlackHole (Windows records system audio natively) and Screen Recording
// (no such permission on Windows); those checks always report satisfied.

#include "SetupChecker.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <audioclient.h>
#include <mmdeviceapi.h>

#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>

#include <nlohmann/json.hpp>

#include "net/Http.h"
#include "platform/win/WinUtil.h"

namespace {

constexpr const char* kOllamaModels[] = {"qwen3.5:4b"};  // must match LocalLLMClient/VisionLLMClient
constexpr size_t kOllamaModelCount = sizeof(kOllamaModels) / sizeof(kOllamaModels[0]);
constexpr const char* kThinkHarderModel = "qwen3.5:9b";  // must match LocalLLMClient
constexpr const char* kOllamaApi = "http://127.0.0.1:11434";
constexpr const char* kWhisperModelUrl =
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin";

std::string ModelDir() {
    return WinUtil::AppDataSubdir("models");
}

// ---- microphone ------------------------------------------------------------

// "Deny" in any of the three privacy switches blocks desktop apps: the
// device-wide one (HKLM), "Let apps access your microphone" (HKCU) and
// "Let desktop apps access your microphone" (HKCU ...\NonPackaged).
bool RegistryDenies(HKEY root, const wchar_t* subkey) {
    wchar_t value[16] = {};
    DWORD size = sizeof(value);
    if (RegGetValueW(root, subkey, L"Value", RRF_RT_REG_SZ, nullptr, value, &size) != ERROR_SUCCESS) return false;
    return _wcsicmp(value, L"Deny") == 0;
}

bool MicBlockedByPrivacySettings() {
    const wchar_t* base = L"Software\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\microphone";
    const std::wstring nonPackaged = std::wstring(base) + L"\\NonPackaged";
    return RegistryDenies(HKEY_LOCAL_MACHINE, base) || RegistryDenies(HKEY_CURRENT_USER, base) ||
           RegistryDenies(HKEY_CURRENT_USER, nonPackaged.c_str());
}

enum class MicProbe { NotRun, Ok, Denied, NoDevice };
std::atomic<MicProbe> g_micProbe{MicProbe::NotRun};
std::chrono::steady_clock::time_point g_lastMicProbe{};

// Opens (and immediately closes) a shared-mode stream on the default mic.
// Run on the UI thread: newer Windows 11 builds show their per-app
// microphone prompt only for access that starts there.
MicProbe ProbeMicrophone() {
    const HRESULT coInit = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    MicProbe result = MicProbe::NoDevice;
    IMMDeviceEnumerator* enumerator = nullptr;
    IMMDevice* device = nullptr;
    IAudioClient* client = nullptr;
    WAVEFORMATEX* format = nullptr;
    if (SUCCEEDED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator),
                                   reinterpret_cast<void**>(&enumerator))) &&
        SUCCEEDED(enumerator->GetDefaultAudioEndpoint(eCapture, eConsole, &device))) {
        HRESULT hr = device->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(&client));
        if (SUCCEEDED(hr)) hr = client->GetMixFormat(&format);
        if (SUCCEEDED(hr)) hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 10000000, 0, format, nullptr);
        result = SUCCEEDED(hr) ? MicProbe::Ok : (hr == E_ACCESSDENIED ? MicProbe::Denied : MicProbe::NoDevice);
    }
    if (format) CoTaskMemFree(format);
    if (client) client->Release();
    if (device) device->Release();
    if (enumerator) enumerator->Release();
    if (SUCCEEDED(coInit)) CoUninitialize();
    static MicProbe lastLogged = MicProbe::NotRun;  // log changes only (this runs every few seconds)
    if (result != lastLogged) {
        lastLogged = result;
        WinUtil::Log("Microphone check: %s", result == MicProbe::Ok       ? "ok"
                                             : result == MicProbe::Denied ? "blocked by privacy settings"
                                                                          : "no microphone found");
    }
    return result;
}

// ---- whisper download --------------------------------------------------------

std::atomic<bool> g_whisperDownloading{false};
std::atomic<bool> g_whisperFailed{false};
std::atomic<float> g_whisperProgress{0.0f};

// ---- Ollama --------------------------------------------------------------------

std::atomic<bool> g_ollamaReachable{false};
std::atomic<bool> g_ollamaModelsReady{false};
std::atomic<bool> g_thinkHarderPresent{false};
std::atomic<bool> g_ollamaCheckInFlight{false};
std::atomic<bool> g_ollamaDownloading{false};
std::atomic<bool> g_ollamaDownloadFailed{false};
std::atomic<float> g_ollamaProgress{0.0f};
std::atomic<bool> g_thinkHarderDownloading{false};
std::atomic<bool> g_thinkHarderFailed{false};
std::mutex g_checkMutex;
std::chrono::steady_clock::time_point g_lastOllamaCheck{};

void CheckOllamaStatusBlocking() {
    const Http::Result r = Http::get(std::string(kOllamaApi) + "/api/tags", 2);
    if (!r.ok || r.status != 200) {
        g_ollamaReachable = false;
        g_ollamaModelsReady = false;
        g_thinkHarderPresent = false;
        return;
    }
    g_ollamaReachable = true;
    bool all = false;
    bool thinkHarder = false;
    try {
        const nlohmann::json j = nlohmann::json::parse(r.body);
        all = true;
        for (const char* wanted : kOllamaModels) {
            bool found = false;
            for (const auto& m : j.value("models", nlohmann::json::array())) {
                if (m.value("name", "") == wanted) found = true;
            }
            if (!found) all = false;
        }
        for (const auto& m : j.value("models", nlohmann::json::array())) {
            if (m.value("name", "") == kThinkHarderModel) thinkHarder = true;
        }
    } catch (const nlohmann::json::exception&) {
        all = false;
    }
    g_ollamaModelsReady = all;
    g_thinkHarderPresent = thinkHarder;
}

// Keeps per-frame polling cheap: at most one check every 2s, one at a time,
// on a background thread; callers read the cached atomics.
void RefreshOllamaStatusIfStale() {
    {
        std::lock_guard<std::mutex> lock(g_checkMutex);
        const auto now = std::chrono::steady_clock::now();
        if (now - g_lastOllamaCheck < std::chrono::seconds(2)) return;
        g_lastOllamaCheck = now;
    }
    bool expected = false;
    if (!g_ollamaCheckInFlight.compare_exchange_strong(expected, true)) return;
    std::thread([] {
        CheckOllamaStatusBlocking();
        g_ollamaCheckInFlight = false;
    }).detach();
}

void ForceOllamaRecheck() {
    std::lock_guard<std::mutex> lock(g_checkMutex);
    g_lastOllamaCheck = {};
}

std::string OllamaInstallDir() {
    return WinUtil::LocalAppDataDir() + "\\Programs\\Ollama";
}

// Pulls one model through Ollama's HTTP API (no console window), reporting
// byte progress from the streamed status lines. Returns false on failure.
bool PullModel(const std::string& model, std::atomic<float>* progress) {
    bool sawSuccess = false;
    bool sawError = false;
    const nlohmann::json body = {{"model", model}, {"stream", true}};
    const Http::Result r =
        Http::postStreamingLines(std::string(kOllamaApi) + "/api/pull", body.dump(), [&](const std::string& line) {
            try {
                const nlohmann::json j = nlohmann::json::parse(line);
                if (j.contains("error")) sawError = true;
                if (j.value("status", "") == "success") sawSuccess = true;
                const double total = j.value("total", 0.0);
                const double completed = j.value("completed", 0.0);
                if (progress && total > 0) progress->store(static_cast<float>(completed / total));
            } catch (const nlohmann::json::exception&) {
            }
        });
    const bool ok = r.ok && r.status == 200 && sawSuccess && !sawError;
    WinUtil::Log("ollama pull %s: %s (http %ld %s)", model.c_str(), ok ? "ok" : "FAILED", r.status, r.error.c_str());
    return ok;
}

}  // namespace

namespace SetupChecker {

std::string whisperModelPath() {
    const std::string dir = ModelDir();
    const std::string turbo = dir + "\\ggml-large-v3-turbo-q5_0.bin";
    const std::string base = dir + "\\ggml-base.en.bin";
    if (WinUtil::FileExists(turbo) || !WinUtil::FileExists(base)) return turbo;
    return base;
}

MicPermission microphonePermissionStatus() {
    if (MicBlockedByPrivacySettings()) return MicPermission::Denied;
    // Re-probe every few seconds until it works (e.g. right after the user
    // flips the switch in Settings or plugs in a mic); once OK it stays OK.
    const auto now = std::chrono::steady_clock::now();
    MicProbe probe = g_micProbe.load();
    if (probe != MicProbe::Ok && now - g_lastMicProbe > std::chrono::seconds(3)) {
        g_lastMicProbe = now;
        probe = ProbeMicrophone();
        g_micProbe = probe;
    }
    switch (probe) {
        case MicProbe::Ok:
            return MicPermission::Authorized;
        case MicProbe::Denied:
            return MicPermission::Denied;
        case MicProbe::NoDevice:
            return MicPermission::Restricted;  // no microphone found
        case MicProbe::NotRun:
        default:
            return MicPermission::NotDetermined;
    }
}

void requestMicrophoneAccess() {
    g_micProbe = ProbeMicrophone();
    g_lastMicProbe = std::chrono::steady_clock::now();
}

void openSystemMicrophoneSettings() {
    WinUtil::OpenUrl("ms-settings:privacy-microphone");
}

bool isMicrophoneMissing() {
    return microphonePermissionStatus() == MicPermission::Restricted;  // probe found no capture device
}

void openSoundSettings() {
    WinUtil::OpenUrl("ms-settings:sound");
}

// Not needed on Windows (see needsAudioDriver()).
bool isBlackHoleInstalled() { return true; }
void openBlackHoleDownloadPage() {}
void installBlackHoleAsync() {}
bool isBlackHoleInstallerDownloading() { return false; }

bool isWhisperModelDownloaded() {
    return WinUtil::FileExists(whisperModelPath());
}

bool isWhisperModelDownloading() {
    return g_whisperDownloading.load();
}

float whisperModelDownloadProgress() {
    return g_whisperProgress.load();
}

bool didWhisperModelDownloadFail() {
    return g_whisperFailed.load();
}

void downloadWhisperModelAsync() {
    if (isWhisperModelDownloaded()) return;
    bool expected = false;
    if (!g_whisperDownloading.compare_exchange_strong(expected, true)) return;
    g_whisperFailed = false;
    g_whisperProgress = 0.0f;
    const std::string dest = ModelDir() + "\\ggml-large-v3-turbo-q5_0.bin";
    std::thread([dest] {
        std::string error;
        const bool ok = Http::downloadToFile(kWhisperModelUrl, dest, &g_whisperProgress, &error);
        WinUtil::Log("Speech model download: %s %s", ok ? "ok" : "FAILED", error.c_str());
        g_whisperFailed = !ok;
        g_whisperDownloading = false;
    }).detach();
}

// Not needed on Windows (see needsScreenRecordingPermission()).
bool hasScreenRecordingPermission() { return true; }
bool isScreenCaptureConfirmed() { return true; }
bool isScreenCaptureTestRunning() { return false; }
bool didScreenCaptureTestFail() { return false; }
void testScreenCaptureAsync() {}
void noteScreenCaptureSucceeded() {}
void noteScreenCaptureFailed() {}
bool hasRequestedScreenRecordingAccessBefore() { return true; }
void requestScreenRecordingAccess() {}
void openSystemScreenRecordingSettings() {}

bool isOllamaReachable() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load();
}

bool isOllamaInstalled() {
    return WinUtil::FileExists(OllamaInstallDir() + "\\ollama.exe") ||
           WinUtil::FileExists(OllamaInstallDir() + "\\ollama app.exe");
}

bool startOllamaIfInstalled() {
    CheckOllamaStatusBlocking();
    if (g_ollamaReachable.load()) return true;
    if (!isOllamaInstalled()) return false;
    const std::string trayApp = OllamaInstallDir() + "\\ollama app.exe";
    if (WinUtil::FileExists(trayApp)) {
        // The tray app runs the server and keeps it running. This marker
        // (what Ollama's own installer script uses) makes it start hidden
        // instead of popping its window up over the lecture.
        const std::string markerDir = WinUtil::LocalAppDataDir() + "\\Ollama";
        WinUtil::CreateDirectories(markerDir);
        if (FILE* f = _wfopen(WinUtil::Widen(markerDir + "\\upgraded").c_str(), L"wb")) std::fclose(f);
        WinUtil::Launch(trayApp, {}, /*hidden=*/false);
    } else {
        WinUtil::Launch(OllamaInstallDir() + "\\ollama.exe", {"serve"}, /*hidden=*/true);
    }
    WinUtil::Log("Starting Ollama");
    for (int i = 0; i < 20; ++i) {  // up to ~10s for the server to come up
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        CheckOllamaStatusBlocking();
        if (g_ollamaReachable.load()) return true;
    }
    WinUtil::Log("Ollama didn't start within 10s");
    return false;
}

bool checkOllamaModelsReadyNow() {
    startOllamaIfInstalled();
    return g_ollamaModelsReady.load();
}

bool areOllamaModelsReady() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load() && g_ollamaModelsReady.load();
}

bool isOllamaModelDownloading() {
    return g_ollamaDownloading.load();
}

float ollamaModelDownloadProgress() {
    return g_ollamaProgress.load();
}

bool didOllamaModelDownloadFail() {
    return g_ollamaDownloadFailed.load();
}

void downloadOllamaModelsAsync() {
    if (areOllamaModelsReady()) return;
    bool expected = false;
    if (!g_ollamaDownloading.compare_exchange_strong(expected, true)) return;
    g_ollamaDownloadFailed = false;
    g_ollamaProgress = 0.0f;
    std::thread([] {
        bool ok = true;
        for (const char* model : kOllamaModels) {
            if (!PullModel(model, &g_ollamaProgress)) {
                ok = false;
                break;
            }
        }
        g_ollamaDownloadFailed = !ok;
        g_ollamaDownloading = false;
        ForceOllamaRecheck();
    }).detach();
}

void openOllamaDownloadPage() {
    WinUtil::OpenUrl("https://ollama.com/download/windows");
}

bool isThinkHarderModelReady() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load() && g_thinkHarderPresent.load();
}

bool isThinkHarderModelDownloading() {
    return g_thinkHarderDownloading.load();
}

bool didThinkHarderModelDownloadFail() {
    return g_thinkHarderFailed.load();
}

void downloadThinkHarderModelAsync() {
    if (isThinkHarderModelReady()) return;
    bool expected = false;
    if (!g_thinkHarderDownloading.compare_exchange_strong(expected, true)) return;
    g_thinkHarderFailed = false;
    std::thread([] {
        const bool ok = PullModel(kThinkHarderModel, nullptr);
        g_thinkHarderFailed = !ok;
        g_thinkHarderDownloading = false;
        ForceOllamaRecheck();
    }).detach();
}

}  // namespace SetupChecker
