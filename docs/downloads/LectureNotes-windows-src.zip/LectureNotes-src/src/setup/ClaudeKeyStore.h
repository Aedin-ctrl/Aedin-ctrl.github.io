#pragma once

#include <string>

// Stores the user's own Anthropic API key in the macOS Keychain (not a
// plaintext file) -- used by ClaudeClient when the user opts into
// "smarter" answers (Setup's optional Claude backend) instead of the
// always-local, always-free default. Plain C++ header so any translation
// unit can call it without pulling in Security.framework directly; the
// actual Keychain calls live in ClaudeKeyStore.mm.
namespace ClaudeKeyStore {

bool hasKey();

// Overwrites any existing stored key.
void setKey(const std::string& apiKey);

void clearKey();

// Returns the stored key, or empty if none is set. Only ClaudeClient
// should need this -- Setup UI should show hasKey() as a checkmark/status,
// never redisplay the actual key value.
std::string key();

}  // namespace ClaudeKeyStore
