#import <AVFoundation/AVFoundation.h>
#import <AppKit/AppKit.h>
#import <CoreGraphics/CoreGraphics.h>
#include <CommonCrypto/CommonDigest.h>

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <sys/stat.h>
#include <unistd.h>

#include "SetupChecker.h"

#include "capture/ScreenCapture.h"

namespace {

bool FileExists(const std::string& path) {
    struct stat st {};
    return ::stat(path.c_str(), &st) == 0;
}

std::string ApplicationSupportModelDir() {
    const char* home = getenv("HOME");
    std::string base = home ? std::string(home) : std::string();
    return base + "/Library/Application Support/LectureNotes/models";
}

// NSURLSessionDownloadTask isn't default-constructible/copyable into a
// plain C++ global cleanly, so it's held as an untyped strong reference;
// the download-progress readers below cast it back when non-null.
NSURLSessionDownloadTask* g_downloadTask = nil;
std::atomic<bool> g_downloadFailed{false};

// Must match LocalLLMClient.cpp's kModelName and VisionLLMClient.cpp's
// kVisionModelName exactly -- these are the two models the app actually
// calls Ollama for (Q&A and camera/vision respectively).
// One model covers both Q&A and the camera: Qwen3.5 is natively multimodal,
// so it replaced the llama3.2:3b + qwen2.5vl:3b pair (5.2GB -> 3.4GB).
constexpr const char* kOllamaModels[] = {"qwen3.5:4b"};
constexpr size_t kOllamaModelCount = sizeof(kOllamaModels) / sizeof(kOllamaModels[0]);

// Must match LocalLLMClient.cpp's kThinkHarderModelName exactly. Optional
// -- not required to use the app, only to use the "think harder" retry
// button without a Claude API key configured.
constexpr const char* kThinkHarderModel = "qwen3.5:9b";

std::atomic<bool> g_ollamaReachable{false};
std::atomic<bool> g_ollamaModelsReady{false};
std::atomic<bool> g_thinkHarderModelPresent{false};
std::atomic<bool> g_ollamaCheckInFlight{false};
std::atomic<bool> g_ollamaDownloading{false};
std::atomic<bool> g_ollamaDownloadFailed{false};
std::atomic<int> g_ollamaModelsDownloaded{0};
std::atomic<bool> g_thinkHarderDownloading{false};
std::atomic<bool> g_thinkHarderDownloadFailed{false};
std::chrono::steady_clock::time_point g_lastOllamaCheck{};

// Ollama's own CLI, not just whatever's on $PATH -- a GUI app launched
// via Finder/`open` doesn't inherit a login shell's PATH, so Homebrew's
// /opt/homebrew/bin (Apple Silicon) or /usr/local/bin (Intel) often isn't
// visible even though a Terminal-launched `ollama` works fine. Falls back
// to the bare name in case it genuinely is on this process's PATH.
std::string OllamaBinaryPath() {
    if (FileExists("/opt/homebrew/bin/ollama")) return "/opt/homebrew/bin/ollama";
    if (FileExists("/usr/local/bin/ollama")) return "/usr/local/bin/ollama";
    return "ollama";
}

// One /api/tags round trip (at most ~2s), updating g_ollamaReachable /
// g_ollamaModelsReady / g_thinkHarderModelPresent. Shared by the throttled
// background refresh and the synchronous startup check.
void CheckOllamaStatusBlocking() {
      NSURL* url = [NSURL URLWithString:@"http://localhost:11434/api/tags"];
      NSMutableURLRequest* req = [NSMutableURLRequest requestWithURL:url];
      req.timeoutInterval = 1.5;
      NSURLSessionConfiguration* config = [NSURLSessionConfiguration ephemeralSessionConfiguration];
      NSURLSession* session = [NSURLSession sessionWithConfiguration:config];

      dispatch_semaphore_t sem = dispatch_semaphore_create(0);
      __block NSData* resultData = nil;
      NSURLSessionDataTask* task =
          [session dataTaskWithRequest:req
                      completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                        (void)response;
                        (void)error;
                        resultData = data;
                        dispatch_semaphore_signal(sem);
                      }];
      [task resume];
      dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)));

      if (resultData == nil) {
          g_ollamaReachable = false;
          g_ollamaModelsReady = false;
          g_thinkHarderModelPresent = false;
          return;
      }
      g_ollamaReachable = true;

      id parsed = [NSJSONSerialization JSONObjectWithData:resultData options:0 error:nil];
      bool allPresent = false;
      bool thinkHarderPresent = false;
      if ([parsed isKindOfClass:[NSDictionary class]]) {
          NSArray* models = ((NSDictionary*)parsed)[@"models"];
          NSMutableSet<NSString*>* names = [NSMutableSet set];
          for (NSDictionary* m in models) {
              NSString* name = m[@"name"];
              if (name) {
                  [names addObject:name];
              }
          }
          allPresent = true;
          for (size_t i = 0; i < kOllamaModelCount; ++i) {
              if (![names containsObject:[NSString stringWithUTF8String:kOllamaModels[i]]]) {
                  allPresent = false;
                  break;
              }
          }
          thinkHarderPresent = [names containsObject:[NSString stringWithUTF8String:kThinkHarderModel]];
      }
      g_ollamaModelsReady = allPresent;
      g_thinkHarderModelPresent = thinkHarderPresent;
    }

// Refreshes g_ollamaReachable/g_ollamaModelsReady on a background queue,
// throttled to at most once every 2s and never more than one in flight --
// keeps every-frame UI polling cheap (just reads cached atomics) instead
// of a network round trip per frame.
void RefreshOllamaStatusIfStale() {
    const auto now = std::chrono::steady_clock::now();
    if (now - g_lastOllamaCheck < std::chrono::seconds(2)) {
        return;
    }
    bool expected = false;
    if (!g_ollamaCheckInFlight.compare_exchange_strong(expected, true)) {
        return;
    }
    g_lastOllamaCheck = now;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
      CheckOllamaStatusBlocking();
      g_ollamaCheckInFlight = false;
    });
}

}  // namespace

namespace SetupChecker {

// large-v3-turbo (q5_0, 547MB) replaced base.en (142MB) as the default on
// 2026-09-28. On a real MIT 8.02 lecture excerpt, base.en heard "watt" as
// "volt" three times in four minutes ("1,000-volt light bulb"), a unit error
// that flows straight into the question sent to the model; turbo made none,
// and small.en silently dropped a whole sentence. All three ran at ~10x
// real time on an M2. Installs that already have base.en keep using it
// until turbo is downloaded.
std::string whisperModelPath() {
    const std::string dir = ApplicationSupportModelDir();
    const std::string turbo = dir + "/ggml-large-v3-turbo-q5_0.bin";
    const std::string base = dir + "/ggml-base.en.bin";
    if (FileExists(turbo) || !FileExists(base)) return turbo;
    return base;
}

MicPermission microphonePermissionStatus() {
    switch ([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio]) {
        case AVAuthorizationStatusAuthorized:
            return MicPermission::Authorized;
        case AVAuthorizationStatusDenied:
            return MicPermission::Denied;
        case AVAuthorizationStatusRestricted:
            return MicPermission::Restricted;
        case AVAuthorizationStatusNotDetermined:
        default:
            return MicPermission::NotDetermined;
    }
}

void requestMicrophoneAccess() {
    if ([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio] != AVAuthorizationStatusNotDetermined) {
        return;
    }
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL) {
      // Status is re-read fresh via microphonePermissionStatus() every UI
      // frame; nothing to do here.
    }];
}

bool isMicrophoneMissing() {
    return false;  // Macs have a built-in mic; a denied one is a permission issue
}

void openSoundSettings() {
    [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:@"x-apple.systempreferences:com.apple.Sound-Settings.extension"]];
}

void openSystemMicrophoneSettings() {
    NSURL* url = [NSURL URLWithString:@"x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone"];
    [[NSWorkspace sharedWorkspace] openURL:url];
}

namespace {
// Per-process, NOT persisted to disk: macOS ties TCC permission state to
// the app's signing identity, and it can also be reset from outside the app
// (tccutil, System Settings), so screen-recording authorization can
// genuinely go back to "not yet asked" between runs. (Builds are signed with
// a fixed certificate now -- see cmake/codesign.sh -- so rebuilds alone no
// longer cause this, but resets still can.) A persisted (NSUserDefaults)
// "already asked" flag would go stale across exactly that kind of reset
// and wrongly keep redirecting to System Settings instead of ever
// re-prompting for real. An in-memory flag naturally gets a clean slate
// every launch, which is what we actually want: ask at most once per
// *run* (so repeated clicks in one session don't re-spam the "already
// denied" system alert), while every fresh launch gets a genuine chance
// to prompt again if the OS-level state actually changed.
bool g_screenRecordingAskedThisRun = false;
}  // namespace

namespace {
NSString* const kScreenCaptureConfirmedKey = @"ScreenCaptureConfirmed";
std::atomic<bool> g_screenTestRunning{false};
std::atomic<bool> g_screenTestFailed{false};
}  // namespace

bool isScreenCaptureConfirmed() {
    return [[NSUserDefaults standardUserDefaults] boolForKey:kScreenCaptureConfirmedKey];
}

void noteScreenCaptureFailed() {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kScreenCaptureConfirmedKey];
}

void noteScreenCaptureSucceeded() {
    if (!isScreenCaptureConfirmed()) {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kScreenCaptureConfirmedKey];
    }
}

bool isScreenCaptureTestRunning() {
    return g_screenTestRunning.load();
}

bool didScreenCaptureTestFail() {
    return g_screenTestFailed.load();
}

void testScreenCaptureAsync() {
    bool expected = false;
    if (!g_screenTestRunning.compare_exchange_strong(expected, true)) return;
    g_screenTestFailed = false;
    // If the macOS prompt is ignored the capture may never call back; don't
    // leave the row stuck on "Waiting for macOS..." forever.
    static std::atomic<int> generation{0};
    const int myGeneration = ++generation;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      if (generation.load() == myGeneration && g_screenTestRunning.load()) {
          g_screenTestFailed = true;
          g_screenTestRunning = false;
      }
    });
    // A 40x40-point corner of the main screen: enough to exercise the same
    // ScreenCaptureKit path the camera feature uses (and so raise the same
    // prompt), without capturing anything meaningful.
    ScreenCapture::captureRegionAsPNG({0, 0, 40, 40}, 80, 80, [](std::vector<uint8_t> png) {
        const bool ok = !png.empty();
        dispatch_async(dispatch_get_main_queue(), ^{
          if (ok) [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kScreenCaptureConfirmedKey];
          g_screenTestFailed = !ok;
          g_screenTestRunning = false;
        });
    });
}

bool hasScreenRecordingPermission() {
    // CGPreflightScreenCaptureAccess (10.15+) reads the current TCC state
    // without ever prompting -- safe to poll every frame from the UI.
    return CGPreflightScreenCaptureAccess();
}

bool hasRequestedScreenRecordingAccessBefore() {
    return g_screenRecordingAskedThisRun;
}

void requestScreenRecordingAccess() {
    // Unlike requestMicrophoneAccess, this is NOT a true no-op once denied:
    // CGRequestScreenCaptureAccess re-shows a "you already denied this --
    // open System Settings" system alert on *every* call after a prior
    // denial, not just the first (confirmed in practice -- it was
    // reappearing on every camera-button click). CGPreflightScreenCaptureAccess
    // only exposes a granted/not-granted bool, with no NotDetermined/Denied
    // distinction the way AVCaptureDevice's mic API has, so there's no public
    // API to detect "already asked, was denied" within this same run --
    // track it ourselves instead, so the OS prompt fires at most once per
    // launch instead of nagging on every click.
    if (g_screenRecordingAskedThisRun) {
        return;
    }
    g_screenRecordingAskedThisRun = true;
    CGRequestScreenCaptureAccess();
}

void openSystemScreenRecordingSettings() {
    NSURL* url = [NSURL URLWithString:@"x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"];
    [[NSWorkspace sharedWorkspace] openURL:url];
}

bool isBlackHoleInstalled() {
    return FileExists("/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver");
}

namespace {
// Keep in sync with install-lecturenotes.sh (the Homebrew cask's pinned
// pkg; the developer publishes no GitHub release assets).
NSString* const kBlackHolePkgURL = @"https://existential.audio/downloads/BlackHole2ch-0.7.1.pkg";
NSString* const kBlackHolePkgSHA256 = @"57b540f27a3e29c37e310e01bee0fdfab76733087e47f997ef9dccf851400dcf";
std::atomic<bool> g_blackHoleDownloading{false};

NSString* Sha256Hex(NSData* data) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, static_cast<CC_LONG>(data.length), digest);
    NSMutableString* hex = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; ++i) [hex appendFormat:@"%02x", digest[i]];
    return hex;
}
}  // namespace

bool isBlackHoleInstallerDownloading() {
    return g_blackHoleDownloading.load();
}

void installBlackHoleAsync() {
    bool expected = false;
    if (!g_blackHoleDownloading.compare_exchange_strong(expected, true)) return;
    NSURLSessionDataTask* task = [[NSURLSession sharedSession]
          dataTaskWithURL:[NSURL URLWithString:kBlackHolePkgURL]
        completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
          (void)response;
          NSString* path = nil;
          if (!error && data && [Sha256Hex(data) isEqualToString:kBlackHolePkgSHA256]) {
              path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"BlackHole2ch.pkg"];
              if (![data writeToFile:path atomically:YES]) path = nil;
          }
          dispatch_async(dispatch_get_main_queue(), ^{
            g_blackHoleDownloading = false;
            if (path) {
                // Installer.app handles the admin password and the steps.
                [[NSWorkspace sharedWorkspace] openURL:[NSURL fileURLWithPath:path]];
            } else {
                openBlackHoleDownloadPage();  // checksum or network problem
            }
          });
        }];
    [task resume];
}

void openBlackHoleDownloadPage() {
    NSURL* url = [NSURL URLWithString:@"https://github.com/ExistentialAudio/BlackHole"];
    [[NSWorkspace sharedWorkspace] openURL:url];
}

bool isWhisperModelDownloaded() {
    return FileExists(whisperModelPath());
}

bool isWhisperModelDownloading() {
    return g_downloadTask != nil && g_downloadTask.state == NSURLSessionTaskStateRunning;
}

float whisperModelDownloadProgress() {
    if (!g_downloadTask) {
        return 0.0f;
    }
    return static_cast<float>(g_downloadTask.progress.fractionCompleted);
}

bool didWhisperModelDownloadFail() {
    return g_downloadFailed.load();
}

void downloadWhisperModelAsync() {
    if (isWhisperModelDownloading() || isWhisperModelDownloaded()) {
        return;
    }
    g_downloadFailed = false;

    NSString* dir = [NSString stringWithUTF8String:ApplicationSupportModelDir().c_str()];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir
                               withIntermediateDirectories:YES
                                                attributes:nil
                                                     error:nil];

    NSURL* remote = [NSURL
        URLWithString:@"https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin"];
    NSString* destPath = [NSString stringWithUTF8String:whisperModelPath().c_str()];

    g_downloadTask = [[NSURLSession sharedSession]
        downloadTaskWithURL:remote
          completionHandler:^(NSURL* location, NSURLResponse* response, NSError* error) {
            (void)response;
            if (error != nil || location == nil) {
                g_downloadFailed = true;
                return;
            }
            NSError* moveError = nil;
            [[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
            BOOL ok = [[NSFileManager defaultManager] moveItemAtURL:location
                                                                toURL:[NSURL fileURLWithPath:destPath]
                                                                error:&moveError];
            if (!ok) {
                g_downloadFailed = true;
            }
          }];
    [g_downloadTask resume];
}

bool isOllamaReachable() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load();
}

bool isOllamaInstalled() {
    return FileExists("/Applications/Ollama.app") || FileExists("/opt/homebrew/bin/ollama") ||
           FileExists("/usr/local/bin/ollama");
}

bool startOllamaIfInstalled() {
    CheckOllamaStatusBlocking();
    if (g_ollamaReachable.load()) return true;
    if (!isOllamaInstalled()) return false;
    if (FileExists("/Applications/Ollama.app")) {
        // The app runs the server and keeps it running (and normally adds
        // itself to login items).
        std::system("/usr/bin/open -g -a /Applications/Ollama.app");
    } else {
        // Command-line install (e.g. Homebrew): start the server detached,
        // so it keeps running after LectureNotes quits, like the app would.
        const std::string cmd = "/usr/bin/nohup \"" + OllamaBinaryPath() + "\" serve >/dev/null 2>&1 &";
        std::system(cmd.c_str());
    }
    for (int i = 0; i < 16; ++i) {  // up to ~8s for the server to come up
        usleep(500 * 1000);
        CheckOllamaStatusBlocking();
        if (g_ollamaReachable.load()) return true;
    }
    return false;
}

bool checkOllamaModelsReadyNow() {
    startOllamaIfInstalled();
    return g_ollamaModelsReady.load();
}

bool areOllamaModelsReady() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load() && g_ollamaModelsReady.load();
}

bool isOllamaModelDownloading() {
    return g_ollamaDownloading.load();
}

float ollamaModelDownloadProgress() {
    return static_cast<float>(g_ollamaModelsDownloaded.load()) / static_cast<float>(kOllamaModelCount);
}

bool didOllamaModelDownloadFail() {
    return g_ollamaDownloadFailed.load();
}

void downloadOllamaModelsAsync() {
    if (g_ollamaDownloading.load() || areOllamaModelsReady()) {
        return;
    }
    g_ollamaDownloading = true;
    g_ollamaDownloadFailed = false;
    g_ollamaModelsDownloaded = 0;

    const std::string binary = OllamaBinaryPath();
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
      bool ok = true;
      for (size_t i = 0; i < kOllamaModelCount; ++i) {
          const std::string cmd = "\"" + binary + "\" pull " + kOllamaModels[i] + " >/dev/null 2>&1";
          if (std::system(cmd.c_str()) != 0) {
              ok = false;
              break;
          }
          g_ollamaModelsDownloaded.fetch_add(1);
      }
      g_ollamaDownloadFailed = !ok;
      g_ollamaDownloading = false;
      // Force the next isOllamaReachable()/areOllamaModelsReady() poll to
      // actually re-check instead of serving a pre-download cached miss.
      g_lastOllamaCheck = std::chrono::steady_clock::time_point{};
    });
}

void openOllamaDownloadPage() {
    NSURL* url = [NSURL URLWithString:@"https://ollama.com/download"];
    [[NSWorkspace sharedWorkspace] openURL:url];
}

bool isThinkHarderModelReady() {
    RefreshOllamaStatusIfStale();
    return g_ollamaReachable.load() && g_thinkHarderModelPresent.load();
}

bool isThinkHarderModelDownloading() {
    return g_thinkHarderDownloading.load();
}

bool didThinkHarderModelDownloadFail() {
    return g_thinkHarderDownloadFailed.load();
}

void downloadThinkHarderModelAsync() {
    if (g_thinkHarderDownloading.load() || isThinkHarderModelReady()) {
        return;
    }
    g_thinkHarderDownloading = true;
    g_thinkHarderDownloadFailed = false;

    const std::string binary = OllamaBinaryPath();
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
      const std::string cmd = "\"" + binary + "\" pull " + kThinkHarderModel + " >/dev/null 2>&1";
      const bool ok = (std::system(cmd.c_str()) == 0);
      g_thinkHarderDownloadFailed = !ok;
      g_thinkHarderDownloading = false;
      g_lastOllamaCheck = std::chrono::steady_clock::time_point{};
    });
}

}  // namespace SetupChecker
