#import <Foundation/Foundation.h>
#import <Security/Security.h>

#include "ClaudeKeyStore.h"

namespace {

NSString* const kService = @"com.aedinlai.lecturenotes.anthropic";
NSString* const kAccount = @"api_key";

NSMutableDictionary* BaseQuery() {
    return [@{
        (__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService : kService,
        (__bridge id)kSecAttrAccount : kAccount,
    } mutableCopy];
}

}  // namespace

namespace ClaudeKeyStore {

std::string key() {
    NSMutableDictionary* query = BaseQuery();
    query[(__bridge id)kSecReturnData] = @YES;
    query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;

    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || result == NULL) {
        return std::string();
    }
    NSData* data = (__bridge_transfer NSData*)result;
    NSString* str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return str ? std::string(str.UTF8String) : std::string();
}

bool hasKey() {
    return !key().empty();
}

void setKey(const std::string& apiKey) {
    NSData* data = [NSData dataWithBytes:apiKey.data() length:apiKey.size()];

    NSDictionary* update = @{(__bridge id)kSecValueData : data};
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)BaseQuery(), (__bridge CFDictionaryRef)update);

    if (status == errSecItemNotFound) {
        NSMutableDictionary* addQuery = BaseQuery();
        addQuery[(__bridge id)kSecValueData] = data;
        // Available as soon as the user unlocks the Mac once after boot,
        // without needing it unlocked again on every subsequent launch --
        // the normal choice for an app that isn't handling Face ID/Touch
        // ID-gated secrets.
        addQuery[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlock;
        SecItemAdd((__bridge CFDictionaryRef)addQuery, NULL);
    }
}

void clearKey() {
    SecItemDelete((__bridge CFDictionaryRef)BaseQuery());
}

}  // namespace ClaudeKeyStore
