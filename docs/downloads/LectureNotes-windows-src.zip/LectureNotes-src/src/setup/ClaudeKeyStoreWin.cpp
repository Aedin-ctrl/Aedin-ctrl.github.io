// Windows implementation of ClaudeKeyStore.h: the optional Anthropic API key
// lives in Windows Credential Manager (the counterpart of the macOS
// Keychain), encrypted to the user's account, never in a plain file.

#include "ClaudeKeyStore.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <wincred.h>

namespace {

const wchar_t* kTarget = L"LectureNotes/AnthropicAPIKey";

}  // namespace

namespace ClaudeKeyStore {

std::string key() {
    PCREDENTIALW cred = nullptr;
    if (!CredReadW(kTarget, CRED_TYPE_GENERIC, 0, &cred) || !cred) return std::string();
    std::string out(reinterpret_cast<const char*>(cred->CredentialBlob), cred->CredentialBlobSize);
    CredFree(cred);
    return out;
}

bool hasKey() {
    return !key().empty();
}

void setKey(const std::string& apiKey) {
    CREDENTIALW cred{};
    cred.Type = CRED_TYPE_GENERIC;
    cred.TargetName = const_cast<wchar_t*>(kTarget);
    cred.CredentialBlobSize = static_cast<DWORD>(apiKey.size());
    cred.CredentialBlob = reinterpret_cast<LPBYTE>(const_cast<char*>(apiKey.data()));
    cred.Persist = CRED_PERSIST_LOCAL_MACHINE;
    cred.UserName = const_cast<wchar_t*>(L"LectureNotes");
    CredWriteW(&cred, 0);
}

void clearKey() {
    CredDeleteW(kTarget, CRED_TYPE_GENERIC, 0);
}

}  // namespace ClaudeKeyStore
