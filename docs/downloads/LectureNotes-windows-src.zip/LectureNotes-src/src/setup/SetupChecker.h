#pragma once

#include <string>

// First-run/anytime setup checklist backend: detects whether each
// dependency the app needs (mic permission, the BlackHole system-audio
// driver, the Whisper speech model) is already satisfied, and drives the
// action for whichever ones aren't yet. Kept as a plain C++ header so
// non-Objective-C++ translation units (App.cpp) can share
// whisperModelPath() without pulling in AppKit/AVFoundation; the actual
// checks live in SetupChecker.mm.
namespace SetupChecker {

enum class MicPermission { NotDetermined, Denied, Restricted, Authorized };

// Which checklist rows this platform needs. Windows records system audio
// natively (no BlackHole) and has no screen-capture permission, so both
// rows are macOS-only; on Windows their checks always report satisfied.
#ifdef _WIN32
inline bool needsAudioDriver() { return false; }
inline bool needsScreenRecordingPermission() { return false; }
#else
inline bool needsAudioDriver() { return true; }
inline bool needsScreenRecordingPermission() { return true; }
#endif

// Where the downloaded Whisper model lives — a standard per-user
// Application Support location (NOT tied to any particular dev checkout),
// so this works for anyone who downloads the built app.
std::string whisperModelPath();
// Smaller, much faster English model the transcriber switches to when a PC
// can't keep up with the main one (Windows only; empty on macOS, where Metal
// keeps the big model fast). ensure...Async downloads it in the background.
std::string fastWhisperModelPath();
void ensureFastWhisperModelAsync();

MicPermission microphonePermissionStatus();
// Triggers the OS mic-permission prompt; no-op unless status is
// NotDetermined (a prior Denied/Restricted requires System Settings).
void requestMicrophoneAccess();
void openSystemMicrophoneSettings();

// True when the PC has no microphone at all (Windows desktops, VMs). Not a
// blocker: LectureNotes then records the lecture/system audio only.
bool isMicrophoneMissing();
void openSoundSettings();

bool isBlackHoleInstalled();
void openBlackHoleDownloadPage();
// Downloads the official BlackHole 2ch installer (same pinned version and
// SHA-256 as the one-line installer), verifies it, and opens it in macOS's
// Installer. Falls back to the download page if anything goes wrong.
void installBlackHoleAsync();
bool isBlackHoleInstallerDownloading();

bool isWhisperModelDownloaded();
bool isWhisperModelDownloading();
float whisperModelDownloadProgress();  // 0..1, meaningful only while downloading
bool didWhisperModelDownloadFail();
// No-op if already downloading or already downloaded.
void downloadWhisperModelAsync();

// For the screen-region "solve this" camera feature (see ScreenCapture,
// UIApp.mm's capture-mode handling) -- checked lazily the first time it's
// used rather than gating the main Setup checklist, since it's an
// optional feature, not core to recording. Unlike mic permission, macOS
// has no NotDetermined/Denied granularity exposed here -- just granted or
// not.
bool hasScreenRecordingPermission();

// macOS Sequoia asks a second, separate question the first time an app
// actually captures the screen ("...requesting to bypass the system private
// window picker..."), even with Screen Recording already granted. These let
// the checklist trigger that prompt with a tiny test capture during setup,
// instead of it appearing the first time the camera is used mid-lecture.
bool isScreenCaptureConfirmed();
bool isScreenCaptureTestRunning();
bool didScreenCaptureTestFail();
void testScreenCaptureAsync();
// Called after any successful real capture, so someone who already
// answered the prompt through the camera isn't asked to test again.
void noteScreenCaptureSucceeded();
// Called when a real capture comes back empty: forgets the "done" flag so the
// checklist asks again at next launch, instead of trusting a stale yes after
// macOS has withdrawn its approval.
void noteScreenCaptureFailed();
// True once requestScreenRecordingAccess() has been called at all, even if
// it was subsequently denied. There's no public NotDetermined/Denied
// distinction for screen recording the way MicPermission has, so this is
// tracked ourselves (persisted) to know whether "not granted" means "never
// asked" or "asked and denied" -- callers use this to switch a UI button
// from "Grant Access" to "Open System Settings", same idea as mic.
bool hasRequestedScreenRecordingAccessBefore();
// Triggers the OS's screen-recording permission prompt the first time
// ever it's called for this install; every call after that is a no-op
// (unlike CGRequestScreenCaptureAccess itself, which re-shows an "already
// denied" system alert on every call after a denial -- see the .mm file).
void requestScreenRecordingAccess();
void openSystemScreenRecordingSettings();

// For the Q&A (LocalLLMClient) and camera/vision (VisionLLMClient)
// features -- both use the same multimodal model ("qwen3.5:4b"), and need a
// local Ollama install that's actually running with it pulled. A
// fresh machine has neither, and without this check the app would just
// silently fail Q&A/camera requests with a cryptic "[error] could not
// reach Ollama" the first time someone tried them, well after Setup said
// everything was ready. Polled state is cached/refreshed on a background
// thread (at most every couple seconds) rather than blocking the UI
// thread on a network call every frame.
bool isOllamaReachable();
// False if Ollama itself isn't reachable, regardless of models.
bool areOllamaModelsReady();
// Blocking version (one localhost request, at most ~2s) for startup, where
// the cached value above hasn't been filled in yet.
bool checkOllamaModelsReadyNow();

// Ollama installed (app or command-line) but not necessarily running.
bool isOllamaInstalled();
// Starts an installed Ollama that isn't running (e.g. right after a restart)
// and waits briefly for it to answer. Returns true if it's reachable
// afterwards. Called automatically at launch, so a machine that simply
// hasn't started Ollama yet never gets told to download it again.
bool startOllamaIfInstalled();
bool isOllamaModelDownloading();
float ollamaModelDownloadProgress();  // 0..1 by model count, not bytes
bool didOllamaModelDownloadFail();
// No-op if already downloading or already ready.
void downloadOllamaModelsAsync();
void openOllamaDownloadPage();

// Optional, separate from the two required models above -- only needed
// for the "think harder" retry button (see LocalLLMClient::askThinkHarder)
// when no Claude API key is configured. Not required to use the app at
// all, so this is never folded into the main Setup checklist's allOK.
bool isThinkHarderModelReady();
bool isThinkHarderModelDownloading();
bool didThinkHarderModelDownloadFail();
void downloadThinkHarderModelAsync();

}  // namespace SetupChecker
