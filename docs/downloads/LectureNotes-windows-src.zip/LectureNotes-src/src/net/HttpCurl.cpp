// macOS implementation of Http.h on libcurl.

#include "net/Http.h"

#include <curl/curl.h>

#include <cstdio>

namespace Http {

namespace {

struct Sink {
    std::function<bool(const char*, size_t)> onData;
};

size_t WriteCallback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* sink = static_cast<Sink*>(userdata);
    return sink->onData(ptr, size * nmemb) ? size * nmemb : 0;
}

Result Perform(const std::string& url, const std::vector<std::string>& headers, const std::string* body,
               long timeoutSeconds, const std::function<bool(const char*, size_t)>& onData) {
    Result result;
    CURL* curl = curl_easy_init();
    if (!curl) {
        result.error = "failed to initialize HTTP client";
        return result;
    }
    struct curl_slist* list = nullptr;
    for (const std::string& h : headers) list = curl_slist_append(list, h.c_str());
    Sink sink{onData};
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    if (list) curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
    if (body) {
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body->c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body->size()));
    }
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    if (timeoutSeconds > 0) curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeoutSeconds);

    const CURLcode rc = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &result.status);
    if (list) curl_slist_free_all(list);
    curl_easy_cleanup(curl);
    if (rc != CURLE_OK) {
        result.error = curl_easy_strerror(rc);
        return result;
    }
    result.ok = true;
    return result;
}

}  // namespace

Result post(const std::string& url, const std::vector<std::string>& headers, const std::string& body,
            long timeoutSeconds) {
    std::string out;
    Result r = Perform(url, headers, &body, timeoutSeconds, [&](const char* d, size_t n) {
        out.append(d, n);
        return true;
    });
    r.body = std::move(out);
    return r;
}

Result get(const std::string& url, long timeoutSeconds) {
    std::string out;
    Result r = Perform(url, {}, nullptr, timeoutSeconds, [&](const char* d, size_t n) {
        out.append(d, n);
        return true;
    });
    r.body = std::move(out);
    return r;
}

Result postStreamingLines(const std::string& url, const std::string& body,
                          const std::function<void(const std::string&)>& onLine) {
    std::string pending;
    Result r = Perform(url, {"Content-Type: application/json"}, &body, 0, [&](const char* d, size_t n) {
        pending.append(d, n);
        size_t nl;
        while ((nl = pending.find('\n')) != std::string::npos) {
            onLine(pending.substr(0, nl));
            pending.erase(0, nl + 1);
        }
        return true;
    });
    if (!pending.empty()) onLine(pending);
    return r;
}

bool downloadToFile(const std::string& url, const std::string& path, std::atomic<float>* progress,
                    std::string* error) {
    (void)progress;
    const std::string tmp = path + ".part";
    FILE* f = std::fopen(tmp.c_str(), "wb");
    if (!f) {
        if (error) *error = "could not write " + tmp;
        return false;
    }
    const Result r = Perform(url, {}, nullptr, 0, [&](const char* d, size_t n) { return std::fwrite(d, 1, n, f) == n; });
    std::fclose(f);
    if (!r.ok || r.status < 200 || r.status >= 300 || std::rename(tmp.c_str(), path.c_str()) != 0) {
        std::remove(tmp.c_str());
        if (error) *error = r.ok ? "server returned " + std::to_string(r.status) : r.error;
        return false;
    }
    return true;
}

}  // namespace Http
