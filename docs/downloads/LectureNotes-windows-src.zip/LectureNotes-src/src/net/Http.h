#pragma once

// Minimal blocking HTTP client: libcurl on macOS, WinHTTP on Windows.

#include <atomic>
#include <functional>
#include <string>
#include <vector>

namespace Http {

struct Result {
    bool ok = false;         // transport succeeded (any HTTP status)
    long status = 0;         // HTTP status code
    std::string body;
    std::string error;       // transport error text when !ok
};

// `headers` are full "Name: value" lines.
Result post(const std::string& url, const std::vector<std::string>& headers, const std::string& body,
            long timeoutSeconds);
Result get(const std::string& url, long timeoutSeconds);

// POST that hands each response line to `onLine` as it arrives (for
// streaming JSON-lines APIs like Ollama's /api/pull). No overall timeout.
Result postStreamingLines(const std::string& url, const std::string& body,
                          const std::function<void(const std::string&)>& onLine);

// Downloads to `path` (via a temp file, renamed on success). `progress`
// (0..1) is updated when the server sends a length.
bool downloadToFile(const std::string& url, const std::string& path, std::atomic<float>* progress,
                    std::string* error);

}  // namespace Http
