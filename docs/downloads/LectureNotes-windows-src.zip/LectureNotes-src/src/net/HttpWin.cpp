// Windows implementation of Http.h on WinHTTP: built into Windows, uses the
// system's TLS and proxy settings, nothing extra to ship.

#include "net/Http.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>

#include <cstdio>
#include <algorithm>
#include <filesystem>

#include "platform/win/WinUtil.h"

namespace Http {

namespace {

struct Handle {
    HINTERNET h = nullptr;
    Handle() = default;
    explicit Handle(HINTERNET v) : h(v) {}
    ~Handle() {
        if (h) WinHttpCloseHandle(h);
    }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    explicit operator bool() const { return h != nullptr; }
};

std::string LastErrorText(const char* what) {
    return std::string(what) + " failed (error " + std::to_string(GetLastError()) + ")";
}

// One request/response. `onData` receives body bytes as they arrive; if it
// returns false the transfer stops. `contentLength` is set when known.
Result Perform(const std::string& method, const std::string& url, const std::vector<std::string>& headers,
               const std::string& body, long timeoutSeconds,
               const std::function<bool(const char*, size_t, unsigned long long contentLength)>& onData) {
    Result result;
    const std::wstring wurl = WinUtil::Widen(url);

    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof(parts);
    wchar_t host[256] = {};
    wchar_t path[4096] = {};
    parts.lpszHostName = host;
    parts.dwHostNameLength = static_cast<DWORD>(std::size(host));
    parts.lpszUrlPath = path;
    parts.dwUrlPathLength = static_cast<DWORD>(std::size(path));
    wchar_t extra[4096] = {};
    parts.lpszExtraInfo = extra;
    parts.dwExtraInfoLength = static_cast<DWORD>(std::size(extra));
    if (!WinHttpCrackUrl(wurl.c_str(), 0, 0, &parts)) {
        result.error = "bad URL";
        return result;
    }
    const bool https = parts.nScheme == INTERNET_SCHEME_HTTPS;

    // AUTOMATIC_PROXY needs Windows 8.1+; fall back to the default proxy.
    Handle session(WinHttpOpen(L"LectureNotes/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, WINHTTP_NO_PROXY_NAME,
                               WINHTTP_NO_PROXY_BYPASS, 0));
    if (!session) {
        session.h = WinHttpOpen(L"LectureNotes/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
                                WINHTTP_NO_PROXY_BYPASS, 0);
    }
    if (!session) {
        result.error = LastErrorText("WinHttpOpen");
        return result;
    }
    // 0 = no timeout (used for long streaming downloads).
    const int ms = timeoutSeconds > 0 ? static_cast<int>(timeoutSeconds * 1000) : 0;
    WinHttpSetTimeouts(session.h, ms ? ms : 15000, ms ? ms : 15000, ms, ms);

    Handle connection(WinHttpConnect(session.h, host, parts.nPort, 0));
    if (!connection) {
        result.error = LastErrorText("WinHttpConnect");
        return result;
    }
    const std::wstring object = std::wstring(path) + extra;
    Handle request(WinHttpOpenRequest(connection.h, WinUtil::Widen(method).c_str(), object.c_str(), nullptr,
                                      WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                      https ? WINHTTP_FLAG_SECURE : 0));
    if (!request) {
        result.error = LastErrorText("WinHttpOpenRequest");
        return result;
    }

    std::wstring headerBlock;
    for (const std::string& h : headers) headerBlock += WinUtil::Widen(h) + L"\r\n";

    if (!WinHttpSendRequest(request.h, headerBlock.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headerBlock.c_str(),
                            headerBlock.empty() ? 0 : static_cast<DWORD>(-1L),
                            body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(body.data()),
                            static_cast<DWORD>(body.size()), static_cast<DWORD>(body.size()), 0) ||
        !WinHttpReceiveResponse(request.h, nullptr)) {
        const DWORD err = GetLastError();
        result.error = err == ERROR_WINHTTP_CANNOT_CONNECT  ? "could not connect"
                       : err == ERROR_WINHTTP_TIMEOUT       ? "timed out"
                       : err == ERROR_WINHTTP_NAME_NOT_RESOLVED ? "no internet connection (name not resolved)"
                                                              : "request failed (error " + std::to_string(err) + ")";
        return result;
    }

    DWORD status = 0;
    DWORD size = sizeof(status);
    WinHttpQueryHeaders(request.h, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX,
                        &status, &size, WINHTTP_NO_HEADER_INDEX);
    result.status = static_cast<long>(status);

    unsigned long long contentLength = 0;
    wchar_t lenBuf[32] = {};
    DWORD lenSize = sizeof(lenBuf);
    if (WinHttpQueryHeaders(request.h, WINHTTP_QUERY_CONTENT_LENGTH, WINHTTP_HEADER_NAME_BY_INDEX, lenBuf, &lenSize,
                            WINHTTP_NO_HEADER_INDEX)) {
        contentLength = _wcstoui64(lenBuf, nullptr, 10);
    }

    std::vector<char> buf(64 * 1024);
    for (;;) {
        // Ask how much has arrived first: a synchronous WinHttpReadData
        // otherwise waits to fill the whole buffer, which holds back a
        // streamed answer until it's finished.
        DWORD available = 0;
        if (!WinHttpQueryDataAvailable(request.h, &available)) {
            result.error = GetLastError() == ERROR_WINHTTP_TIMEOUT ? "timed out" : LastErrorText("WinHttpQueryDataAvailable");
            return result;
        }
        if (available == 0) break;
        DWORD read = 0;
        if (!WinHttpReadData(request.h, buf.data(), std::min<DWORD>(available, static_cast<DWORD>(buf.size())), &read)) {
            result.error = GetLastError() == ERROR_WINHTTP_TIMEOUT ? "timed out" : LastErrorText("WinHttpReadData");
            return result;
        }
        if (read == 0) break;
        if (!onData(buf.data(), read, contentLength)) break;
    }
    result.ok = true;
    return result;
}

}  // namespace

Result post(const std::string& url, const std::vector<std::string>& headers, const std::string& body,
            long timeoutSeconds) {
    std::string out;
    Result r = Perform("POST", url, headers, body, timeoutSeconds,
                       [&](const char* d, size_t n, unsigned long long) {
                           out.append(d, n);
                           return true;
                       });
    r.body = std::move(out);
    return r;
}

Result get(const std::string& url, long timeoutSeconds) {
    std::string out;
    Result r = Perform("GET", url, {}, "", timeoutSeconds, [&](const char* d, size_t n, unsigned long long) {
        out.append(d, n);
        return true;
    });
    r.body = std::move(out);
    return r;
}

Result postStreamingLines(const std::string& url, const std::string& body,
                          const std::function<void(const std::string&)>& onLine, long timeoutSeconds) {
    std::string pending;
    Result r = Perform("POST", url, {"Content-Type: application/json"}, body, timeoutSeconds,
                       [&](const char* d, size_t n, unsigned long long) {
                           pending.append(d, n);
                           size_t nl;
                           while ((nl = pending.find('\n')) != std::string::npos) {
                               onLine(pending.substr(0, nl));
                               pending.erase(0, nl + 1);
                           }
                           return true;
                       });
    if (!pending.empty()) onLine(pending);
    return r;
}

bool downloadToFile(const std::string& url, const std::string& path, std::atomic<float>* progress,
                    std::string* error) {
    const std::string tmp = path + ".part";
    FILE* f = _wfopen(WinUtil::Widen(tmp).c_str(), L"wb");
    if (!f) {
        if (error) *error = "could not write " + tmp;
        return false;
    }
    unsigned long long received = 0;
    bool writeFailed = false;
    const Result r = Perform("GET", url, {}, "", 0, [&](const char* d, size_t n, unsigned long long total) {
        if (std::fwrite(d, 1, n, f) != n) {
            writeFailed = true;
            return false;
        }
        received += n;
        if (progress && total > 0) progress->store(static_cast<float>(static_cast<double>(received) / total));
        return true;
    });
    std::fclose(f);
    std::error_code ec;
    if (!r.ok || writeFailed || r.status < 200 || r.status >= 300) {
        std::filesystem::remove(std::filesystem::path(WinUtil::Widen(tmp)), ec);
        if (error) {
            *error = writeFailed ? "disk write failed (is the disk full?)"
                     : !r.ok     ? r.error
                                 : "server returned " + std::to_string(r.status);
        }
        return false;
    }
    std::filesystem::rename(std::filesystem::path(WinUtil::Widen(tmp)), std::filesystem::path(WinUtil::Widen(path)),
                            ec);
    if (ec) {
        if (error) *error = "could not move the download into place";
        return false;
    }
    return true;
}

}  // namespace Http
