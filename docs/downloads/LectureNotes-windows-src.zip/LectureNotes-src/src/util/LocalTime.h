#pragma once

// Thread-safe localtime (localtime_r on POSIX, localtime_s on Windows).

#include <ctime>

inline std::tm LocalTm(std::time_t t) {
    std::tm out{};
#ifdef _WIN32
    localtime_s(&out, &t);
#else
    localtime_r(&t, &out);
#endif
    return out;
}
