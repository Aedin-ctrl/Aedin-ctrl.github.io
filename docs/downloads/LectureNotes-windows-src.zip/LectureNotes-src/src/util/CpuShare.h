#pragma once

#include <atomic>

// On Windows the speech model and the local answer model share the CPU.
// Counts local-model requests in flight so transcription can use every core
// except while an answer is being generated (see WhisperWorker/OllamaClient).
namespace CpuShare {

inline std::atomic<int> localModelBusy{0};

struct LocalModelBusy {
    LocalModelBusy() { ++localModelBusy; }
    ~LocalModelBusy() { --localModelBusy; }
    LocalModelBusy(const LocalModelBusy&) = delete;
    LocalModelBusy& operator=(const LocalModelBusy&) = delete;
};

}  // namespace CpuShare
