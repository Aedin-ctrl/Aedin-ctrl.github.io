#include "util/Log.h"

#include <cstdarg>
#include <cstdio>

#ifdef _WIN32
#include "platform/win/WinUtil.h"
#endif

void LogLine(const char* format, ...) {
    char buf[1024];
    va_list args;
    va_start(args, format);
    std::vsnprintf(buf, sizeof(buf), format, args);
    va_end(args);
#ifdef _WIN32
    WinUtil::Log("%s", buf);
#else
    std::fprintf(stderr, "%s\n", buf);
#endif
}
