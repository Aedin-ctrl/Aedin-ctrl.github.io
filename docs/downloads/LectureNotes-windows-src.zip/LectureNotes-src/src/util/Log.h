#pragma once

// One-line diagnostics: Windows appends to %LOCALAPPDATA%\LectureNotes\Logs\
// app.log (see WinUtil::Log); macOS writes to stderr.
void LogLine(const char* format, ...);
