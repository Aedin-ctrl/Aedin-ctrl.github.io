#include "SessionWriter.h"

#include <sys/stat.h>

#include <cstdlib>
#include <filesystem>
#include <ctime>
#include <fstream>
#include <sstream>

#include "util/LocalTime.h"
#ifdef _WIN32
#include "platform/win/WinUtil.h"
#endif

namespace {

std::string homeDir() {
    if (const char* home = getenv("HOME")) {
        return std::string(home);
    }
    return std::string();
}

#ifndef _WIN32
// Ensures a directory exists, creating intermediate components as needed.
void mkdirsRecursive(const std::string& path) {
    std::string current;
    size_t pos = 0;
    if (path.empty()) return;
    if (path[0] == '/') {
        current = "/";
        pos = 1;
    }
    while (pos <= path.size()) {
        size_t next = path.find('/', pos);
        if (next == std::string::npos) next = path.size();
        current += path.substr(pos, next - pos);
        if (!current.empty()) {
            mkdir(current.c_str(), 0755); // ignore EEXIST and other errors here
        }
        current += "/";
        pos = next + 1;
    }
}
#endif

std::string timestampForFilename() {
    std::time_t t = std::time(nullptr);
    const std::tm tmVal = LocalTm(t);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d_%H-%M-%S", &tmVal);
    return std::string(buf);
}

std::string timestampForHeader() {
    std::time_t t = std::time(nullptr);
    const std::tm tmVal = LocalTm(t);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tmVal);
    return std::string(buf);
}

} // namespace

std::string SessionWriter::writeTranscript(const std::vector<TranscriptSegment>& segments,
                                            const std::vector<QAEntry>& qaEntries) {
#ifdef _WIN32
    const std::string dir = WinUtil::DocumentsDir() + "\\LectureNotes";
    WinUtil::CreateDirectories(dir);
#else
    std::string dir = homeDir() + "/Documents/LectureNotes";
    mkdirsRecursive(dir);
#endif

    std::string filename = timestampForFilename() + ".md";
    std::string path = dir + "/" + filename;

    std::ofstream out(std::filesystem::u8path(path), std::ios::out | std::ios::trunc);
    out << "# Lecture Notes - " << timestampForHeader() << "\n\n";
    out << "## Transcript\n\n";
    for (const auto& seg : segments) {
        out << "**" << speakerLabel(seg.speaker) << ":** " << seg.text << "\n\n";
    }

    // Auto-Q&A tabs live only in memory (QAStore) while recording -- without
    // this section, closing the app silently threw away every answer the
    // local LLM had already generated, which is the one artifact worth
    // keeping most since it took real latency/compute to produce.
    if (!qaEntries.empty()) {
        out << "## Q&A\n\n";
        for (const auto& qa : qaEntries) {
            out << "**Q:** " << qa.question << "\n\n";
            if (qa.pending) {
                out << "**A:** _(recording stopped before an answer came back)_\n\n";
            } else if (qa.streaming) {
                out << "**A:** " << qa.answer << "\n\n_(recording stopped while this answer was still coming in)_\n\n";
            } else {
                out << "**A:** " << qa.answer << "\n\n";
            }
        }
    }
    out.close();

    return path;
}

bool SessionWriter::insertNotes(const std::string& path, const std::string& notes) {
    std::ifstream in(std::filesystem::u8path(path));
    if (!in) return false;
    std::stringstream buffer;
    buffer << in.rdbuf();
    in.close();
    std::string content = buffer.str();
    // After the "# Lecture Notes - <date>" title line and its blank line.
    size_t insertAt = content.find("\n\n");
    insertAt = (insertAt == std::string::npos) ? content.size() : insertAt + 2;
    content.insert(insertAt, "## Notes\n\n" + notes + "\n\n");
    std::ofstream out(std::filesystem::u8path(path), std::ios::out | std::ios::trunc);
    out << content;
    return static_cast<bool>(out);
}
