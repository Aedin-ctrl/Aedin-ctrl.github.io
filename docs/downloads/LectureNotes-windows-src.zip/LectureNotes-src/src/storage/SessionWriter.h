#pragma once

#include <string>
#include <vector>

#include "asr/TranscriptStore.h"
#include "qa/QAStore.h"

class SessionWriter {
public:
    // Writes the given transcript segments (and, if any, the session's
    // auto-Q&A history) to a timestamped markdown file under
    // ~/Documents/LectureNotes/ (creating the directory if needed).
    // Returns the full path written. `qaEntries` defaults empty so existing
    // callers/tests that only care about the transcript don't need changes.
    static std::string writeTranscript(const std::vector<TranscriptSegment>& segments,
                                        const std::vector<QAEntry>& qaEntries = {});

    // Inserts a "## Notes" section right under the title of a session file
    // written by writeTranscript(), so the notes are the first thing you see.
    static bool insertNotes(const std::string& path, const std::string& notes);
};
