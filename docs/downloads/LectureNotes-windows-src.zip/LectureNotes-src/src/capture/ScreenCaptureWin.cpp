// Windows implementation of ScreenCapture.h. GDI BitBlt from the desktop DC:
// no permission prompt and no yellow capture border, and it honors
// WDA_EXCLUDEFROMCAPTURE, so the overlay itself never appears in the shot.
// `rect` is in physical screen pixels (the Windows front end is
// per-monitor DPI aware); the image is encoded to PNG with WIC.

#include "ScreenCapture.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <objidl.h>
#include <wincodec.h>

#include <thread>

namespace {

std::vector<uint8_t> EncodePng(const std::vector<uint8_t>& bgra, int width, int height) {
    std::vector<uint8_t> png;
    const HRESULT coInit = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IWICImagingFactory* factory = nullptr;
    IStream* stream = nullptr;
    IWICBitmapEncoder* encoder = nullptr;
    IWICBitmapFrameEncode* frame = nullptr;
    bool ok = SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                         IID_PPV_ARGS(&factory))) &&
              SUCCEEDED(CreateStreamOnHGlobal(nullptr, TRUE, &stream)) &&
              SUCCEEDED(factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, &encoder)) &&
              SUCCEEDED(encoder->Initialize(stream, WICBitmapEncoderNoCache)) &&
              SUCCEEDED(encoder->CreateNewFrame(&frame, nullptr)) && SUCCEEDED(frame->Initialize(nullptr)) &&
              SUCCEEDED(frame->SetSize(static_cast<UINT>(width), static_cast<UINT>(height)));
    if (ok) {
        WICPixelFormatGUID format = GUID_WICPixelFormat32bppBGR;
        ok = SUCCEEDED(frame->SetPixelFormat(&format)) &&
             SUCCEEDED(frame->WritePixels(static_cast<UINT>(height), static_cast<UINT>(width * 4),
                                          static_cast<UINT>(bgra.size()), const_cast<BYTE*>(bgra.data()))) &&
             SUCCEEDED(frame->Commit()) && SUCCEEDED(encoder->Commit());
    }
    if (ok) {
        HGLOBAL mem = nullptr;
        if (SUCCEEDED(GetHGlobalFromStream(stream, &mem))) {
            STATSTG stat{};
            stream->Stat(&stat, STATFLAG_NONAME);
            const SIZE_T size = static_cast<SIZE_T>(stat.cbSize.QuadPart);
            if (const void* data = GlobalLock(mem)) {
                png.assign(static_cast<const uint8_t*>(data), static_cast<const uint8_t*>(data) + size);
                GlobalUnlock(mem);
            }
        }
    }
    if (frame) frame->Release();
    if (encoder) encoder->Release();
    if (stream) stream->Release();
    if (factory) factory->Release();
    if (SUCCEEDED(coInit)) CoUninitialize();
    return png;
}

}  // namespace

namespace ScreenCapture {

void captureRegionAsPNG(const ScreenRect& rect, int pixelWidth, int pixelHeight,
                        std::function<void(std::vector<uint8_t>)> callback) {
    const int x = static_cast<int>(rect.x);
    const int y = static_cast<int>(rect.y);
    const int w = pixelWidth > 0 ? pixelWidth : static_cast<int>(rect.width);
    const int h = pixelHeight > 0 ? pixelHeight : static_cast<int>(rect.height);
    std::vector<uint8_t> pixels;
    if (w > 0 && h > 0) {
        HDC screen = GetDC(nullptr);
        HDC mem = CreateCompatibleDC(screen);
        BITMAPINFO bi{};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
        bi.bmiHeader.biWidth = w;
        bi.bmiHeader.biHeight = -h;  // top-down rows
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP bmp = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        if (bmp && bits) {
            HGDIOBJ old = SelectObject(mem, bmp);
            if (BitBlt(mem, 0, 0, w, h, screen, x, y, SRCCOPY | CAPTUREBLT)) {
                pixels.assign(static_cast<uint8_t*>(bits), static_cast<uint8_t*>(bits) + static_cast<size_t>(w) * h * 4);
            }
            SelectObject(mem, old);
        }
        if (bmp) DeleteObject(bmp);
        DeleteDC(mem);
        ReleaseDC(nullptr, screen);
    }
    // Encoding and the model call happen off the UI thread, like the macOS
    // ScreenCaptureKit path.
    std::thread([pixels = std::move(pixels), w, h, callback = std::move(callback)]() {
        callback(pixels.empty() ? std::vector<uint8_t>() : EncodePng(pixels, w, h));
    }).detach();
}

}  // namespace ScreenCapture
