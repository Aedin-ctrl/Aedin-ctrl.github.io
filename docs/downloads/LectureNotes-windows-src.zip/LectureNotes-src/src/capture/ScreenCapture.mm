#import <ScreenCaptureKit/ScreenCaptureKit.h>

#include "ScreenCapture.h"

#import <ImageIO/ImageIO.h>

namespace {

std::vector<uint8_t> EncodeCGImageAsPNG(CGImageRef image) {
    CFMutableDataRef data = CFDataCreateMutable(kCFAllocatorDefault, 0);
    CGImageDestinationRef dest = CGImageDestinationCreateWithData(data, CFSTR("public.png"), 1, nullptr);
    if (!dest) {
        CFRelease(data);
        return {};
    }

    CGImageDestinationAddImage(dest, image, nullptr);
    const bool ok = CGImageDestinationFinalize(dest);
    CFRelease(dest);

    std::vector<uint8_t> bytes;
    if (ok) {
        const UInt8* ptr = CFDataGetBytePtr(data);
        const CFIndex len = CFDataGetLength(data);
        bytes.assign(ptr, ptr + len);
    }
    CFRelease(data);
    return bytes;
}

}  // namespace

void ScreenCapture::captureRegionAsPNG(const ScreenRect& rect, int pixelWidth, int pixelHeight,
                                        std::function<void(std::vector<uint8_t>)> callback) {
    if (rect.width <= 0 || rect.height <= 0 || pixelWidth <= 0 || pixelHeight <= 0) {
        callback({});
        return;
    }

    if (@available(macOS 14.0, *)) {
        const CGRect quartzRect = CGRectMake(rect.x, rect.y, rect.width, rect.height);
        const int outWidth = pixelWidth;
        const int outHeight = pixelHeight;

        [SCShareableContent
            getShareableContentWithCompletionHandler:^(SCShareableContent* _Nullable content, NSError* _Nullable error) {
              if (error || content.displays.count == 0) {
                  dispatch_async(dispatch_get_main_queue(), ^{
                    callback({});
                  });
                  return;
              }

              // Our capture overlay always spans exactly one NSScreen, so
              // whichever display contains the region's origin is the
              // right one; falls back to the first display in the
              // (shouldn't-happen) case none match.
              SCDisplay* target = content.displays.firstObject;
              for (SCDisplay* d in content.displays) {
                  if (CGRectContainsPoint(d.frame, quartzRect.origin)) {
                      target = d;
                      break;
                  }
              }

              SCContentFilter* filter = [[SCContentFilter alloc] initWithDisplay:target excludingWindows:@[]];
              SCStreamConfiguration* config = [[SCStreamConfiguration alloc] init];
              // sourceRect is relative to the display's own origin, not
              // global screen space.
              config.sourceRect = CGRectMake(quartzRect.origin.x - target.frame.origin.x,
                                              quartzRect.origin.y - target.frame.origin.y, quartzRect.size.width,
                                              quartzRect.size.height);
              config.width = (size_t)outWidth;
              config.height = (size_t)outHeight;
              config.showsCursor = NO;

              [SCScreenshotManager
                  captureImageWithFilter:filter
                            configuration:config
                        completionHandler:^(CGImageRef _Nullable image, NSError* _Nullable captureError) {
                          std::vector<uint8_t> bytes = image ? EncodeCGImageAsPNG(image) : std::vector<uint8_t>{};
                          dispatch_async(dispatch_get_main_queue(), ^{
                            callback(std::move(bytes));
                          });
                        }];
            }];
    } else {
        // The macOS 15 SDK this project builds against no longer has
        // CGWindowListCreateImage at all, so there's no older fallback
        // path left to try here.
        callback({});
    }
}
