#pragma once

#include <cstdint>
#include <functional>
#include <vector>

// A rectangle in Quartz global-display coordinates: origin at the
// top-left of the main display, y increasing downward -- NOT the same
// space as AppKit's NSScreen/NSWindow frames (origin bottom-left, y
// increasing upward). Callers converting from an NSView/NSWindow rect
// must flip y first; see UIApp.mm's confirmScreenCapture for that
// conversion.
struct ScreenRect {
    double x = 0;
    double y = 0;
    double width = 0;
    double height = 0;
};

// Screen-region grabbing for the camera/"solve this" feature, via
// ScreenCaptureKit's one-shot screenshot API (SCScreenshotManager,
// macOS 14+). The older, simpler CGWindowListCreateImage was fully
// removed (not just deprecated) as of the macOS 15 SDK this project
// builds against, so there's no simpler synchronous alternative anymore.
namespace ScreenCapture {

// Captures the given region as PNG-encoded bytes, asynchronously (this
// API has no synchronous form). `callback` fires on the main thread with
// empty bytes on any failure -- most commonly Screen Recording
// permission not granted (see SetupChecker::hasScreenRecordingPermission),
// but also an invalid/off-screen rect, no matching display, or an
// encoding failure. `pixelWidth`/`pixelHeight` are the desired output
// image's pixel dimensions (the caller multiplies by the screen's
// backingScaleFactor for a Retina-sharp capture); the region itself is
// still given in points via `rect`.
void captureRegionAsPNG(const ScreenRect& rect, int pixelWidth, int pixelHeight,
                        std::function<void(std::vector<uint8_t>)> callback);

}  // namespace ScreenCapture
