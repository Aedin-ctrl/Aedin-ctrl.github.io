// lecturenotes-selftest: exercises the Windows build's real code paths from
// the command line (no GUI), for testing on machines where the UI can't be
// driven. Prints results to stdout; exit code 0 = pass.
//
//   selftest ollama "question"      local model answer via WinHTTP
//   selftest claude "question"      Claude Code CLI via CreateProcess
//   selftest capture <seconds> [wav] record system audio (WASAPI loopback) + mic, transcribe;
//                                   plays the WAV through the speakers meanwhile, if given
//   selftest loopback               play a tone and record it back via WASAPI loopback
//   selftest play <wav>             just play a WAV on the speakers
//   selftest doc <file>             text the "+" drawer would extract (pdf/docx/txt)
//   selftest screenshot <out.png>   GDI capture of the top-left 400x300 px, as PNG

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <audioclient.h>
#include <mmdeviceapi.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <chrono>
#include <cstdio>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "asr/TranscriptStore.h"
#include "asr/WhisperWorker.h"
#include "audio/AudioCapture.h"
#include "audio/RingBuffer.h"
#include "audio/Resampler.h"
#include "whisper.h"
#include "capture/ScreenCapture.h"
#include "platform/win/DocumentTextWin.h"
#include "setup/SetupChecker.h"
#include "summarize/ClaudeCodeClient.h"
#include "summarize/LocalLLMClient.h"
#include "summarize/VisionLLMClient.h"

namespace {

// Plays a 16-bit PCM WAV on the default speakers in a background thread
// (Windows converts the format). Used by "capture" to feed known speech
// through the real system-audio path.
std::thread PlayWav(const std::string& path, std::atomic<bool>* done) {
    return std::thread([path, done]() {
        FILE* f = std::fopen(path.c_str(), "rb");
        std::vector<uint8_t> file;
        if (f) {
            uint8_t buf[65536];
            size_t n;
            while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) file.insert(file.end(), buf, buf + n);
            std::fclose(f);
        }
        // Minimal RIFF parse: find "fmt " and "data".
        WAVEFORMATEX fmt{};
        const uint8_t* pcm = nullptr;
        size_t pcmBytes = 0;
        for (size_t i = 12; i + 8 <= file.size();) {
            const uint32_t size = *reinterpret_cast<const uint32_t*>(&file[i + 4]);
            if (std::memcmp(&file[i], "fmt ", 4) == 0) std::memcpy(&fmt, &file[i + 8], 16);
            if (std::memcmp(&file[i], "data", 4) == 0) {
                pcm = &file[i + 8];
                pcmBytes = std::min<size_t>(size, file.size() - i - 8);
            }
            i += 8 + size + (size & 1);
        }
        if (!pcm || fmt.nBlockAlign == 0) {
            std::printf("could not read %s\n", path.c_str());
            *done = true;
            return;
        }
        CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        IMMDeviceEnumerator* en = nullptr;
        IMMDevice* dev = nullptr;
        IAudioClient* client = nullptr;
        IAudioRenderClient* render = nullptr;
        HRESULT hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                                      __uuidof(IMMDeviceEnumerator), reinterpret_cast<void**>(&en));
        if (SUCCEEDED(hr)) hr = en->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
        if (SUCCEEDED(hr)) hr = dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(&client));
        if (SUCCEEDED(hr)) hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED,
                                                   AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
                                                   10000000, 0, &fmt, nullptr);
        if (SUCCEEDED(hr)) hr = client->GetService(__uuidof(IAudioRenderClient), reinterpret_cast<void**>(&render));
        UINT32 bufferFrames = 0;
        if (SUCCEEDED(hr)) hr = client->GetBufferSize(&bufferFrames);
        if (FAILED(hr)) {
            std::printf("wav playback failed 0x%08lX\n", static_cast<unsigned long>(hr));
            *done = true;
            return;
        }
        client->Start();
        size_t offset = 0;
        const size_t totalFrames = pcmBytes / fmt.nBlockAlign;
        while (offset < totalFrames) {
            UINT32 padding = 0;
            client->GetCurrentPadding(&padding);
            UINT32 frames = std::min<UINT32>(bufferFrames - padding, static_cast<UINT32>(totalFrames - offset));
            BYTE* data = nullptr;
            if (frames > 0 && SUCCEEDED(render->GetBuffer(frames, &data))) {
                std::memcpy(data, pcm + offset * fmt.nBlockAlign, frames * fmt.nBlockAlign);
                render->ReleaseBuffer(frames, 0);
                offset += frames;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        client->Stop();
        std::printf("played %zu frames of %s\n", totalFrames, path.c_str());
        *done = true;
    });
}

int Ollama(const std::string& q) {
    const auto t0 = std::chrono::steady_clock::now();
    int partials = 0;
    double first = -1;
    const std::string a = LocalLLMClient::ask(q, [&](const std::string&) {
        if (first < 0) first = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        ++partials;
    });
    const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("ollama (%.1fs, first words at %.1fs, %d updates): %s\n", s, first, partials, a.c_str());
    return a.rfind("[error]", 0) == 0 ? 1 : 0;
}

int Claude(const std::string& q, const std::string& force) {
    std::printf("claude installed: %d\n", ClaudeCodeClient::isInstalled() ? 1 : 0);
    const bool available = ClaudeCodeClient::isAvailableNow();
    std::printf("claude signed in: %d\n", available ? 1 : 0);
    if (!available && force.empty()) return 2;
    const auto t0 = std::chrono::steady_clock::now();
    const std::string a = ClaudeCodeClient::ask(q, LocalLLMClient::systemPrompt(), "low", 60,
                                                [](const std::string&) {});
    const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("claude (%.1fs): %s\n", s, a.c_str());
    return a.rfind("[error]", 0) == 0 ? 1 : 0;
}

int Capture(int seconds, const std::string& wav) {
    RingBuffer themRing, meRing;
    TranscriptStore store;
    const std::string model = SetupChecker::whisperModelPath();
    std::printf("model: %s\n", model.c_str());
    WhisperWorker worker(model, themRing, meRing, store);
    worker.setFallbackModel(SetupChecker::fastWhisperModelPath());
    const auto t0 = std::chrono::steady_clock::now();
    if (!worker.start()) {
        std::printf("whisper failed: %s\n", worker.lastError().c_str());
        return 1;
    }
    std::printf("whisper loaded in %.1fs\n",
                std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    AudioCapture them("BlackHole", themRing);  // = WASAPI loopback on Windows
    AudioCapture me(std::string(), meRing);
    const bool themOk = them.start();
    const bool meOk = me.start();
    std::printf("loopback: %s\n", themOk ? "started" : them.lastError().c_str());
    std::printf("mic: %s\n", meOk ? "started" : me.lastError().c_str());
    if (!themOk) return 1;
    std::atomic<bool> played{false};
    std::thread player;
    if (!wav.empty()) player = PlayWav(wav, &played);
    float peakThem = 0, peakMe = 0;
    for (int i = 0; i < seconds * 10; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        peakThem = std::max(peakThem, them.currentLevelRMS());
        if (meOk) peakMe = std::max(peakMe, me.currentLevelRMS());
    }
    std::printf("peak level: them %.4f  me %.4f\n", peakThem, peakMe);
    if (player.joinable()) player.join();
    // Let the last window finish decoding.
    std::this_thread::sleep_for(std::chrono::seconds(12));
    them.stop();
    if (meOk) me.stop();
    worker.stop();
    int n = 0;
    for (const auto& seg : store.snapshot()) {
        std::printf("[%s] %s\n", seg.speaker == Speaker::Me ? "me" : "them", seg.text.c_str());
        ++n;
    }
    std::printf("segments: %d\n", n);
    return n > 0 ? 0 : 1;
}

// Plays a 440 Hz tone on the default speakers (its own WASAPI render stream)
// while AudioCapture records them in loopback: tells "nothing was playing"
// apart from "loopback doesn't deliver audio on this machine".
int Loopback() {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IMMDeviceEnumerator* en = nullptr;
    IMMDevice* dev = nullptr;
    IAudioClient* client = nullptr;
    IAudioRenderClient* render = nullptr;
    WAVEFORMATEX* wfx = nullptr;
    HRESULT hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator),
                                  reinterpret_cast<void**>(&en));
    if (SUCCEEDED(hr)) hr = en->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
    if (SUCCEEDED(hr)) hr = dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(&client));
    if (SUCCEEDED(hr)) hr = client->GetMixFormat(&wfx);
    if (FAILED(hr)) {
        std::printf("render setup failed 0x%08lX\n", static_cast<unsigned long>(hr));
        return 1;
    }
    std::printf("speaker mix format: %lu Hz, %u ch, %u bits, tag 0x%x\n", wfx->nSamplesPerSec, wfx->nChannels,
                wfx->wBitsPerSample, wfx->wFormatTag);
    hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 10000000, 0, wfx, nullptr);
    if (SUCCEEDED(hr)) hr = client->GetService(__uuidof(IAudioRenderClient), reinterpret_cast<void**>(&render));
    UINT32 bufferFrames = 0;
    if (SUCCEEDED(hr)) hr = client->GetBufferSize(&bufferFrames);
    if (FAILED(hr)) {
        std::printf("render init failed 0x%08lX\n", static_cast<unsigned long>(hr));
        return 1;
    }

    RingBuffer ring;
    AudioCapture loop("BlackHole", ring);
    if (!loop.start()) {
        std::printf("loopback start failed: %s\n", loop.lastError().c_str());
        return 1;
    }
    client->Start();
    const bool isFloat = wfx->wBitsPerSample == 32;  // mix format is float32 on practically all systems
    double phase = 0;
    float peak = 0;
    size_t captured = 0;
    std::vector<float> drain(16000);
    const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (std::chrono::steady_clock::now() < end) {
        UINT32 padding = 0;
        client->GetCurrentPadding(&padding);
        const UINT32 frames = bufferFrames - padding;
        BYTE* data = nullptr;
        if (frames > 0 && SUCCEEDED(render->GetBuffer(frames, &data))) {
            for (UINT32 f = 0; f < frames; ++f) {
                const float v = 0.2f * static_cast<float>(std::sin(phase));
                phase += 2 * 3.14159265358979 * 440.0 / wfx->nSamplesPerSec;
                for (int c = 0; c < wfx->nChannels; ++c) {
                    if (isFloat) reinterpret_cast<float*>(data)[f * wfx->nChannels + c] = v;
                    else reinterpret_cast<int16_t*>(data)[f * wfx->nChannels + c] = static_cast<int16_t>(v * 32767);
                }
            }
            render->ReleaseBuffer(frames, 0);
        }
        peak = std::max(peak, loop.currentLevelRMS());
        size_t n;
        while ((n = ring.read(drain.data(), drain.size())) > 0) captured += n;
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    client->Stop();
    loop.stop();
    std::printf("loopback: captured %zu samples (16 kHz), peak level %.4f -> %s\n", captured, peak,
                peak > 0.01f ? "WORKS" : "NO AUDIO");
    return peak > 0.01f ? 0 : 1;
}

// Times whisper on the first 8 s of a 16-bit PCM WAV, with the default
// 30 s context and with the reduced context the app switches to on slow CPUs.
int Bench(const std::string& wav, const std::string& modelPath) {
    FILE* f = std::fopen(wav.c_str(), "rb");
    if (!f) return 1;
    std::vector<uint8_t> file;
    uint8_t buf[65536];
    size_t n;
    while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) file.insert(file.end(), buf, buf + n);
    std::fclose(f);
    WAVEFORMATEX fmt{};
    const int16_t* pcm = nullptr;
    size_t samples = 0;
    for (size_t i = 12; i + 8 <= file.size();) {
        const uint32_t size = *reinterpret_cast<const uint32_t*>(&file[i + 4]);
        if (std::memcmp(&file[i], "fmt ", 4) == 0) std::memcpy(&fmt, &file[i + 8], 16);
        if (std::memcmp(&file[i], "data", 4) == 0) {
            pcm = reinterpret_cast<const int16_t*>(&file[i + 8]);
            samples = std::min<size_t>(size, file.size() - i - 8) / 2;
        }
        i += 8 + size + (size & 1);
    }
    if (!pcm) return 1;
    std::vector<float> in(samples);
    for (size_t i = 0; i < samples; ++i) in[i] = pcm[i] / 32768.0f;
    Resampler rs(static_cast<double>(fmt.nSamplesPerSec), fmt.nChannels, 16000.0);
    std::vector<float> audio;
    rs.process(in.data(), samples / fmt.nChannels, audio);
    audio.resize(std::min<size_t>(audio.size(), 128000));
    whisper_context_params cp = whisper_context_default_params();
    const std::string model = modelPath.empty() ? SetupChecker::whisperModelPath() : modelPath;
    std::printf("model %s\n", model.c_str());
    std::printf("system %s\n", whisper_print_system_info());
    whisper_context* ctx = whisper_init_from_file_with_params(model.c_str(), cp);
    if (!ctx) return 1;
    unsigned hw = std::thread::hardware_concurrency();
    for (int ctxv : {1500, 512}) {
        const int reduced = ctxv;
        whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
        p.print_progress = p.print_realtime = p.print_timestamps = false;
        p.language = "en";
        p.no_context = true;
        p.n_threads = static_cast<int>(hw > 1 ? std::min(hw - 1, 8u) : 1u);
        p.audio_ctx = ctxv;
        const auto t0 = std::chrono::steady_clock::now();
        whisper_full(ctx, p, audio.data(), static_cast<int>(audio.size()));
        const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::string text;
        for (int i = 0; i < whisper_full_n_segments(ctx); ++i) text += whisper_full_get_segment_text(ctx, i);
        std::printf("audio_ctx %d, %d threads: %.1fs for %.1fs of audio (%.1fx real time)\n  %s\n",
                    reduced, p.n_threads, sec, audio.size() / 16000.0,
                    (audio.size() / 16000.0) / sec, text.c_str());
    }
    whisper_free(ctx);
    return 0;
}

int Screenshot(const std::string& out) {
    std::atomic<bool> done{false};
    std::vector<uint8_t> png;
    ScreenCapture::captureRegionAsPNG({0, 0, 400, 300}, 400, 300, [&](std::vector<uint8_t> bytes) {
        png = std::move(bytes);
        done = true;
    });
    for (int i = 0; i < 100 && !done; ++i) std::this_thread::sleep_for(std::chrono::milliseconds(50));
    std::printf("png bytes: %zu\n", png.size());
    if (png.empty()) return 1;
    if (FILE* f = std::fopen(out.c_str(), "wb")) {
        std::fwrite(png.data(), 1, png.size(), f);
        std::fclose(f);
    }
    return 0;
}

// Times a camera question on a screenshot of the top-left w x h pixels.
int Vision(int w, int h) {
    std::atomic<bool> done{false};
    std::vector<uint8_t> png;
    const double shrink = std::min(1.0, std::sqrt(300000.0 / (static_cast<double>(w) * h)));  // as WinApp
    ScreenCapture::captureRegionAsPNG({0, 0, static_cast<double>(w), static_cast<double>(h)},
                                      static_cast<int>(w * shrink), static_cast<int>(h * shrink),
                                      [&](std::vector<uint8_t> bytes) {
                                          png = std::move(bytes);
                                          done = true;
                                      });
    for (int i = 0; i < 100 && !done; ++i) std::this_thread::sleep_for(std::chrono::milliseconds(50));
    const auto t0 = std::chrono::steady_clock::now();
    double first = -1;
    const std::string a = VisionLLMClient::analyze(png, "", [&](const std::string&) {
        if (first < 0) first = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    });
    const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("vision %dx%d (%zu bytes) first words %.1fs, total %.1fs: %.300s\n", w, h, png.size(), first, s,
                a.c_str());
    if (FILE* f = std::fopen("vision.png", "wb")) {
        std::fwrite(png.data(), 1, png.size(), f);
        std::fclose(f);
    }
    return a.rfind("[error]", 0) == 0 ? 1 : 0;
}

}  // namespace

int main(int argc, char** argv) {
    const std::string mode = argc > 1 ? argv[1] : "";
    const std::string arg = argc > 2 ? argv[2] : "";
    if (mode == "ollama") return Ollama(arg.empty() ? "What is 7 times 8?" : arg);
    if (mode == "claude") return Claude(arg.empty() ? "What is 7 times 8?" : arg, argc > 3 ? argv[3] : "");
    if (mode == "capture") return Capture(arg.empty() ? 20 : std::stoi(arg), argc > 3 ? argv[3] : "");
    if (mode == "loopback") return Loopback();
    if (mode == "vision") return Vision(arg.empty() ? 840 : std::stoi(arg), argc > 3 ? std::stoi(argv[3]) : 640);
    if (mode == "bench") return Bench(arg, argc > 3 ? argv[3] : "");
    if (mode == "play") {
        std::atomic<bool> done{false};
        std::thread t = PlayWav(arg, &done);
        t.join();
        return 0;
    }
    if (mode == "doc") {
        const std::string text = ExtractDocumentText(arg);
        std::printf("chars: %zu\n%s\n", text.size(), text.substr(0, 600).c_str());
        return text.empty() ? 1 : 0;
    }
    if (mode == "screenshot") return Screenshot(arg.empty() ? "selftest.png" : arg);
    std::printf("usage: selftest ollama|claude|capture|screenshot [arg]\n");
    return 2;
}
