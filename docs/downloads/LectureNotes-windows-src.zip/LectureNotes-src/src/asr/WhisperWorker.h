#pragma once

#include <atomic>
#include <cstdint>
#include <deque>
#include <functional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

struct whisper_context;

#include "Speaker.h"

class RingBuffer;
class TranscriptStore;

// Owns a single shared whisper_context and a worker thread that alternates
// between the "Them" and "Me" ring buffers, running whisper inference on
// 8-second windows and appending resulting segments to a TranscriptStore.
class WhisperWorker {
public:
    WhisperWorker(std::string modelPath, RingBuffer& them, RingBuffer& me, TranscriptStore& store);
    ~WhisperWorker();

    WhisperWorker(const WhisperWorker&) = delete;
    WhisperWorker& operator=(const WhisperWorker&) = delete;

    // Loads the whisper model (failing gracefully with a clear error if the
    // model file doesn't exist) and spawns the worker thread.
    bool start();

    // Signals the worker thread to stop and joins it.
    void stop();

    bool isRunning() const { return running_.load(std::memory_order_acquire); }
    const std::string& lastError() const { return lastError_; }

    // Called from the worker thread whenever any kept (non-hallucinated,
    // non-duplicate) segment is appended, from either speaker -- questions
    // can come from what you're listening to ("Them") or something you
    // ask out loud yourself ("Me"), so both are offered to the callback;
    // it's up to the caller (App's question-detection) to decide what
    // counts as a question worth answering.
    void setOnSegment(std::function<void(Speaker, const std::string&)> callback);

private:
    void run();
    void processWindow(std::vector<float>& pending, Speaker speaker);

    std::string modelPath_;
    RingBuffer& them_;
    RingBuffer& me_;
    TranscriptStore& store_;

    whisper_context* ctx_ = nullptr;
    std::thread thread_;
    std::atomic<bool> running_{false};
    std::atomic<bool> stopRequested_{false};

    // Slow-CPU mode (see processWindow): once decoding can't keep up with
    // real time, windows are encoded with a context sized to their actual
    // length instead of Whisper's padded 30 s -- several times faster.
    bool reducedContext_ = false;
    int slowWindows_ = 0;

    std::function<void(Speaker, const std::string&)> onSegment_;

    // Last *kept* (non-hallucinated, non-duplicate) text per speaker, used
    // to collapse immediate repeats — see processWindow's hallucination
    // filtering.
    std::string lastThemText_;
    std::string lastMeText_;

    // Rolling window of recently-kept "Them" text (normalized, with
    // timestamps), used to catch acoustic crosstalk: system audio played
    // out loud through real speakers can leak into the physical
    // microphone, showing up as a "Me" segment that's actually the same
    // content Them already has. Leakage only ever flows this direction
    // (system audio -> mic), never the reverse, so only Me segments are
    // checked against this.
    std::deque<std::pair<int64_t, std::string>> recentThemNormalized_;

    std::string lastError_;
};
