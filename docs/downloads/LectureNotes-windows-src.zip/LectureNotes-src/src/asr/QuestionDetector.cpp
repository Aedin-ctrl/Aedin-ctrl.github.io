#include "QuestionDetector.h"

#include <algorithm>
#include <cctype>
#include <sstream>
#include <vector>

namespace {

// Lowercase, letters/digits/apostrophes kept, everything else a space.
std::string Normalize(const std::string& text) {
    std::string out;
    for (unsigned char c : text) {
        out += (std::isalnum(c) || c == '\'') ? static_cast<char>(std::tolower(c)) : ' ';
    }
    return out;
}

std::vector<std::string> Words(const std::string& text) {
    std::istringstream in(Normalize(text));
    std::vector<std::string> words;
    for (std::string w; in >> w;) words.push_back(w);
    return words;
}

// The last sentence of the question: whisper segments often carry a lead-in
// ("You don't want that. So how do you do -- what do you do now?").
std::string LastSentence(const std::string& question) {
    std::string q = question;
    while (!q.empty() && (q.back() == '?' || std::isspace(static_cast<unsigned char>(q.back())))) q.pop_back();
    const size_t cut = q.find_last_of(".!?");
    return cut == std::string::npos ? q : q.substr(cut + 1);
}

bool EndsWith(const std::string& s, const std::string& suffix) {
    return s.size() >= suffix.size() && s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}

}  // namespace

namespace QuestionDetector {

bool looksLikeQuestion(const std::string& text) {
    return text.find('?') != std::string::npos;
}

std::string extractQuestion(const std::string& text) {
    size_t pos = text.rfind('?');
    if (pos == std::string::npos) {
        return text;
    }
    return text.substr(0, pos + 1);
}

bool isWorthAnswering(const std::string& question) {
    const std::string sentence = LastSentence(question);
    const std::vector<std::string> words = Words(sentence);
    if (words.empty()) return false;

    // Tag questions: a statement with a check-in tacked on after a comma
    // ("That's possible, right?"). The comma matters: without it these words
    // end real either/or questions ("Does it point left or right?", "Is the
    // field zero, yes or no?").
    std::string lowered;
    for (unsigned char c : sentence) lowered += static_cast<char>(std::tolower(c));
    while (!lowered.empty() && (std::isspace(static_cast<unsigned char>(lowered.back())) || lowered.back() == '?')) {
        lowered.pop_back();
    }
    static const char* kTags[] = {", right", ", isn't it", ", aren't they", ", don't you", ", didn't it",
                                  ", isn't that", ", no", ", okay", ", ok", ", yes", ", huh", ", eh"};
    for (const char* tag : kTags) {
        if (EndsWith(lowered, tag)) return false;
    }

    // Leading interjections don't change what's being asked ("Ah, did you
    // see it?" is still "did you see it").
    static const char* kInterjections[] = {"ah", "oh", "um", "uh", "so", "okay", "ok", "well", "now", "and", "but"};
    size_t skip = 0;
    while (skip + 1 < words.size() &&
           std::any_of(std::begin(kInterjections), std::end(kInterjections),
                       [&](const char* w) { return words[skip] == w; })) {
        ++skip;
    }
    std::string core;
    for (size_t i = skip; i < words.size(); ++i) core += (core.empty() ? "" : " ") + words[i];

    // Stock classroom check-ins.
    static const char* kFiller[] = {"you see", "see", "you ready", "are you ready", "ready", "did you see it",
                                    "did you see that", "you see that", "see that", "got it", "you got it",
                                    "any questions", "questions", "you know", "right", "okay", "ok", "yes",
                                    "no", "huh", "remember", "you remember", "makes sense", "does that make sense",
                                    "is that clear", "amazing", "why not", "what else"};
    for (const char* f : kFiller) {
        if (core == f) return false;
    }
    // Check-ins that carry a few extra words ("Are you ready for that?",
    // "Did you see the spark?", "You happy with the light?").
    static const char* kFillerPrefixes[] = {"did you see ", "are you ready", "you ready ", "you see ",
                                            "you happy ", "are you happy ", "everybody happy", "you guys see "};
    for (const char* f : kFillerPrefixes) {
        if (core.rfind(f, 0) == 0) return false;
    }

    // Addressed to someone by name at the end ("..., Marcos?"): a comma, then
    // a single capitalized word that ends the question.
    {
        std::string trimmed = sentence;
        while (!trimmed.empty() && (trimmed.back() == '?' || std::isspace(static_cast<unsigned char>(trimmed.back())))) {
            trimmed.pop_back();
        }
        const size_t comma = trimmed.rfind(',');
        if (comma != std::string::npos) {
            const std::string tail = trimmed.substr(comma + 1);
            const size_t start = tail.find_first_not_of(' ');
            if (start != std::string::npos && tail.find(' ', start) == std::string::npos &&
                std::isupper(static_cast<unsigned char>(tail[start])) && tail.size() - start > 2) {
                return false;
            }
        }
    }

    // Addressed to someone by name ("Marcos, do I have all my lights on?"):
    // a capitalized first word followed directly by a comma, unless it's a
    // common sentence opener ("Next, what is the current?").
    const size_t firstWordStart = sentence.find_first_not_of(" \t\"'-");
    if (firstWordStart != std::string::npos && std::isupper(static_cast<unsigned char>(sentence[firstWordStart]))) {
        const size_t comma = sentence.find(',', firstWordStart);
        const size_t space = sentence.find(' ', firstWordStart);
        if (comma != std::string::npos && (space == std::string::npos || comma < space)) {
            static const char* kOpeners[] = {
                "so", "okay", "ok", "now", "well", "alright", "and", "but", "then", "yes", "no", "right",
                "good", "fine", "look", "remember", "first", "second", "third", "next", "finally", "lastly",
                "also", "again", "here", "suppose", "anyway", "however", "therefore", "thus", "hence",
                "actually", "basically", "instead", "otherwise", "similarly", "obviously", "clearly", "sure",
                "great", "perfect", "excellent", "wait", "listen", "everyone", "class", "folks", "guys",
                "ah", "oh", "um", "uh", "hmm", "today", "remember", "meanwhile", "besides", "likewise"};
            const std::string first = words.front();
            if (std::none_of(std::begin(kOpeners), std::end(kOpeners),
                             [&](const char* o) { return first == o; })) {
                return false;
            }
        }
    }

    // Too short to have anything to answer ("You see?", "Really?"), unless
    // it carries a number ("I two?").
    const bool hasDigit = std::any_of(core.begin(), core.end(), [](char c) { return std::isdigit(c); });
    return words.size() - skip >= 3 || hasDigit;
}

std::string unpunctuatedQuestion(const std::string& text) {
    if (text.find('?') != std::string::npos) return "";
    std::string lower;
    for (unsigned char c : text) lower += static_cast<char>(std::tolower(c));
    // Dots and commas between digits are numbers ("0.2 tesla", "1,000 W"),
    // not punctuation -- physics lectures are full of them.
    bool noPunctuation = true;
    for (size_t i = 0; i < lower.size() && noPunctuation; ++i) {
        const char c = lower[i];
        if (c != '.' && c != ',' && c != '!' && c != ';' && c != ':') continue;
        const bool numeric = (c == '.' || c == ',') && i > 0 && i + 1 < lower.size() &&
                             std::isdigit(static_cast<unsigned char>(lower[i - 1])) &&
                             std::isdigit(static_cast<unsigned char>(lower[i + 1]));
        if (!numeric) noPunctuation = false;
    }

    // Phrases like "how much"/"what happens" are common inside statements
    // ("that tells you how much current flows"), so mid-segment in an
    // unpunctuated chunk only the direct question openers count.
    struct Phrase {
        const char* text;
        bool directOpener;
    };
    static const Phrase kPhrases[] = {
        {"what is the ", true}, {"what's the ", true},  {"what are the ", true}, {"which way ", true},
        {"which direction ", true}, {"why does ", true}, {"why is ", true},     {"how much ", false},
        {"how many ", false},   {"how far ", false},    {"how long ", false},    {"how fast ", false},
        {"how big ", false},    {"what happens ", false},
    };
    size_t best = std::string::npos;
    for (const Phrase& phrase : kPhrases) {
        for (size_t pos = lower.find(phrase.text); pos != std::string::npos; pos = lower.find(phrase.text, pos + 1)) {
            // Start of a sentence: beginning of the segment, or after . or !
            size_t before = pos;
            while (before > 0 && lower[before - 1] == ' ') --before;
            const bool sentenceStart = before == 0 || lower[before - 1] == '.' || lower[before - 1] == '!';
            if ((sentenceStart || (noPunctuation && phrase.directOpener)) && pos < best) best = pos;
        }
    }
    if (best == std::string::npos) return "";

    std::string question = text.substr(best);
    while (!question.empty() && (std::isspace(static_cast<unsigned char>(question.back())) ||
                                 question.back() == '.' || question.back() == '!')) {
        question.pop_back();
    }
    // Trailing check-ins that got glued on ("...from the battery you see okay").
    // Not " right": it ends real questions ("...to the left or to the right").
    static const char* kTrailing[] = {" you see", " okay", " ok", " alright", " yeah", " huh"};
    for (bool trimmed = true; trimmed;) {
        trimmed = false;
        std::string q;
        for (unsigned char c : question) q += static_cast<char>(std::tolower(c));
        for (const char* t : kTrailing) {
            if (EndsWith(q, t)) {
                question.resize(question.size() - std::string(t).size());
                trimmed = true;
                break;
            }
        }
    }
    if (!question.empty()) question[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(question[0])));
    return question + "?";
}

}  // namespace QuestionDetector
