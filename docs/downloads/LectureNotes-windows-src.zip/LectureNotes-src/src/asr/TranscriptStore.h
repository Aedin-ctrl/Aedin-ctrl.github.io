#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

#include "Speaker.h"

struct TranscriptSegment {
    Speaker speaker;
    std::string text;
    int64_t timestampMs;
};

// Mutex-guarded, append-only store of speaker-tagged transcript segments.
class TranscriptStore {
public:
    void append(Speaker speaker, const std::string& text);
    std::vector<TranscriptSegment> snapshot() const;

    // Bumped on every append(). The UI polls this (a cheap atomic read)
    // every frame and only pays for a fresh snapshot() -- a full vector
    // deep-copy under a mutex -- when it's actually changed, instead of
    // copying the whole (potentially hour-long) transcript on every
    // single redraw regardless of whether anything new was said.
    uint64_t version() const { return version_.load(std::memory_order_acquire); }

private:
    mutable std::mutex mutex_;
    std::vector<TranscriptSegment> segments_;
    std::atomic<uint64_t> version_{0};
};
