#pragma once

enum class Speaker { Me, Them };

inline const char* speakerLabel(Speaker s) {
    switch (s) {
        case Speaker::Me: return "Me";
        case Speaker::Them: return "Them";
    }
    return "?";
}
