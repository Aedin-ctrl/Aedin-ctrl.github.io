#pragma once

#include <string>

// Heuristic-only: good enough since whisper.cpp reliably produces terminal
// punctuation for English models. No NLP -- just "does this segment
// contain a question mark".
//
// Checking anywhere in the segment (not just at the very end) matters
// because whisper.cpp often merges a spoken question together with
// whatever was said right after it into one segment, e.g.
// "What is your biggest weakness? Most people say..." -- the trailing
// continuation would otherwise hide a real question that ended mid-segment.
namespace QuestionDetector {
bool looksLikeQuestion(const std::string& text);

// Returns just the question part: everything up through the last "?" in
// the text, dropping any trailing continuation after it. Returns the
// input unchanged if it has no "?" at all.
std::string extractQuestion(const std::string& text);

// False for classroom filler that has a "?" but isn't worth answering (or
// spending a Claude call on): tag questions ("..., right?", "isn't it?"),
// stock check-ins ("You see?", "You ready?", "Did you see it?"), very short
// questions with nothing to answer, and questions addressed to a named
// person ("Marcos, do I have all my lights on?"). Judged on the final
// sentence of `question` (extractQuestion's output). In a real 50-minute
// lecture, 10 of 15 detected questions were this kind of filler.
bool isWorthAnswering(const std::string& question);

// Catches questions whisper transcribed without a "?" -- it drops
// punctuation entirely on some chunks that start mid-sentence ("6 volt
// battery what is the total current from the battery you see okay").
// Returns the question (from its wh-phrase, trailing check-ins removed,
// with a "?" added), or "" if there isn't one. Deliberately narrow: the
// wh-phrase must start a sentence, or the segment must have no punctuation
// at all -- in a real 50-minute lecture that matched one real question and
// none of the statements containing "how much"/"what happens".
std::string unpunctuatedQuestion(const std::string& text);
}
