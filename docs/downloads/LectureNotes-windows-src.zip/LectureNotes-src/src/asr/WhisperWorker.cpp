#include "WhisperWorker.h"

#include <sys/stat.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <ctime>

#include "util/Log.h"
#include <string>
#include <vector>

#include "whisper.h"
#include "audio/RingBuffer.h"
#include "TranscriptStore.h"
#include "util/CpuShare.h"

namespace {
constexpr size_t kWindowSize = 128000;  // 8s @ 16kHz
constexpr size_t kOverlapSize = 16000;  // 1s @ 16kHz

// Below this RMS, treat the window as silence and skip inference entirely
// rather than handing Whisper near-zero audio. Whisper.cpp doesn't expose
// per-segment no-speech probability in this version (whisper_full_params::
// no_speech_thold is marked "TODO: not implemented" in whisper.h), so this
// simple energy gate stands in for that -- it's also the standard approach
// used by whisper.cpp's own examples/stream demo (a lightweight VAD check
// before running inference at all).
constexpr float kSilenceRmsThreshold = 0.008f;

bool fileExists(const std::string& path) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0;
}

std::string readFile(const std::string& path) {
    std::string out;
    if (FILE* f = std::fopen(path.c_str(), "rb")) {
        char buf[256];
        size_t n;
        while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
        std::fclose(f);
    }
    return out;
}

std::string baseName(const std::string& path) {
    const size_t slash = path.find_last_of("/\\");
    return slash == std::string::npos ? path : path.substr(slash + 1);
}

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) return std::string();
    size_t end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

float computeRms(const float* data, size_t n) {
    double sumSq = 0.0;
    for (size_t i = 0; i < n; ++i) {
        sumSq += static_cast<double>(data[i]) * data[i];
    }
    return static_cast<float>(std::sqrt(sumSq / static_cast<double>(n)));
}

// Lowercased, punctuation-collapsed-to-spaces form, used both for matching
// against the known-hallucination phrase list and for detecting immediate
// repeats (Whisper tends to hallucinate the *same* filler word over and
// over across consecutive windows of silence, not a different one each
// time).
std::string normalizeForCompare(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (std::isalnum(static_cast<unsigned char>(c))) {
            out += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        } else if (!out.empty() && out.back() != ' ') {
            out += ' ';
        }
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

// Catches the well-documented Whisper failure mode where feeding it
// silence or near-silent/non-speech audio produces confident-looking but
// fabricated short filler text (widely reported for both openai/whisper
// and whisper.cpp -- "you" is the single most common one) instead of
// recognizing there's nothing to transcribe.
bool looksLikeHallucination(const std::string& trimmedText) {
    // Non-speech sound-effect-style captions: Whisper's convention is to
    // wrap the whole segment in parens/brackets, e.g. "(sighs)",
    // "(wind blowing)", "[BLANK_AUDIO]" -- never real spoken content.
    if (trimmedText.size() >= 2) {
        const char first = trimmedText.front();
        const char last = trimmedText.back();
        if ((first == '(' && last == ')') || (first == '[' && last == ']')) {
            return true;
        }
    }

    static const std::vector<std::string> kKnownHallucinations = {
        "you",
        "thank you",
        "thanks for watching",
        "thank you for watching",
        "please subscribe",
        "bye",
        "bye bye",
        "the",
        "um",
        "uh",
    };
    const std::string normalized = normalizeForCompare(trimmedText);
    for (const auto& phrase : kKnownHallucinations) {
        if (normalized == phrase) {
            return true;
        }
    }
    return false;
}

// How recently a "Them" segment has to have appeared to still count as a
// plausible source of acoustic leakage into the mic, and how much of a
// "Me" segment's words have to overlap with it to call it leakage rather
// than a coincidental shared word or two.
constexpr int64_t kCrosstalkWindowMs = 20000;
constexpr float kCrosstalkOverlapThreshold = 0.6f;

std::vector<std::string> splitWords(const std::string& normalized) {
    std::vector<std::string> words;
    size_t pos = 0;
    while (pos < normalized.size()) {
        size_t next = normalized.find(' ', pos);
        if (next == std::string::npos) next = normalized.size();
        if (next > pos) words.push_back(normalized.substr(pos, next - pos));
        pos = next + 1;
    }
    return words;
}

// Fraction of the shorter segment's words that also appear in the other
// segment -- robust to the two streams chunking the same spoken audio
// into differently-sized windows/segments (a short leaked snippet fully
// contained in a longer Them segment should still score high).
float wordOverlapRatio(const std::string& normA, const std::string& normB) {
    std::vector<std::string> wordsA = splitWords(normA);
    std::vector<std::string> wordsB = splitWords(normB);
    if (wordsA.empty() || wordsB.empty()) return 0.0f;

    size_t overlap = 0;
    for (const auto& wa : wordsA) {
        for (const auto& wb : wordsB) {
            if (wa == wb) {
                ++overlap;
                break;
            }
        }
    }
    size_t denom = std::min(wordsA.size(), wordsB.size());
    return denom > 0 ? static_cast<float>(overlap) / static_cast<float>(denom) : 0.0f;
}
} // namespace

WhisperWorker::WhisperWorker(std::string modelPath, RingBuffer& them, RingBuffer& me, TranscriptStore& store)
    : modelPath_(std::move(modelPath)), them_(them), me_(me), store_(store) {}

WhisperWorker::~WhisperWorker() {
    stop();
}

void WhisperWorker::setOnSegment(std::function<void(Speaker, const std::string&)> callback) {
    onSegment_ = std::move(callback);
}

bool WhisperWorker::start() {
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }

    lastError_.clear();

    if (!fileExists(modelPath_)) {
        lastError_ = "Whisper model not found at " + modelPath_ +
                     ". Run scripts/fetch_model.sh to download it first.";
        return false;
    }

    whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = true;

    // A previous session found this PC too slow for the main model (see
    // processWindow): start straight on the fast one.
    // The marker holds the name of the main model that was too slow, so a
    // different (faster) main model gets its own chance. It lapses after a
    // week, in case the slow stretch was a one-off (a virus scan, battery saver).
    std::string path = modelPath_;
    const std::string marker = fallbackModelPath_ + ".preferred";
    struct stat markerStat{};
    const bool markerFresh = stat(marker.c_str(), &markerStat) == 0 &&
                             std::time(nullptr) - markerStat.st_mtime < 7 * 24 * 60 * 60;
    if (!fallbackModelPath_.empty() && fileExists(fallbackModelPath_) && markerFresh &&
        readFile(marker) == baseName(modelPath_)) {
        path = fallbackModelPath_;
        switchedToFallback_ = true;
    }
    LogLine("whisper: loading %s", path.c_str());
    ctx_ = whisper_init_from_file_with_params(path.c_str(), cparams);
    warmedUp_ = false;
    if (!ctx_) {
        lastError_ = "Failed to load whisper model from " + modelPath_ + " (whisper_init_from_file_with_params returned null).";
        return false;
    }

    stopRequested_.store(false, std::memory_order_release);
    running_.store(true, std::memory_order_release);
    thread_ = std::thread(&WhisperWorker::run, this);
    return true;
}

void WhisperWorker::stop() {
    if (!running_.load(std::memory_order_acquire)) {
        return;
    }

    stopRequested_.store(true, std::memory_order_release);
    if (thread_.joinable()) {
        thread_.join();
    }
    running_.store(false, std::memory_order_release);

    if (ctx_) {
        whisper_free(ctx_);
        ctx_ = nullptr;
    }
}

void WhisperWorker::run() {
    std::vector<float> themPending;
    std::vector<float> mePending;
    std::vector<float> drainBuf(32000); // 2s @16kHz scratch for draining ring buffers

    themPending.reserve(kWindowSize * 2);
    mePending.reserve(kWindowSize * 2);

    while (!stopRequested_.load(std::memory_order_acquire)) {
        size_t n;
        while ((n = them_.read(drainBuf.data(), drainBuf.size())) > 0) {
            themPending.insert(themPending.end(), drainBuf.begin(), drainBuf.begin() + static_cast<long>(n));
        }
        while ((n = me_.read(drainBuf.data(), drainBuf.size())) > 0) {
            mePending.insert(mePending.end(), drainBuf.begin(), drainBuf.begin() + static_cast<long>(n));
        }

        // Prioritize "Them" so question detection (wired in M2) stays prompt.
        if (themPending.size() >= kWindowSize) {
            processWindow(themPending, Speaker::Them);
        }
        if (mePending.size() >= kWindowSize) {
            processWindow(mePending, Speaker::Me);
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
}

void WhisperWorker::processWindow(std::vector<float>& pending, Speaker speaker) {
    size_t total = pending.size();
    const float* windowStart = pending.data() + (total - kWindowSize);

    // Silence gate: a window with essentially no audio energy (e.g. an
    // audio-capture stream that isn't actually receiving anything -- the
    // most common cause being system output not routed to it) is skipped
    // entirely rather than handed to Whisper, which otherwise tends to
    // hallucinate short filler text ("you" being the classic case) on
    // near-zero input.
    if (computeRms(windowStart, kWindowSize) >= kSilenceRmsThreshold) {
        whisper_full_params wparams = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
        wparams.print_progress = false;
        wparams.print_special = false;
        wparams.print_realtime = false;
        wparams.print_timestamps = false;
        wparams.translate = false;
        wparams.no_context = true;
        wparams.single_segment = false;
        wparams.language = "en";
        unsigned int hw = std::thread::hardware_concurrency();
#ifdef _WIN32
        // CPU-only on Windows: every core but one, except while the local
        // answer model is generating -- then it gets half (see
        // OllamaClient.cpp), so a question mid-lecture can't stall this.
        const unsigned mine = CpuShare::localModelBusy.load() > 0 ? hw - hw / 2 : hw - 1;
        wparams.n_threads = static_cast<int>(hw > 1 ? std::min(mine, 8u) : 1u);
#else
        wparams.n_threads = static_cast<int>(hw > 0 ? std::min(hw, 4u) : 4u);
#endif
        if (reducedContext_) {
            // 1500 frames = 30 s; an 8 s window needs ~400. Rounded up for margin.
            wparams.audio_ctx = 512;
        }

        const bool sharedAtStart = CpuShare::localModelBusy.load() > 0;
        const auto started = std::chrono::steady_clock::now();
        int rc = whisper_full(ctx_, wparams, windowStart, static_cast<int>(kWindowSize));
        const bool sharedCpu = sharedAtStart || CpuShare::localModelBusy.load() > 0;
        const double seconds =
            std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
        LogLine("whisper: %s window decoded in %.2fs (%s%s)", speaker == Speaker::Them ? "them" : "me", seconds,
                switchedToFallback_ ? "fast model" : "main model", reducedContext_ ? ", reduced context" : "");
        // Two streams (lecture + mic) share one decoder, so anything over
        // ~40% of a window's duration means windows start queuing and audio
        // gets dropped. Two slow windows in a row: first switch to the
        // reduced context (if not already), then to the smaller fallback model.
        // Not counted: the first decode after loading a model (one-time setup:
        // weight repacking, allocations) and decodes that shared the CPU with
        // an answer being generated (a few seconds, not this PC's real pace).
        const bool warmup = !warmedUp_;
        warmedUp_ = true;
        if (!warmup && !sharedCpu) slowWindows_ = seconds > (kWindowSize / 16000.0) * 0.4 ? slowWindows_ + 1 : 0;
        // Already in reduced-context mode, one slow window is evidence
        // enough: every extra one drops another 8 s of lecture.
        if (slowWindows_ >= (reducedContext_ ? 1 : 2)) {
            slowWindows_ = 0;
            if (!reducedContext_) {
                reducedContext_ = true;
                LogLine("whisper: %.1fs for an 8s window; switching to reduced context", seconds);
            } else if (!switchedToFallback_ && !fallbackModelPath_.empty() && fileExists(fallbackModelPath_)) {
                whisper_context_params cparams = whisper_context_default_params();
                if (whisper_context* faster = whisper_init_from_file_with_params(fallbackModelPath_.c_str(), cparams)) {
                    whisper_free(ctx_);
                    ctx_ = faster;
                    switchedToFallback_ = true;
                    warmedUp_ = false;
                    // Remember for next time, so this PC starts on the fast model.
                    if (FILE* marker = std::fopen((fallbackModelPath_ + ".preferred").c_str(), "wb")) {
                        const std::string name = baseName(modelPath_);
                        std::fwrite(name.data(), 1, name.size(), marker);
                        std::fclose(marker);
                    }
                    LogLine("whisper: still %.1fs per window; switched to %s", seconds, fallbackModelPath_.c_str());
                }
            }
        }
        if (rc == 0) {
            int n = whisper_full_n_segments(ctx_);
            std::string& lastText = (speaker == Speaker::Them) ? lastThemText_ : lastMeText_;
            for (int i = 0; i < n; ++i) {
                const char* text = whisper_full_get_segment_text(ctx_, i);
                if (!text) continue;
                std::string trimmed = trim(text);
                if (trimmed.empty()) continue;
                if (looksLikeHallucination(trimmed)) continue;

                std::string normalized = normalizeForCompare(trimmed);
                if (!normalized.empty() && normalized == lastText) {
                    // Same text as last time, back to back -- Whisper
                    // repeating itself is usually still hallucination
                    // that slipped past the checks above, not a person
                    // actually repeating a whole sentence verbatim.
                    continue;
                }

                const int64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
                                          std::chrono::system_clock::now().time_since_epoch())
                                          .count();

                // Drop expired entries regardless of which speaker this
                // window is for, so the deque doesn't grow unbounded
                // during long stretches with no "Them" speech at all.
                while (!recentThemNormalized_.empty() &&
                       nowMs - recentThemNormalized_.front().first > kCrosstalkWindowMs) {
                    recentThemNormalized_.pop_front();
                }

                if (speaker == Speaker::Me) {
                    bool isCrosstalk = false;
                    for (const auto& entry : recentThemNormalized_) {
                        if (wordOverlapRatio(normalized, entry.second) >= kCrosstalkOverlapThreshold) {
                            isCrosstalk = true;
                            break;
                        }
                    }
                    if (isCrosstalk) {
                        // This is almost certainly system audio the mic
                        // picked up acoustically (speakers, not
                        // headphones) rather than something the user
                        // actually said -- "Them" already has it.
                        continue;
                    }
                }

                lastText = normalized;
                if (speaker == Speaker::Them && !normalized.empty()) {
                    recentThemNormalized_.push_back({nowMs, normalized});
                }

                store_.append(speaker, trimmed);
                if (onSegment_) {
                    onSegment_(speaker, trimmed);
                }
            }
        }
    }

    // Keep the last second as overlap for the next window; drop the rest.
    if (pending.size() > kOverlapSize) {
        std::vector<float> tail(pending.end() - static_cast<long>(kOverlapSize), pending.end());
        pending.swap(tail);
    }
}
