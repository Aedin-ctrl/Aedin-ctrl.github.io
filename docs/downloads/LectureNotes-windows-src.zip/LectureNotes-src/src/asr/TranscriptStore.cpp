#include "TranscriptStore.h"

#include <chrono>

void TranscriptStore::append(Speaker speaker, const std::string& text) {
    int64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
                        std::chrono::system_clock::now().time_since_epoch())
                        .count();
    std::lock_guard<std::mutex> lock(mutex_);
    segments_.push_back(TranscriptSegment{speaker, text, nowMs});
    version_.fetch_add(1, std::memory_order_release);
}

std::vector<TranscriptSegment> TranscriptStore::snapshot() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return segments_;
}
