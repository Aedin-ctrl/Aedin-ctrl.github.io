#pragma once

// Small Windows helpers shared by the Windows-only sources.

#include <string>
#include <vector>

namespace WinUtil {

std::wstring Widen(const std::string& utf8);
std::string Narrow(const std::wstring& wide);

// Known folders, UTF-8, no trailing separator. Empty on failure.
std::string LocalAppDataDir();   // %LOCALAPPDATA%
std::string DocumentsDir();      // the user's Documents (may be OneDrive-redirected)
std::string UserProfileDir();    // %USERPROFILE%
std::string TempDir();           // %TEMP%

// %LOCALAPPDATA%\LectureNotes\<sub>, created if missing.
std::string AppDataSubdir(const std::string& sub);

bool FileExists(const std::string& path);
bool CreateDirectories(const std::string& path);

// Runs a program hidden (no console window) and waits for it. Returns the
// exit code, or -1 if it couldn't be started. `args` are quoted for the
// Windows command-line parser.
int RunHidden(const std::string& program, const std::vector<std::string>& args, unsigned long timeoutMs = 0xFFFFFFFF);
// Starts a program detached (doesn't wait). `hidden` hides console windows.
bool Launch(const std::string& program, const std::vector<std::string>& args, bool hidden);

// Quotes one argument per the rules CommandLineToArgvW / the CRT use.
std::wstring QuoteArg(const std::wstring& arg);

void OpenUrl(const std::string& url);

// Appends a timestamped line to %LOCALAPPDATA%\LectureNotes\Logs\app.log
// (printf-style), so problems on someone else's PC can be diagnosed.
void Log(const char* format, ...);
std::string LogPath();

}  // namespace WinUtil
