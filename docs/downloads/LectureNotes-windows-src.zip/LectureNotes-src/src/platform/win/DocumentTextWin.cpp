// Text extraction for the "+" documents drawer on Windows (PDF via PDFium,
// Word .docx via its XML, plain text/Markdown as UTF-8).

#include "platform/win/DocumentTextWin.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>

#include "platform/win/WinUtil.h"

namespace {


// PDFium (BSD-3, shipped next to the exe) for PDF text, loaded on demand so a
// missing DLL only disables PDFs instead of stopping the app from starting.
struct Pdfium {
    using InitFn = void (*)();
    using LoadDocFn = void* (*)(const char*, const char*);
    using CloseDocFn = void (*)(void*);
    using PageCountFn = int (*)(void*);
    using LoadPageFn = void* (*)(void*, int);
    using ClosePageFn = void (*)(void*);
    using TextLoadFn = void* (*)(void*);
    using TextCloseFn = void (*)(void*);
    using CountCharsFn = int (*)(void*);
    using GetTextFn = int (*)(void*, int, int, unsigned short*);

    bool loaded = false;
    InitFn init = nullptr;
    LoadDocFn loadDocument = nullptr;
    CloseDocFn closeDocument = nullptr;
    PageCountFn pageCount = nullptr;
    LoadPageFn loadPage = nullptr;
    ClosePageFn closePage = nullptr;
    TextLoadFn textLoad = nullptr;
    TextCloseFn textClose = nullptr;
    CountCharsFn countChars = nullptr;
    GetTextFn getText = nullptr;

    bool ensure() {
        if (loaded) return true;
        HMODULE dll = LoadLibraryW(L"pdfium.dll");
        if (!dll) return false;
        auto get = [&](const char* name) { return reinterpret_cast<void*>(GetProcAddress(dll, name)); };
        init = reinterpret_cast<InitFn>(get("FPDF_InitLibrary"));
        loadDocument = reinterpret_cast<LoadDocFn>(get("FPDF_LoadDocument"));
        closeDocument = reinterpret_cast<CloseDocFn>(get("FPDF_CloseDocument"));
        pageCount = reinterpret_cast<PageCountFn>(get("FPDF_GetPageCount"));
        loadPage = reinterpret_cast<LoadPageFn>(get("FPDF_LoadPage"));
        closePage = reinterpret_cast<ClosePageFn>(get("FPDF_ClosePage"));
        textLoad = reinterpret_cast<TextLoadFn>(get("FPDFText_LoadPage"));
        textClose = reinterpret_cast<TextCloseFn>(get("FPDFText_ClosePage"));
        countChars = reinterpret_cast<CountCharsFn>(get("FPDFText_CountChars"));
        getText = reinterpret_cast<GetTextFn>(get("FPDFText_GetText"));
        loaded = init && loadDocument && closeDocument && pageCount && loadPage && closePage && textLoad &&
                 textClose && countChars && getText;
        if (loaded) init();
        return loaded;
    }
};

std::string ExtractPdfText(const std::string& path) {
    static Pdfium pdf;
    if (!pdf.ensure()) return "";
    void* doc = pdf.loadDocument(path.c_str(), nullptr);  // PDFium takes UTF-8 paths on Windows
    if (!doc) return "";
    std::wstring text;
    const int pages = pdf.pageCount(doc);
    for (int i = 0; i < pages; ++i) {
        void* page = pdf.loadPage(doc, i);
        if (!page) continue;
        if (void* tp = pdf.textLoad(page)) {
            const int n = pdf.countChars(tp);
            if (n > 0) {
                std::vector<unsigned short> buf(static_cast<size_t>(n) + 1);
                const int written = pdf.getText(tp, 0, n, buf.data());
                if (written > 1) text.append(reinterpret_cast<const wchar_t*>(buf.data()), written - 1);
                text += L"\n";
            }
            pdf.textClose(tp);
        }
        pdf.closePage(page);
    }
    pdf.closeDocument(doc);
    return WinUtil::Narrow(text);
}

// Word .docx: a zip whose text lives in word/document.xml. tar.exe (built into
// Windows 10 1803+) extracts it; paragraphs and tabs are kept, tags dropped.
std::string ExtractDocxText(const std::string& path) {
    const std::string dir = WinUtil::TempDir() + "\\lecturenotes-docx";
    std::error_code ec;
    std::filesystem::remove_all(std::filesystem::path(WinUtil::Widen(dir)), ec);
    WinUtil::CreateDirectories(dir);
    wchar_t sys[MAX_PATH];
    GetSystemDirectoryW(sys, MAX_PATH);
    const std::string tar = WinUtil::Narrow(sys) + "\\tar.exe";
    if (WinUtil::RunHidden(tar, {"-xf", path, "-C", dir, "word/document.xml"}, 15000) != 0) return "";
    std::ifstream in(std::filesystem::path(WinUtil::Widen(dir + "\\word\\document.xml")), std::ios::binary);
    std::stringstream ss;
    ss << in.rdbuf();
    const std::string xml = ss.str();
    std::string text;
    text.reserve(xml.size() / 4);
    for (size_t i = 0; i < xml.size();) {
        if (xml[i] == '<') {
            const size_t end = xml.find('>', i);
            if (end == std::string::npos) break;
            const std::string tag = xml.substr(i + 1, end - i - 1);
            if (tag == "/w:p") text += '\n';
            else if (tag.rfind("w:tab", 0) == 0 || tag.rfind("w:br", 0) == 0) text += tag[2] == 't' ? '\t' : '\n';
            i = end + 1;
        } else if (xml[i] == '&') {
            static const std::pair<const char*, char> kEntities[] = {
                {"&amp;", '&'}, {"&lt;", '<'}, {"&gt;", '>'}, {"&quot;", '"'}, {"&apos;", '\''}};
            bool matched = false;
            for (const auto& [entity, ch] : kEntities) {
                const size_t n = std::strlen(entity);
                if (xml.compare(i, n, entity) == 0) {
                    text += ch;
                    i += n;
                    matched = true;
                    break;
                }
            }
            if (!matched) text += xml[i++];
        } else {
            text += xml[i++];
        }
    }
    std::filesystem::remove_all(std::filesystem::path(WinUtil::Widen(dir)), ec);
    return text;
}

}  // namespace

// Plain text/markdown as UTF-8, PDFs through PDFium, Word .docx via its XML.
// (Old binary .doc files aren't supported; save them as .docx or PDF.)
std::string ExtractDocumentText(const std::string& path) {
    std::string lower = path;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return std::tolower(c); });
    auto endsWith = [&](const char* ext) {
        const size_t n = std::strlen(ext);
        return lower.size() >= n && lower.compare(lower.size() - n, n, ext) == 0;
    };
    if (endsWith(".pdf")) return ExtractPdfText(path);
    if (endsWith(".docx")) return ExtractDocxText(path);
    if (endsWith(".doc")) return "";
    std::ifstream in(std::filesystem::u8path(path), std::ios::binary);
    std::stringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

