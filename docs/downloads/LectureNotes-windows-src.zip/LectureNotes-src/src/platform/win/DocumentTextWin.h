#pragma once

#include <string>

// Plain text of a document the user uploads (PDF, .docx, .txt, .md), or
// empty if it can't be read. `path` is UTF-8.
std::string ExtractDocumentText(const std::string& path);
