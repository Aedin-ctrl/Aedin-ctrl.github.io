#include "platform/win/WinUtil.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>

#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <mutex>

namespace WinUtil {

std::wstring Widen(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int n = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
    std::wstring out(static_cast<size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), out.data(), n);
    return out;
}

std::string Narrow(const std::wstring& wide) {
    if (wide.empty()) return std::string();
    const int n = WideCharToMultiByte(CP_UTF8, 0, wide.data(), static_cast<int>(wide.size()), nullptr, 0, nullptr, nullptr);
    std::string out(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.data(), static_cast<int>(wide.size()), out.data(), n, nullptr, nullptr);
    return out;
}

namespace {

std::string KnownFolder(REFKNOWNFOLDERID id) {
    PWSTR path = nullptr;
    std::string out;
    if (SUCCEEDED(SHGetKnownFolderPath(id, KF_FLAG_CREATE, nullptr, &path)) && path) {
        out = Narrow(path);
    }
    if (path) CoTaskMemFree(path);
    return out;
}

}  // namespace

std::string LocalAppDataDir() { return KnownFolder(FOLDERID_LocalAppData); }
std::string DocumentsDir() { return KnownFolder(FOLDERID_Documents); }
std::string UserProfileDir() { return KnownFolder(FOLDERID_Profile); }

std::string TempDir() {
    wchar_t buf[MAX_PATH + 1];
    const DWORD n = GetTempPathW(MAX_PATH + 1, buf);
    std::string out = (n > 0 && n <= MAX_PATH) ? Narrow(std::wstring(buf, n)) : std::string("C:\\Windows\\Temp\\");
    while (!out.empty() && (out.back() == '\\' || out.back() == '/')) out.pop_back();
    return out;
}

std::string AppDataSubdir(const std::string& sub) {
    const std::string dir = LocalAppDataDir() + "\\LectureNotes" + (sub.empty() ? "" : "\\" + sub);
    CreateDirectories(dir);
    return dir;
}

bool FileExists(const std::string& path) {
    const DWORD attrs = GetFileAttributesW(Widen(path).c_str());
    return attrs != INVALID_FILE_ATTRIBUTES;
}

bool CreateDirectories(const std::string& path) {
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(Widen(path)), ec);
    return !ec;
}

std::wstring QuoteArg(const std::wstring& arg) {
    if (!arg.empty() && arg.find_first_of(L" \t\n\v\"") == std::wstring::npos) return arg;
    std::wstring out = L"\"";
    for (size_t i = 0;; ++i) {
        size_t backslashes = 0;
        while (i < arg.size() && arg[i] == L'\\') {
            ++i;
            ++backslashes;
        }
        if (i == arg.size()) {
            out.append(backslashes * 2, L'\\');  // escape them all: a quote follows
            break;
        }
        if (arg[i] == L'"') {
            out.append(backslashes * 2 + 1, L'\\');
            out.push_back(L'"');
        } else {
            out.append(backslashes, L'\\');
            out.push_back(arg[i]);
        }
    }
    out.push_back(L'"');
    return out;
}

namespace {

std::wstring CommandLine(const std::string& program, const std::vector<std::string>& args) {
    std::wstring cmd = QuoteArg(Widen(program));
    for (const std::string& a : args) {
        cmd += L" ";
        cmd += QuoteArg(Widen(a));
    }
    return cmd;
}

}  // namespace

int RunHidden(const std::string& program, const std::vector<std::string>& args, unsigned long timeoutMs) {
    std::wstring cmd = CommandLine(program, args);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        return -1;
    }
    CloseHandle(pi.hThread);
    DWORD code = static_cast<DWORD>(-1);
    if (WaitForSingleObject(pi.hProcess, timeoutMs) == WAIT_OBJECT_0) {
        GetExitCodeProcess(pi.hProcess, &code);
    } else {
        TerminateProcess(pi.hProcess, 1);
    }
    CloseHandle(pi.hProcess);
    return static_cast<int>(code);
}

bool Launch(const std::string& program, const std::vector<std::string>& args, bool hidden) {
    std::wstring cmd = CommandLine(program, args);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    if (hidden) {
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
    }
    PROCESS_INFORMATION pi{};
    const DWORD flags = hidden ? CREATE_NO_WINDOW : CREATE_NEW_CONSOLE;
    if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE, flags, nullptr, nullptr, &si, &pi)) {
        return false;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;
}

void OpenUrl(const std::string& url) {
    ShellExecuteW(nullptr, L"open", Widen(url).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

std::string LogPath() {
    return AppDataSubdir("Logs") + "\\app.log";
}

void Log(const char* format, ...) {
    static std::mutex mutex;
    std::lock_guard<std::mutex> lock(mutex);
    FILE* f = _wfopen(Widen(LogPath()).c_str(), L"a");
    if (!f) return;
    const std::time_t now = std::time(nullptr);
    std::tm local{};
    localtime_s(&local, &now);
    char when[32];
    std::strftime(when, sizeof(when), "%Y-%m-%d %H:%M:%S", &local);
    std::fprintf(f, "%s  ", when);
    va_list args;
    va_start(args, format);
    std::vfprintf(f, format, args);
    va_end(args);
    std::fputc('\n', f);
    std::fclose(f);
}

}  // namespace WinUtil
