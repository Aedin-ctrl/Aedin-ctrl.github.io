#include "LocalLLMClient.h"

#include <atomic>
#include <mutex>
#include <thread>

#include <nlohmann/json.hpp>

#include "OllamaClient.h"
#include "Utf8.h"
#include "net/Http.h"

namespace {

// Qwen3.5 4B (2026-09-28 benchmark, experiments/ in this repo): on 12
// Physics 2 problems graded against hand-worked + Opus-verified answers it
// scored 10/12 vs llama3.2:3b's 0/12, at ~3.1GB resident -- so it still
// leaves whisper.cpp's Metal transcription the memory headroom that got
// llama3.2:3b picked originally. It's also natively multimodal, so
// VisionLLMClient uses this same model and the camera feature no longer
// needs its own ~3GB model loaded alongside it.
constexpr const char* kModelName = "qwen3.5:4b";

// "Think harder" model -- must match SetupChecker.mm's kThinkHarderModel
// exactly (that's what the optional Setup download row actually pulls).
// A meaningfully bigger, more capable model (8B vs 3B) for when the fast
// answer looks wrong and the user explicitly asks for a stronger retry --
// not kept warm/always-loaded like kModelName, since it's used rarely by
// comparison and the memory would otherwise sit idle most of the time.
constexpr const char* kThinkHarderModelName = "qwen3.5:9b";

// Keeps the model resident in memory for this long after each request,
// overriding Ollama's default ~5 minute idle-unload -- avoids paying a
// model-reload stall on the first question after a quiet stretch of
// video. Passed per-request rather than via the OLLAMA_KEEP_ALIVE env
// var so this app doesn't depend on global machine configuration.
constexpr const char* kKeepAlive = "30m";

// Typical answers run ~350 tokens (~18s at the ~21 tok/s this model gets
// alongside everything else). Occasionally it second-guesses itself on a
// multi-loop circuit and keeps going -- one benchmark answer ran 2,109
// tokens / 105s, past the timeout, so the user got an error instead of an
// answer. Capping at ~2.5x typical bounds the worst case near 45s.
constexpr int kMaxAnswerTokens = 900;

// Two things this steers away from by default, per explicit user
// feedback: (1) flat dictionary-style definitions for technical/factual
// questions -- ask it to explain like a person talking, not a textbook;
// (2) fabricating a fake personal anecdote for behavioral/personal
// questions ("tell me about a time you...") -- the model has no real
// experience to draw on, so instead of pretending it does, it should
// hand back a short outline the listener can fill in with their own.
constexpr const char* kSystemPrompt =
    "You are a live assistant listening alongside someone watching a video or "
    "lecture, or being interviewed, helping them understand or respond in the "
    "moment.\n\n"
    "1. If the question is factual, technical, or conceptual (e.g. \"how do you "
    "reverse a linked list\", \"what is X\"), explain it plainly and "
    "conversationally, the way a knowledgeable person would explain it out loud "
    "to a friend -- not a dictionary or textbook definition.\n\n"
    "2. If the question is personal or behavioral -- asking about the "
    "listener's own experience, opinions, or background (e.g. \"tell me about a "
    "time you...\", \"have you ever dealt with...\", \"what would you do "
    "if...\") -- do NOT invent a fake personal story as if you were them. "
    "Instead, give a short bulleted outline of points they could use to build "
    "their OWN real answer. For interview-style behavioral questions, a "
    "Situation / Task / Action / Result structure works well. This is only for "
    "questions aimed at the listener personally, like in an interview. A "
    "lecturer asking the room something (\"so what do you do now?\", \"how do "
    "you keep it cool?\") is a subject question: answer it under rule 1.\n\n"
    "3. Keep it short: a few sentences, or a short bullet list -- never a long "
    "essay.\n\n"
    "4. If the question gives numbers and asks for a quantity, actually work it "
    "out: write the one governing equation, plug in the values with units "
    "converted to SI, and finish with the result on its own last line, starting "
    "with \"Answer:\" (e.g. \"Answer: 3.14 V\"). Double-check the arithmetic "
    "and the exponent before stating it. Keep the explanation brief, but never "
    "stop before the final number.";

// Appended for Claude only (see systemPrompt()). Tried on the local model
// too, and its benchmark score fell from 10-11/12 to 7/12: small models
// work math out in LaTeX, and banning it cost real accuracy. The answer
// view converts leftover LaTeX/Markdown into readable text instead.
constexpr const char* kPlainTextRule =
    "\n\n5. Plain text only -- this is shown in a simple text box, so no Markdown "
    "(no **, #, or backticks) and no LaTeX (no $, \\frac, ^{}). Write math "
    "inline with Unicode: 1.2 × 10⁻⁶ F, v², √2, Δx, θ, ≈.";

// Distills raw uploaded-document text into compact, factual notes the
// model can actually fit inside its own limited context window later
// (see App::requestDocumentScan / DocumentStore::combinedContext for why
// this step exists instead of just handing the raw text straight to
// ask()). Explicitly told not to add commentary or invent anything not in
// the source material -- this output becomes the reference context every
// future question is answered against, so any hallucination here would
// silently poison every answer downstream.
constexpr const char* kSummarizePrompt =
    "You are preparing condensed background notes from documents (e.g. a resume) "
    "that will be reused later as context for answering live questions about this "
    "person's experience.\n\n"
    "Read the material and condense it into a dense, factual bullet list: name (if "
    "present), key skills, work history highlights (role, company, duration, "
    "notable accomplishments), education, and any standout projects. Use short "
    "phrases, not full sentences. Do not add commentary, opinions, or anything not "
    "actually present in the material -- omit a category entirely if the material "
    "doesn't cover it, rather than guessing.";

// Turns a whole session's transcript into study notes when recording stops.
// Plain-text sections rather than Markdown headings so the same text reads
// well both in the app's answer view and in the saved .md file.
constexpr const char* kNotesPrompt =
    "You turn a raw lecture transcript into concise study notes for the student "
    "who attended. The transcript is speech-to-text: expect missing punctuation, "
    "repeated fragments, and misheard words -- fix obvious errors when the context "
    "makes the intended word clear (e.g. \"100-volt light bulb\" is a 100-watt "
    "bulb), and never present a guess as fact.\n\n"
    "Use exactly these sections, each title on its own line, skipping any that "
    "the lecture didn't cover:\n"
    "Summary: 3-5 sentences on what the lecture was about.\n"
    "Key ideas: a short bullet list (\"- \"), one idea per bullet.\n"
    "Formulas: each formula with what its symbols mean and when it applies.\n"
    "Worked examples: any numerical examples the lecturer went through, with "
    "the numbers used and the result.\n"
    "To review: things the lecturer flagged as important, or that are easy to get "
    "wrong.\n\n"
    "Only include what's actually in the transcript. Keep it tight: the goal is "
    "something the student can reread in five minutes.";

// Transcript budget for local notes. Ollama defaults to a 4,096-token
// context, which would silently cut a lecture down to its last few
// minutes; kNotesContextTokens raises it for this one request. ~40k
// characters is roughly 10k tokens, leaving room for the notes themselves.
constexpr size_t kLocalNotesMaxChars = 40000;
constexpr int kNotesContextTokens = 16384;

// Guards g_referenceContext -- set once from the UI thread whenever the
// user uploads/clears a document, read from whichever background thread
// is handling the current question. Plain string + mutex rather than
// DocumentStore's own version-caching pattern: this is copied into an
// outgoing HTTP request body at most once per question, nowhere near the
// per-frame redraw rate that pattern exists to avoid.
std::mutex g_referenceContextMutex;
std::string g_referenceContext;

// Shared by ask(), summarizeDocuments(), and warmUp() -- warmUp only
// cares about the side effect (loading the model), not the returned
// text, so it passes an empty system prompt (no point steering style for
// a throwaway "Hi"). `timeoutSeconds` defaults to the live-question
// ceiling; summarizeDocuments passes a longer one since a resume-sized
// prompt is meaningfully bigger than a spoken question. The actual
// HTTP/error-handling work lives in the shared OllamaClient, not here.
std::string RunOllama(const std::string& prompt, const std::string& system, const std::string& model,
                      long timeoutSeconds = 60, int maxTokens = kMaxAnswerTokens, int contextTokens = 0,
                      const std::function<void(const std::string&)>& onPartial = nullptr, bool think = false) {
    nlohmann::json body = {
        {"model", model},
        {"prompt", prompt},
        {"stream", false},
        {"keep_alive", kKeepAlive},
        // Qwen3.5 reasons at length before answering unless told not to:
        // measured 60-180s per question with it on vs ~10-25s off, far too
        // slow for a live lecture. Rule 4 of the system prompt gets most
        // of the accuracy back without the wait.
        {"think", think},
    };
    body["options"] = nlohmann::json::object();
    if (maxTokens > 0) body["options"]["num_predict"] = maxTokens;
    if (contextTokens > 0) body["options"]["num_ctx"] = contextTokens;
    if (!system.empty()) {
        body["system"] = system;
    }
    return OllamaClient::generate(body, timeoutSeconds, onPartial);
}

// Builds the same system prompt + reference-context blending ask() and
// askThinkHarder() both need, so the two only differ in which model/
// timeout they call RunOllama() with.
std::string systemPromptWithContext() {
    std::string system = kSystemPrompt;
    std::lock_guard<std::mutex> lock(g_referenceContextMutex);
    if (!g_referenceContext.empty()) {
        system +=
            "\n\nThe listener has shared background documents (e.g. a resume) you can draw "
            "on when relevant, especially for personal/behavioral questions -- use them to "
            "make the outline specific to their real background instead of generic:\n\n" +
            g_referenceContext;
    }
    return system;
}

// Loads the model and leaves Ollama a reusable copy of the system prompt.
// qwen3.5 is a hybrid (partly recurrent) model, so Ollama can only resume a
// prompt from a saved "context checkpoint", and it saves one ~4 tokens before
// the end of each prompt -- for a question that's past the point where the
// next question differs, so every question re-read the whole ~360-token
// system prompt (~30 s on a laptop CPU). A raw prompt that stops exactly where
// the question would start (Ollama's own qwen3.5 layout) leaves a checkpoint
// inside the shared part; later questions resume from it (~4 s in testing).
// One token of output: this is only for its side effects.
void WarmSystemPrompt() {
    nlohmann::json body = {
        {"model", kModelName},
        {"prompt", "<|im_start|>system\n" + systemPromptWithContext() + "<|im_end|>\n<|im_start|>user\n"},
        {"raw", true},
        {"stream", false},
        {"keep_alive", kKeepAlive},
    };
    body["options"] = {{"num_predict", 1}};
    OllamaClient::generate(body, 120);
}

}  // namespace

namespace LocalLLMClient {

std::string ask(const std::string& question, const std::function<void(const std::string&)>& onPartial) {
    return RunOllama(question, systemPromptWithContext(), kModelName, 60, kMaxAnswerTokens, 0, onPartial);
}

std::string systemPrompt() {
    return systemPromptWithContext() + kPlainTextRule;
}

std::string notesSystemPrompt() {
    return std::string(kNotesPrompt) + kPlainTextRule;
}

std::string makeNotes(const std::string& transcript, const std::function<void(const std::string&)>& onPartial) {
    // Keep the end if it's too long: the latest material is what's least
    // likely to have been covered by answers the student already has.
    const std::string input = Utf8::Tail(transcript, kLocalNotesMaxChars);
    // Generous: this runs after the lecture, and on a PC without a usable GPU
    // reading a full lecture (~10k tokens) takes many minutes before the first
    // word -- a timeout would just throw that work away.
    const std::string notes = RunOllama(input, kNotesPrompt, kModelName, /*timeoutSeconds=*/900,
                                        /*maxTokens=*/1500, kNotesContextTokens, onPartial);
    warmUp();  // a different prompt replaced the cached one
    return notes;
}

std::string askThinkHarder(const std::string& question) {
    // Longer timeout than ask()'s default 60s -- a 9B model is
    // meaningfully slower than the 3B fast model, and this path is only
    // ever invoked on explicit user request, not automatically, so the
    // extra ceiling is a fair trade for not timing out mid-answer.
    const std::string answer =
        RunOllama(question, systemPromptWithContext(), kThinkHarderModelName, /*timeoutSeconds=*/120);
    warmUp();  // the bigger model may have pushed the regular one out of memory
    return answer;
}

// 1 = on a GPU, 0 = CPU only, -1 = not loaded (or Ollama unreachable).
int LoadedOnGpu() {
    // /api/ps lists loaded models with how much of each sits in GPU memory.
    const Http::Result r = Http::get("http://127.0.0.1:11434/api/ps", 5);
    if (!r.ok) return -1;
    const nlohmann::json ps = nlohmann::json::parse(r.body, nullptr, /*allow_exceptions=*/false);
    if (!ps.is_object() || !ps.contains("models") || !ps["models"].is_array()) return -1;
    for (const auto& m : ps["models"]) {
        if (m.value("name", "") == kModelName) return m.value("size_vram", 0LL) > 0 ? 1 : 0;
    }
    return -1;
}

bool runsOnGpu() {
    int where = LoadedOnGpu();
    if (where < 0) {
        // Not in memory (idle for a while, or pushed out by the bigger model):
        // load it the useful way, then look again.
        WarmSystemPrompt();
        where = LoadedOnGpu();
    }
    return where > 0;
}

std::string askReasoning(const std::string& question) {
    // Its reasoning counts against the token limit, hence the higher cap.
    const std::string answer = RunOllama(question, systemPromptWithContext(), kModelName, /*timeoutSeconds=*/240,
                                         /*maxTokens=*/2500, /*contextTokens=*/0, nullptr, /*think=*/true);
    warmUp();  // the reasoning pass left a different prompt cached
    return answer;
}

void setReferenceContext(const std::string& context) {
    {
        std::lock_guard<std::mutex> lock(g_referenceContextMutex);
        if (g_referenceContext == context) return;
        g_referenceContext = context;
    }
    warmUp();  // the system prompt changed
}

std::string summarizeDocuments(const std::string& rawText) {
    // Uncapped: condensed notes from a long document can legitimately run
    // past the answer cap.
    const std::string summary = RunOllama(rawText, kSummarizePrompt, kModelName, /*timeoutSeconds=*/90, /*maxTokens=*/0);
    warmUp();  // a different prompt replaced the cached one
    return summary;
}

void warmUp() {
    // One at a time; several triggers can land together (recording start,
    // a document scan finishing). A request that arrives mid-warm-up (e.g.
    // the system prompt changed) runs another pass instead of being dropped.
    static std::atomic<unsigned> requested{0};
    static std::atomic<bool> warming{false};
    ++requested;
    if (warming.exchange(true)) return;
    std::thread([]() {
        for (;;) {
            const unsigned target = requested.load();
            WarmSystemPrompt();
            if (requested.load() != target) continue;
            warming.store(false);
            // Re-check after letting go, so a request in that gap isn't lost.
            if (requested.load() == target || warming.exchange(true)) return;
        }
    }).detach();
}

}  // namespace LocalLLMClient
