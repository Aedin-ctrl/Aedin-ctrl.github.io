#pragma once

#include <string>

// Minimal, synchronous (blocking) Claude API client for the first working
// cut of auto Q&A. Callers should run ask() on a background thread — it
// does a blocking HTTPS request.
namespace ClaudeClient {

// Returns the answer text, or a string starting with "[error]" on failure
// (no API key configured, network failure, non-2xx response, etc.) so
// callers can show it as-is without needing exceptions.
std::string ask(const std::string& question);

}  // namespace ClaudeClient
