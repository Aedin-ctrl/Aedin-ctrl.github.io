#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// Screen-capture "solve this" backend: sends an image (PNG bytes, from
// ScreenCapture) plus an optional typed question to a vision-capable
// local Ollama model. Separate from LocalLLMClient (llama3.2:3b,
// text-only) -- see VisionLLMClient.cpp for which vision model and why.
namespace VisionLLMClient {

// Blocking; same "[error]..." failure convention as LocalLLMClient::ask().
// `question` may be empty -- in that case the model is asked to just
// solve/explain whatever's in the image on its own.
// With `onPartial`, the answer streams in (called with the text so far).
std::string analyze(const std::vector<uint8_t>& pngBytes, const std::string& question,
                    const std::function<void(const std::string&)>& onPartial = nullptr);

// The system prompt for Claude screenshots: analyze()'s instructions plus a
// plain-text-math rule the local model does worse with.
std::string systemPrompt();

// The prompt analyze() sends when the user didn't type a question.
std::string defaultPrompt();

}  // namespace VisionLLMClient
