#pragma once

#include <functional>
#include <string>

// Local Q&A backend via Ollama (http://localhost:11434) instead of the
// Anthropic API -- no API key to manage, no per-token cost, no network
// dependency. Chosen after local-council research (2026-09-23): on a
// 16GB Mac that's also running whisper.cpp's Metal transcription
// continuously, a small model with real memory headroom beats a bigger,
// higher-quality one that risks swap/latency spikes under combined
// GPU/RAM pressure. See src/summarize/ClaudeClient.h for the (currently
// unused but kept available) real-Claude-API alternative, e.g. if the
// user configures an API key later.
namespace LocalLLMClient {

// Same contract as ClaudeClient::ask(): blocking, returns the answer
// text, or a string starting with "[error]" on failure (Ollama not
// running, model not pulled, timeout, etc.). With `onPartial`, the answer
// streams in: it's called with the text so far as it's generated.
std::string ask(const std::string& question,
                const std::function<void(const std::string&)>& onPartial = nullptr);

// "Think harder" retry: re-answers the same question through a larger
// local model ("qwen3.5:9b", see SetupChecker's optional download row)
// instead of the default fast one -- for when the fast answer looks
// wrong. Deliberately a different, stronger model rather than asking the
// same small one to double-check itself, which tends to just repeat the
// same mistake. Same "[error]..." convention as ask(); requires the
// model to have been downloaded first (SetupChecker::isThinkHarderModelReady()).
// Slower than ask() by design (bigger model, longer timeout) -- only
// called when the user explicitly asks for it, never automatically.
std::string askThinkHarder(const std::string& question);

// Think Harder without the bigger model: the regular model with its reasoning
// ("thinking") mode on -- off for live answers because it takes minutes on a
// CPU, but a real second opinion when the user asks for one.
std::string askReasoning(const std::string& question);

// Whether Ollama has the regular model loaded on a GPU (reasoning mode takes
// minutes on a processor alone).
bool runsOnGpu();

// The system prompt for Claude: the same instructions and reference context
// ask() uses, plus a plain-text-math rule the local model does worse with.
std::string systemPrompt();

// System prompt for turning a session transcript into study notes (for
// Claude; includes the plain-text rule), and the local-model equivalent,
// which runs the whole thing itself. makeNotes() blocks for up to a few
// minutes on a long lecture -- call it on a background thread.
std::string notesSystemPrompt();
std::string makeNotes(const std::string& transcript,
                      const std::function<void(const std::string&)>& onPartial = nullptr);

// Sets the text ask() weaves into its system prompt for every future
// question -- mainly useful for personal/behavioral questions, so the
// bulleted outline the model gives back is grounded in the listener's own
// real background instead of being generic. Normally the *output* of
// summarizeDocuments(), not raw document text -- see
// App::requestDocumentScan. Pass an empty string to clear. Safe to call
// from any thread.
void setReferenceContext(const std::string& context);

// Condenses raw uploaded-document text (see DocumentStore::combinedContext)
// into compact factual notes suitable for setReferenceContext(). Blocking,
// same "[error]..." failure convention as ask() -- but allows a longer
// timeout, since a resume-sized prompt takes meaningfully longer than a
// spoken question.
std::string summarizeDocuments(const std::string& rawText);

// Fire-and-forget: sends a tiny throwaway prompt so the model gets
// loaded into memory now rather than on the first real question.
// Ollama unloads an idle model after a few minutes by default; without
// this, the first question after any quiet stretch pays a multi-second
// reload stall that has nothing to do with the question itself. It also
// leaves Ollama a cached copy of the system prompt for questions to resume
// from (see WarmSystemPrompt in the .cpp). Safe to call from the UI/main
// thread -- spawns its own background thread.
void warmUp();

}  // namespace LocalLLMClient
