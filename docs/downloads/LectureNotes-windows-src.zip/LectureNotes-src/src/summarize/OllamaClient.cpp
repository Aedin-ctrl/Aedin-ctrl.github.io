#include "OllamaClient.h"

#include "net/Http.h"

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        return std::string();
    }
    size_t end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

}  // namespace

std::string OllamaClient::generate(const nlohmann::json& body, long timeoutSeconds) {
    // Replace (not throw on) invalid UTF-8: whisper output can split a
    // multi-byte character, and a throw here kills the calling thread.
    const std::string bodyStr = body.dump(-1, ' ', false, nlohmann::json::error_handler_t::replace);

    // 127.0.0.1 rather than "localhost": on Windows, localhost can resolve
    // to ::1 first while Ollama listens on IPv4 only.
    const Http::Result r = Http::post("http://127.0.0.1:11434/api/generate", {"Content-Type: application/json"},
                                      bodyStr, timeoutSeconds);
    const long httpStatus = r.status;
    const std::string& responseBody = r.body;

    if (!r.ok) {
        return "[error] Could not reach Ollama at localhost:11434 (" + r.error +
               "). Is Ollama running? The Setup checklist can start it.";
    }

    nlohmann::json parsed;
    try {
        parsed = nlohmann::json::parse(responseBody);
    } catch (const nlohmann::json::parse_error&) {
        return "[error] Could not parse Ollama response.";
    }

    if (httpStatus < 200 || httpStatus >= 300) {
        std::string message = parsed.value("error", responseBody);
        if (message.find("not found") != std::string::npos && body.contains("model")) {
            message += " Run: ollama pull " + body["model"].get<std::string>();
        }
        return "[error] Ollama returned " + std::to_string(httpStatus) + ": " + message;
    }

    if (parsed.contains("response")) {
        return trim(parsed["response"].get<std::string>());
    }
    return "[error] Unexpected response shape from Ollama.";
}
