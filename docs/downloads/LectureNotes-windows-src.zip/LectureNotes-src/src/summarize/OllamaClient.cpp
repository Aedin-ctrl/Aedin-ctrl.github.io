#include "OllamaClient.h"

#include "net/Http.h"
#include "util/CpuShare.h"

#include <thread>

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        return std::string();
    }
    size_t end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

}  // namespace

std::string OllamaClient::generate(const nlohmann::json& requestBody, long timeoutSeconds,
                                   const std::function<void(const std::string&)>& onPartial) {
    nlohmann::json body = requestBody;
#ifdef _WIN32
    // Windows runs both the speech model and this one on the CPU. Left to
    // itself Ollama takes every core, and a question answered mid-lecture
    // slowed transcription ~18x (1.5 s -> 27 s per 8 s window in testing), so
    // audio was dropped. Give Ollama half the cores; while it runs,
    // transcription keeps the rest. Answers take a little longer, so allow
    // them more time.
    CpuShare::LocalModelBusy busy;
    const unsigned hw = std::thread::hardware_concurrency();
    if (!body.contains("options")) body["options"] = nlohmann::json::object();
    if (!body["options"].contains("num_thread")) body["options"]["num_thread"] = hw > 1 ? hw / 2 : 1;
    timeoutSeconds *= 2;
#endif
    if (onPartial) body["stream"] = true;
    // Replace (not throw on) invalid UTF-8: whisper output can split a
    // multi-byte character, and a throw here kills the calling thread.
    const std::string bodyStr = body.dump(-1, ' ', false, nlohmann::json::error_handler_t::replace);

    if (onPartial) {
        // JSON lines: {"response":"<next tokens>","done":false} ... then
        // {"done":true}; {"error":"..."} on failure.
        std::string text;
        std::string streamError;
        const Http::Result r = Http::postStreamingLines(
            "http://127.0.0.1:11434/api/generate", bodyStr,
            [&](const std::string& line) {
                nlohmann::json chunk = nlohmann::json::parse(line, nullptr, /*allow_exceptions=*/false);
                if (!chunk.is_object()) return;
                if (chunk.contains("error") && chunk["error"].is_string()) streamError = chunk["error"];
                if (chunk.contains("response") && chunk["response"].is_string()) {
                    const std::string piece = chunk["response"];
                    if (piece.empty()) return;
                    text += piece;
                    const std::string shown = trim(text);
                    if (!shown.empty()) onPartial(shown);
                }
            },
            timeoutSeconds);
        if (!streamError.empty()) {
            std::string message = streamError;
            if (message.find("not found") != std::string::npos && body.contains("model")) {
                message += " Run: ollama pull " + body["model"].get<std::string>();
            }
            return "[error] Ollama: " + message;
        }
        if (!r.ok && trim(text).empty()) {
            return "[error] Could not reach Ollama at localhost:11434 (" + r.error +
                   "). Is Ollama running? The Setup checklist can start it.";
        }
        if (!r.ok) return trim(text) + "\n\n(Cut off: " + r.error + ".)";  // keep what arrived, but say so
        if (trim(text).empty()) return "[error] Ollama returned an empty answer.";
        return trim(text);
    }

    // 127.0.0.1 rather than "localhost": on Windows, localhost can resolve
    // to ::1 first while Ollama listens on IPv4 only.
    const Http::Result r = Http::post("http://127.0.0.1:11434/api/generate", {"Content-Type: application/json"},
                                      bodyStr, timeoutSeconds);
    const long httpStatus = r.status;
    const std::string& responseBody = r.body;

    if (!r.ok) {
        return "[error] Could not reach Ollama at localhost:11434 (" + r.error +
               "). Is Ollama running? The Setup checklist can start it.";
    }

    nlohmann::json parsed;
    try {
        parsed = nlohmann::json::parse(responseBody);
    } catch (const nlohmann::json::parse_error&) {
        return "[error] Could not parse Ollama response.";
    }

    if (httpStatus < 200 || httpStatus >= 300) {
        std::string message = parsed.value("error", responseBody);
        if (message.find("not found") != std::string::npos && body.contains("model")) {
            message += " Run: ollama pull " + body["model"].get<std::string>();
        }
        return "[error] Ollama returned " + std::to_string(httpStatus) + ": " + message;
    }

    if (parsed.contains("response")) {
        // Empty when e.g. reasoning used up the whole token budget.
        const std::string text = trim(parsed["response"].get<std::string>());
        return text.empty() ? "[error] The local model returned an empty answer." : text;
    }
    return "[error] Unexpected response shape from Ollama.";
}
