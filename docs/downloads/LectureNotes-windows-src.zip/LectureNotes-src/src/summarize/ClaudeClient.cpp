#include "ClaudeClient.h"

#include "net/Http.h"

#include <cstdlib>
#include <sstream>

#include <nlohmann/json.hpp>

#include "setup/ClaudeKeyStore.h"

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        return std::string();
    }
    size_t end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

// Env var first (dev convenience -- only takes effect if launched from a
// shell that exported it, which Finder/`open` launches never do); falls
// back to the Keychain-backed key the user pastes into Setup's optional
// "Smarter answers" section.
std::string resolveApiKey() {
    if (const char* env = std::getenv("ANTHROPIC_API_KEY")) {
        std::string key = trim(env);
        if (!key.empty()) {
            return key;
        }
    }
    return ClaudeKeyStore::key();
}

}  // namespace

namespace ClaudeClient {

std::string ask(const std::string& question) {
    const std::string apiKey = resolveApiKey();
    if (apiKey.empty()) {
        return "[error] No Anthropic API key configured. Add one in Setup under "
               "\"Smarter answers (optional)\".";
    }

    nlohmann::json body = {
        {"model", "claude-haiku-4-5-20251001"},
        {"max_tokens", 300},
        {"messages", nlohmann::json::array({{{"role", "user"}, {"content", question}}})},
    };
    // Replace (not throw on) invalid UTF-8: whisper output can split a
    // multi-byte character, and a throw here kills the calling thread.
    const std::string bodyStr = body.dump(-1, ' ', false, nlohmann::json::error_handler_t::replace);

    const Http::Result r = Http::post("https://api.anthropic.com/v1/messages",
                                      {"x-api-key: " + apiKey, "anthropic-version: 2023-06-01",
                                       "content-type: application/json"},
                                      bodyStr, 30);
    const long httpStatus = r.status;
    const std::string& responseBody = r.body;

    if (!r.ok) {
        return "[error] Request failed: " + r.error;
    }

    nlohmann::json parsed;
    try {
        parsed = nlohmann::json::parse(responseBody);
    } catch (const nlohmann::json::parse_error&) {
        return "[error] Could not parse Claude API response.";
    }

    if (httpStatus < 200 || httpStatus >= 300) {
        std::string message = parsed.value("error", nlohmann::json::object()).value("message", responseBody);
        return "[error] Claude API returned " + std::to_string(httpStatus) + ": " + message;
    }

    if (parsed.contains("content") && parsed["content"].is_array() && !parsed["content"].empty() &&
        parsed["content"][0].contains("text")) {
        return trim(parsed["content"][0]["text"].get<std::string>());
    }
    return "[error] Unexpected response shape from Claude API.";
}

}  // namespace ClaudeClient
