#pragma once

#include <algorithm>
#include <string>

// Byte-count truncation can land inside a multi-byte UTF-8 character
// ("µ", "°", "—"), leaving invalid UTF-8 that makes nlohmann::json::dump()
// throw -- fatal on the detached threads that build model requests.
namespace Utf8 {

inline bool IsContinuation(unsigned char c) {
    return (c & 0xC0) == 0x80;
}

// The last `maxBytes` bytes of `s`, moved forward to a character boundary.
inline std::string Tail(const std::string& s, size_t maxBytes) {
    if (s.size() <= maxBytes) return s;
    size_t start = s.size() - maxBytes;
    while (start < s.size() && IsContinuation(static_cast<unsigned char>(s[start]))) ++start;
    return s.substr(start);
}

// Length in bytes of the UTF-8 character starting at s[pos] (1 for ASCII or
// a stray byte), clamped to the end of the string.
inline size_t CharLength(const std::string& s, size_t pos) {
    const unsigned char c = static_cast<unsigned char>(s[pos]);
    size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
    len = std::min(len, s.size() - pos);
    for (size_t i = 1; i < len; ++i) {
        if (!IsContinuation(static_cast<unsigned char>(s[pos + i]))) return i;
    }
    return len;
}

}  // namespace Utf8
