#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// Answers questions with Claude through the user's own locally installed,
// logged-in Claude Code CLI (`claude -p`), so a Claude subscription can be
// used without an API key. Only works on a machine where Claude Code is
// installed and signed in; everywhere else isAvailable() is false and
// callers fall back to LocalLLMClient.
//
// Each call spawns the CLI stripped down to a plain question-answerer: no
// tools, no MCP servers, no user settings or hooks, no saved session, and
// the app's own short system prompt in place of Claude Code's agent prompt.
// That cuts a call from ~12,300 input tokens to ~450 (measured 2026-09-28,
// see experiments/), so answering every question stays cheap on the
// user's usage limit.
namespace ClaudeCodeClient {

// True if the `claude` binary was found and reports a logged-in account.
// Never blocks: returns the last known state and refreshes it in the
// background at most every few minutes. False until the first check
// completes -- call refreshAsync() at startup so that's quick.
bool isAvailable();

// When the user's Claude usage limit is exhausted, isAvailable() returns
// false until it resets, and this returns the reset time (Unix seconds);
// 0 when not limited. Learned from the rate-limit info the CLI reports on
// every call, so no extra requests are made to find out.
long long limitedUntil();

// Set after repeated failures (Claude not responding): Unix seconds until
// Claude is tried again, 0 when not backing off. isAvailable() is false
// while this is set.
long long backingOffUntil();

// Fraction (0..1) of the current usage window already used, as of the last
// call, or -1 if unknown.
float usageFraction();

// Terminates any Claude Code processes still running (e.g. an answer
// mid-stream). Call on shutdown: they're separate processes, so otherwise
// they finish -- and spend tokens -- after the app is gone.
void cancelAll();

// Blocking variant for background threads about to make a call: if the
// last check said "not available" and is more than a few seconds old,
// re-checks right now (~0.3s) instead of trusting it. A single transient
// failure of the startup check (e.g. while Claude Code updates itself)
// otherwise sent every question to the local model until the next
// periodic re-check.
bool isAvailableNow();

// True if the `claude` binary is present (signed in or not).
bool isInstalled();

// One-click setup for the checklist: opens a Terminal window that installs
// Claude Code with Anthropic's official installer if it's missing, then
// runs `claude auth login` (which opens the browser to sign in). Returns
// false if the setup script couldn't be written or opened.
bool openSetupInTerminal();

// Kicks off a background availability check. Safe to call repeatedly;
// overlapping calls are coalesced.
void refreshAsync();

// Blocking -- run on a background thread. `system` is the full system
// prompt to use (callers pass LocalLLMClient::systemPrompt() so both
// backends answer in the same style with the same reference context).
// `effort` is passed straight through as --effort ("" leaves the CLI's
// default). Returns the answer text, or a string starting with "[error]"
// on any failure (not installed, logged out, usage limit, timeout...).
//
// If `onPartial` is set, the answer is streamed and it's called (on the
// calling thread) with the full text-so-far each time more arrives, so the
// UI can show the answer filling in instead of waiting ~6s for all of it.
std::string ask(const std::string& question, const std::string& system, const std::string& effort = "",
                long timeoutSeconds = 60,
                const std::function<void(const std::string&)>& onPartial = nullptr);

// Same as ask(), with a PNG screenshot attached (the camera feature).
std::string askWithImage(const std::vector<uint8_t>& pngBytes, const std::string& question,
                         const std::string& system, const std::string& effort = "", long timeoutSeconds = 90,
                         const std::function<void(const std::string&)>& onPartial = nullptr);

}  // namespace ClaudeCodeClient
