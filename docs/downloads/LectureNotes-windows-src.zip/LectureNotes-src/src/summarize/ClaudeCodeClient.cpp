#include "ClaudeCodeClient.h"

#include "Base64.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <condition_variable>
#include <deque>
#include "platform/win/WinUtil.h"
#else
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <spawn.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

#include <algorithm>
#include <atomic>
#include <climits>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <mutex>
#include <set>
#include <thread>
#include <vector>

#include <nlohmann/json.hpp>

#include "util/LocalTime.h"

#ifndef _WIN32
extern char** environ;
#endif

namespace {

// Alias, not a pinned version: always resolves to the newest Opus.
constexpr const char* kModel = "opus";

// How long a known availability state is trusted before re-checking. Short
// enough that signing in (or getting logged out) is picked up during a
// lecture, long enough that the check itself costs nothing. A negative
// result is trusted for much less: it's more often transient.
constexpr auto kRecheckInterval = std::chrono::minutes(5);
constexpr auto kRecheckIntervalWhenUnavailable = std::chrono::seconds(30);
constexpr auto kSyncRecheckAfter = std::chrono::seconds(5);

// A handful of detected questions can land within seconds of each other;
// cap concurrent CLI processes so a burst doesn't fork a dozen at once.
constexpr int kMaxConcurrent = 3;

// See Run(). Seen once in testing: a notes call that normally takes ~20-40s
// produced nothing and ran out its full 240s before the local fallback
// started; the same request succeeded moments later.
constexpr long kIdleTimeoutSeconds = 60;

// A healthy call starts streaming model output (thinking or text) within
// ~2-4s (up to ~6s for notes on a full lecture). In the stalls seen in
// testing nothing ever arrived and each question waited out the whole 60s
// timeout before falling back, so give up much sooner if nothing has.
constexpr long kFirstTextSeconds = 20;

// Circuit breaker: after this many failures in a row, stop trying Claude
// for kBackoff so questions go straight to the local model instead of each
// paying the wait above; then try Claude again. Any success resets it.
constexpr int kFailuresBeforeBackoff = 2;
constexpr auto kBackoff = std::chrono::minutes(3);
std::atomic<int> g_consecutiveFailures{0};
std::atomic<long long> g_backoffUntil{0};  // Unix seconds, 0 = not backing off

enum class Availability { Unknown, Yes, No };
std::atomic<Availability> g_availability{Availability::Unknown};
std::atomic<bool> g_checkInFlight{false};
std::mutex g_checkedAtMutex;
std::chrono::steady_clock::time_point g_checkedAt{};

// Unix seconds; 0 = not limited. Set from the rate_limit_event the CLI
// streams on every call.
std::atomic<long long> g_limitedUntil{0};
std::atomic<float> g_usageFraction{-1.0f};

long long NowSeconds() {
    return std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::system_clock::now().time_since_epoch()).count();
}

// {"status": "allowed" | ..., "resetsAt": <unix>, "unifiedWindows":
//  {"five_hour": {"utilization": 0.22, ...}}}
void RecordRateLimitInfo(const nlohmann::json& info) {
    if (info.contains("unifiedWindows") && info["unifiedWindows"].is_object()) {
        float highest = -1.0f;
        for (const auto& window : info["unifiedWindows"]) {
            if (window.contains("utilization") && window["utilization"].is_number()) {
                highest = std::max(highest, window["utilization"].get<float>());
            }
        }
        if (highest >= 0.0f) g_usageFraction = highest;
    }
    const std::string status = info.value("status", std::string("allowed"));
    if (status == "allowed" || status == "allowed_warning") {
        g_limitedUntil = 0;
    } else {
        const long long resetsAt = info.value("resetsAt", 0LL);
        g_limitedUntil = resetsAt > NowSeconds() ? resetsAt : NowSeconds() + 10 * 60;
    }
}

std::mutex g_childrenMutex;
#ifdef _WIN32
using ChildHandle = HANDLE;  // process handle; TerminateProcess kills it
#else
using ChildHandle = pid_t;
#endif
std::set<ChildHandle> g_children;

std::mutex g_slotMutex;
int g_activeCalls = 0;

#ifdef _WIN32
bool IsExecutable(const std::string& path) {
    return WinUtil::FileExists(path);
}

// Where Claude Code's official Windows installer (irm claude.ai/install.ps1)
// and WinGet put claude.exe.
std::string ClaudeBinaryPath() {
    const std::string profile = WinUtil::UserProfileDir();
    const std::string local = WinUtil::LocalAppDataDir();
    const std::vector<std::string> candidates = {
        profile + "\\.local\\bin\\claude.exe",
        local + "\\Microsoft\\WinGet\\Links\\claude.exe",
        profile + "\\.claude\\local\\claude.exe",
    };
    for (const std::string& path : candidates) {
        if (IsExecutable(path)) return path;
    }
    return "";
}

std::string NeutralWorkingDirectory() {
    const std::string dir = WinUtil::TempDir() + "\\lecturenotes-claude";
    WinUtil::CreateDirectories(dir);
    return dir;
}
#else
bool IsExecutable(const std::string& path) {
    return access(path.c_str(), X_OK) == 0;
}

// GUI apps launched from Finder don't inherit the shell's PATH, so
// ~/.local/bin (where Claude Code's native installer puts it) is invisible
// to a plain execvp -- same problem SetupChecker::OllamaBinaryPath solves.
std::string ClaudeBinaryPath() {
    std::vector<std::string> candidates = {"/opt/homebrew/bin/claude", "/usr/local/bin/claude"};
    if (const char* home = std::getenv("HOME"); home && *home) {
        const std::string h = home;
        candidates.insert(candidates.begin(), {h + "/.local/bin/claude", h + "/.claude/local/claude"});
        candidates.push_back(h + "/.npm-global/bin/claude");
    }
    for (const std::string& path : candidates) {
        if (IsExecutable(path)) return path;
    }
    return "";
}
#endif

// Claude Code picks up CLAUDE.md files, project settings, and git status
// from its working directory. Run it from an empty private directory so a
// lecture question never pulls in (or gets to see) whatever project the
// app happens to have been launched near.
#ifndef _WIN32
std::string NeutralWorkingDirectory() {
    const char* tmp = std::getenv("TMPDIR");
    std::string dir = std::string(tmp ? tmp : "/tmp/") + "lecturenotes-claude";
    mkdir(dir.c_str(), 0700);
    return dir;
}
#endif

// The environment for spawned CLI processes: ours, minus Claude Code's own
// session variables. If LectureNotes was started from inside a Claude Code
// session (e.g. `open` run from its terminal), it inherits CLAUDECODE,
// CLAUDE_CODE_SESSION_ID, CLAUDE_CODE_MESSAGING_SOCKET, ... and every
// `claude -p` it spawns then acts as a nested child of that session. Seen
// in testing: calls intermittently hung for the full timeout or failed
// inside the app, while the identical call from a plain shell worked.
//
// Only these session variables, by name -- not every CLAUDE_CODE_* one:
// others are user configuration the CLI needs (CLAUDE_CODE_OAUTH_TOKEN
// from `claude setup-token`, CLAUDE_CODE_USE_BEDROCK/VERTEX, ...).
static const char* kSessionVars[] = {
        "CLAUDECODE",           "CLAUDE_PID",                  "CLAUDE_EFFORT",
        "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_SESSION_ATTENDED", "CLAUDE_CODE_CHILD_SESSION",
        "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_EXECPATH",       "CLAUDE_CODE_MESSAGING_SOCKET",
        "CLAUDE_CODE_MESSAGING_TOKEN",
    };

bool IsSessionVar(const std::string& name) {
    return std::any_of(std::begin(kSessionVars), std::end(kSessionVars), [&](const char* s) {
#ifdef _WIN32
        return _stricmp(name.c_str(), s) == 0;  // Windows variable names are case-insensitive
#else
        return name == s;
#endif
    });
}

#ifdef _WIN32
// CreateProcessW environment block: ours minus the session variables,
// "NAME=value\0...\0\0" in UTF-16.
std::wstring SanitizedEnvironmentBlock() {
    std::wstring block;
    LPWCH env = GetEnvironmentStringsW();
    for (LPWCH p = env; p && *p; p += wcslen(p) + 1) {
        const std::wstring var = p;
        const size_t eq = var.find(L'=', 1);  // entries like "=C:=C:\\" start with '='
        if (eq != std::wstring::npos && IsSessionVar(WinUtil::Narrow(var.substr(0, eq)))) continue;
        block += var;
        block.push_back(L'\0');
    }
    if (env) FreeEnvironmentStringsW(env);
    block.push_back(L'\0');
    return block;
}
#else
std::vector<std::string> SanitizedEnvironment() {
    std::vector<std::string> env;
    for (char** e = environ; e && *e; ++e) {
        const std::string var = *e;
        const std::string name = var.substr(0, var.find('='));
        if (!IsSessionVar(name)) {
            env.push_back(var);
        }
    }
    return env;
}
#endif

// One line per call in ~/Library/Logs/LectureNotes/claude.log, so a
// silent fallback to the local model can be diagnosed afterwards.
void LogCall(double seconds, const std::string& outcome, const std::string& stderrText) {
#ifdef _WIN32
    const std::string dir = WinUtil::AppDataSubdir("Logs");
    FILE* f = _wfopen(WinUtil::Widen(dir + "\\claude.log").c_str(), L"a");
#else
    const char* home = std::getenv("HOME");
    if (!home) return;
    const std::string dir = std::string(home) + "/Library/Logs/LectureNotes";
    mkdir(dir.c_str(), 0755);
    FILE* f = std::fopen((dir + "/claude.log").c_str(), "a");
#endif
    if (!f) return;
    const std::time_t now = std::time(nullptr);
    const std::tm local = LocalTm(now);
    char when[32];
    std::strftime(when, sizeof(when), "%Y-%m-%d %H:%M:%S", &local);
    std::string err = stderrText.substr(0, 300);
    for (char& c : err) {
        if (c == '\n') c = ' ';
    }
    std::fprintf(f, "%s  %5.1fs  %s%s%s\n", when, seconds, outcome.c_str(), err.empty() ? "" : "  stderr: ",
                 err.c_str());
    std::fclose(f);
}

struct ProcessResult {
    bool started = false;
    bool timedOut = false;
    bool wentIdle = false;  // timed out because of silence, not the overall limit
    bool noText = false;    // gave up because no answer text had started by kFirstTextSeconds
    int exitStatus = -1;
    std::string out;
    std::string err;
};

#ifdef _WIN32
// Windows version of Run(): CreateProcessW with anonymous pipes. The child
// inherits only its three pipe ends (PROC_THREAD_ATTRIBUTE_HANDLE_LIST, the
// Windows counterpart of POSIX_SPAWN_CLOEXEC_DEFAULT -- without it,
// concurrent calls inherit each other's stdin and never see EOF). It runs
// in a kill-on-close job so a timeout takes down anything it started.
// Windows pipes can't be poll()ed, so two reader threads feed a queue.
ProcessResult Run(const std::vector<std::string>& argv, const std::string& input, const std::string& cwd,
                  long timeoutSeconds, const std::function<void(const std::string&)>& onStdoutLine = nullptr,
                  long idleTimeoutSeconds = 0, const std::function<bool()>& shouldAbort = nullptr) {
    ProcessResult result;
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE inRead = nullptr, inWrite = nullptr, outRead = nullptr, outWrite = nullptr, errRead = nullptr,
           errWrite = nullptr;
    if (!CreatePipe(&inRead, &inWrite, &sa, 0)) return result;
    if (!CreatePipe(&outRead, &outWrite, &sa, 0)) {
        CloseHandle(inRead); CloseHandle(inWrite);
        return result;
    }
    if (!CreatePipe(&errRead, &errWrite, &sa, 0)) {
        CloseHandle(inRead); CloseHandle(inWrite); CloseHandle(outRead); CloseHandle(outWrite);
        return result;
    }
    for (HANDLE h : {inWrite, outRead, errRead}) SetHandleInformation(h, HANDLE_FLAG_INHERIT, 0);

    SIZE_T attrSize = 0;
    InitializeProcThreadAttributeList(nullptr, 1, 0, &attrSize);
    std::vector<char> attrBuf(attrSize);
    auto* attrs = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(attrBuf.data());
    InitializeProcThreadAttributeList(attrs, 1, 0, &attrSize);
    HANDLE inheritList[3] = {inRead, outWrite, errWrite};
    UpdateProcThreadAttribute(attrs, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, inheritList, sizeof(inheritList), nullptr,
                              nullptr);

    STARTUPINFOEXW si{};
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdInput = inRead;
    si.StartupInfo.hStdOutput = outWrite;
    si.StartupInfo.hStdError = errWrite;
    si.lpAttributeList = attrs;

    std::wstring cmd;
    for (const std::string& a : argv) {
        if (!cmd.empty()) cmd += L" ";
        cmd += WinUtil::QuoteArg(WinUtil::Widen(a));
    }
    std::wstring env = SanitizedEnvironmentBlock();
    const std::wstring wcwd = WinUtil::Widen(cwd);

    HANDLE job = CreateJobObjectW(nullptr, nullptr);
    if (job) {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limits, sizeof(limits));
    }

    PROCESS_INFORMATION pi{};
    const BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE,
                                   EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT | CREATE_NO_WINDOW |
                                       CREATE_SUSPENDED,
                                   env.data(), wcwd.empty() ? nullptr : wcwd.c_str(), &si.StartupInfo, &pi);
    DeleteProcThreadAttributeList(attrs);
    CloseHandle(inRead);
    CloseHandle(outWrite);
    CloseHandle(errWrite);
    if (!ok) {
        CloseHandle(inWrite); CloseHandle(outRead); CloseHandle(errRead);
        if (job) CloseHandle(job);
        return result;
    }
    if (job) AssignProcessToJobObject(job, pi.hProcess);
    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);
    result.started = true;
    {
        std::lock_guard<std::mutex> lock(g_childrenMutex);
        g_children.insert(pi.hProcess);
    }

    // Stdin on its own thread: a screenshot payload is bigger than the pipe
    // buffer, and the CLI may print before it finishes reading.
    std::thread writer([inWrite, &input]() {
        const char* p = input.data();
        size_t left = input.size();
        while (left > 0) {
            DWORD n = 0;
            if (!WriteFile(inWrite, p, static_cast<DWORD>(std::min<size_t>(left, 1 << 16)), &n, nullptr) || n == 0) {
                break;
            }
            p += n;
            left -= n;
        }
        CloseHandle(inWrite);
    });

    struct Chunk {
        int stream;        // 0 = stdout, 1 = stderr
        std::string data;  // empty = that stream hit EOF
    };
    std::mutex qMutex;
    std::condition_variable qCv;
    std::deque<Chunk> queue;
    auto reader = [&](HANDLE h, int stream) {
        char buf[8192];
        for (;;) {
            DWORD n = 0;
            if (!ReadFile(h, buf, sizeof(buf), &n, nullptr) || n == 0) break;
            std::lock_guard<std::mutex> lock(qMutex);
            queue.push_back({stream, std::string(buf, n)});
            qCv.notify_one();
        }
        std::lock_guard<std::mutex> lock(qMutex);
        queue.push_back({stream, std::string()});
        qCv.notify_one();
    };
    std::thread outReader(reader, outRead, 0);
    std::thread errReader(reader, errRead, 1);

    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);
    int open = 2;
    size_t lineStart = 0;
    auto lastActivity = std::chrono::steady_clock::now();
    while (open > 0) {
        const auto now = std::chrono::steady_clock::now();
        auto limit = deadline;
        if (idleTimeoutSeconds > 0) {
            limit = std::min(limit, lastActivity + std::chrono::seconds(idleTimeoutSeconds));
        }
        if (limit <= now) {
            result.timedOut = true;
            result.wentIdle = limit < deadline;
            break;
        }
        if (shouldAbort && shouldAbort()) {
            result.timedOut = true;
            result.noText = true;
            break;
        }
        std::unique_lock<std::mutex> lock(qMutex);
        const auto wake = shouldAbort ? std::min(limit, now + std::chrono::seconds(1)) : limit;
        qCv.wait_until(lock, wake, [&] { return !queue.empty(); });
        while (!queue.empty()) {
            Chunk c = std::move(queue.front());
            queue.pop_front();
            lastActivity = std::chrono::steady_clock::now();
            if (c.data.empty()) {
                --open;
                continue;
            }
            (c.stream == 0 ? result.out : result.err) += c.data;
            if (c.stream == 0 && onStdoutLine) {
                size_t nl;
                while ((nl = result.out.find('\n', lineStart)) != std::string::npos) {
                    std::string line = result.out.substr(lineStart, nl - lineStart);
                    if (!line.empty() && line.back() == '\r') line.pop_back();
                    lock.unlock();
                    onStdoutLine(line);
                    lock.lock();
                    lineStart = nl + 1;
                }
            }
        }
    }

    if (result.timedOut) {
        if (job) TerminateJobObject(job, 1);
        else TerminateProcess(pi.hProcess, 1);
    }
    WaitForSingleObject(pi.hProcess, 5000);
    DWORD code = static_cast<DWORD>(-1);
    GetExitCodeProcess(pi.hProcess, &code);
    // The child is gone, so its pipe ends are closed: the readers finish,
    // and any blocked write has failed.
    outReader.join();
    errReader.join();
    writer.join();
    CloseHandle(outRead);
    CloseHandle(errRead);
    {
        std::lock_guard<std::mutex> lock(g_childrenMutex);
        g_children.erase(pi.hProcess);
    }
    CloseHandle(pi.hProcess);
    if (job) CloseHandle(job);
    result.exitStatus = static_cast<int>(code);
    return result;
}
#else
// Spawns `argv` with `input` on stdin, collecting stdout/stderr until exit
// or `timeoutSeconds`. argv goes straight to posix_spawn -- no shell -- so
// transcript text can never be interpreted as shell syntax, and the
// question travels over stdin so its length isn't bounded by ARG_MAX.
//
// `onStdoutLine`, if set, is called with each complete stdout line as it
// arrives (for streaming output); stdout is still accumulated in `out`.
//
// `idleTimeoutSeconds` (0 = off) gives up early if the process produces no
// output at all for that long: a streaming call emits events continuously
// while it's working, so silence means it's stuck, and there's no point
// waiting out the full timeout before falling back.
ProcessResult Run(const std::vector<std::string>& argv, const std::string& input, const std::string& cwd,
                  long timeoutSeconds, const std::function<void(const std::string&)>& onStdoutLine = nullptr,
                  long idleTimeoutSeconds = 0, const std::function<bool()>& shouldAbort = nullptr) {
    ProcessResult result;
    int inPipe[2], outPipe[2], errPipe[2];
    if (pipe(inPipe) != 0) return result;
    if (pipe(outPipe) != 0) {
        close(inPipe[0]); close(inPipe[1]);
        return result;
    }
    if (pipe(errPipe) != 0) {
        close(inPipe[0]); close(inPipe[1]); close(outPipe[0]); close(outPipe[1]);
        return result;
    }

    // Parent-side ends shouldn't leak into anything else this process
    // spawns either.
    for (int fd : {inPipe[1], outPipe[0], errPipe[0]}) fcntl(fd, F_SETFD, FD_CLOEXEC);

    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, inPipe[0], STDIN_FILENO);
    posix_spawn_file_actions_adddup2(&actions, outPipe[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, errPipe[1], STDERR_FILENO);
    for (int fd : {inPipe[0], inPipe[1], outPipe[0], outPipe[1], errPipe[0], errPipe[1]}) {
        posix_spawn_file_actions_addclose(&actions, fd);
    }
    posix_spawn_file_actions_addchdir_np(&actions, cwd.c_str());

    std::vector<char*> cargv;
    for (const std::string& a : argv) cargv.push_back(const_cast<char*>(a.c_str()));
    cargv.push_back(nullptr);

    const std::vector<std::string> env = SanitizedEnvironment();
    std::vector<char*> cenv;
    for (const std::string& v : env) cenv.push_back(const_cast<char*>(v.c_str()));
    cenv.push_back(nullptr);

    // POSIX_SPAWN_CLOEXEC_DEFAULT: the child inherits only the three
    // descriptors dup2'd above. Without it, two calls spawned at the same
    // moment from different threads (two questions arriving together, or a
    // question during notes) each inherited the *other's* stdin write end.
    // Neither CLI ever saw EOF on stdin, so both hung until the timeout and
    // the app fell back to the local model -- the intermittent failure seen
    // in testing. Reproduced with two concurrent ask() calls: both hung.
    posix_spawnattr_t attr;
    posix_spawnattr_init(&attr);
    posix_spawnattr_setflags(&attr, POSIX_SPAWN_CLOEXEC_DEFAULT);

    pid_t pid = 0;
    const int rc = posix_spawn(&pid, cargv[0], &actions, &attr, cargv.data(), cenv.data());
    posix_spawnattr_destroy(&attr);
    posix_spawn_file_actions_destroy(&actions);
    close(inPipe[0]);
    close(outPipe[1]);
    close(errPipe[1]);
    if (rc != 0) {
        close(inPipe[1]); close(outPipe[0]); close(errPipe[0]);
        return result;
    }
    result.started = true;
    {
        std::lock_guard<std::mutex> lock(g_childrenMutex);
        g_children.insert(pid);
    }

    // Written from its own thread: a screenshot payload is bigger than the
    // pipe buffer, and writing it all before draining stdout could deadlock
    // if the CLI prints output before it finishes reading its input.
    // F_SETNOSIGPIPE: if the CLI exits without reading stdin, a write would
    // otherwise raise SIGPIPE and kill the whole app.
    fcntl(inPipe[1], F_SETNOSIGPIPE, 1);
    const int writeFd = inPipe[1];
    std::thread writer([writeFd, &input]() {
        const char* p = input.data();
        size_t left = input.size();
        while (left > 0) {
            const ssize_t n = write(writeFd, p, left);
            if (n <= 0) break;
            p += n;
            left -= static_cast<size_t>(n);
        }
        close(writeFd);
    });

    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);
    pollfd fds[2] = {{outPipe[0], POLLIN, 0}, {errPipe[0], POLLIN, 0}};
    int open = 2;
    char buf[8192];
    size_t lineStart = 0;
    auto lastActivity = std::chrono::steady_clock::now();
    while (open > 0) {
        const auto now = std::chrono::steady_clock::now();
        auto limit = deadline;
        if (idleTimeoutSeconds > 0) {
            limit = std::min(limit, lastActivity + std::chrono::seconds(idleTimeoutSeconds));
        }
        const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(limit - now);
        if (remaining.count() <= 0) {
            result.timedOut = true;
            result.wentIdle = limit < deadline;
            break;
        }
        if (shouldAbort && shouldAbort()) {
            result.timedOut = true;
            result.noText = true;
            break;
        }
        // Wake at least once a second so shouldAbort is checked promptly.
        const long waitMs = std::min<long>(static_cast<long>(remaining.count()), shouldAbort ? 1000 : LONG_MAX);
        const int ready = poll(fds, 2, static_cast<int>(waitMs));
        if (ready < 0) break;
        if (ready > 0) lastActivity = std::chrono::steady_clock::now();
        for (int i = 0; i < 2; ++i) {
            if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            const ssize_t n = read(fds[i].fd, buf, sizeof(buf));
            if (n > 0) {
                (i == 0 ? result.out : result.err).append(buf, static_cast<size_t>(n));
                if (i == 0 && onStdoutLine) {
                    size_t nl;
                    while ((nl = result.out.find('\n', lineStart)) != std::string::npos) {
                        onStdoutLine(result.out.substr(lineStart, nl - lineStart));
                        lineStart = nl + 1;
                    }
                }
            } else {
                close(fds[i].fd);
                fds[i].fd = -1;
                --open;
            }
        }
    }
    for (pollfd& f : fds) {
        if (f.fd >= 0) close(f.fd);
    }

    if (result.timedOut) {
        kill(pid, SIGTERM);
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        kill(pid, SIGKILL);
    }
    int status = 0;
    waitpid(pid, &status, 0);
    {
        std::lock_guard<std::mutex> lock(g_childrenMutex);
        g_children.erase(pid);
    }
    // The child is gone, so any blocked write has failed and returned.
    writer.join();
    result.exitStatus = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    return result;
}
#endif

void CheckAvailabilityNow() {
    Availability state = Availability::No;
    const std::string binary = ClaudeBinaryPath();
    if (!binary.empty()) {
        const ProcessResult r = Run({binary, "auth", "status"}, "", NeutralWorkingDirectory(), 15);
        try {
            const nlohmann::json j = nlohmann::json::parse(r.out);
            if (j.value("loggedIn", false)) state = Availability::Yes;
        } catch (const nlohmann::json::exception&) {
        }
        LogCall(0, std::string("auth status: ") + (state == Availability::Yes ? "signed in" : "NOT signed in: " + r.out.substr(0, 150)), r.err);
    }
    g_availability.store(state);
    std::lock_guard<std::mutex> lock(g_checkedAtMutex);
    g_checkedAt = std::chrono::steady_clock::now();
}

bool CheckIsStale() {
    std::lock_guard<std::mutex> lock(g_checkedAtMutex);
    const auto interval =
        g_availability.load() == Availability::Yes ? kRecheckInterval : kRecheckIntervalWhenUnavailable;
    return g_checkedAt == std::chrono::steady_clock::time_point{} ||
           std::chrono::steady_clock::now() - g_checkedAt > interval;
}

std::chrono::steady_clock::duration SinceLastCheck() {
    std::lock_guard<std::mutex> lock(g_checkedAtMutex);
    if (g_checkedAt == std::chrono::steady_clock::time_point{}) return std::chrono::hours(1);
    return std::chrono::steady_clock::now() - g_checkedAt;
}

// RAII slot in the kMaxConcurrent limit. Waits rather than failing: a
// question queued for a second or two still beats falling back to the
// weaker local model.
class CallSlot {
public:
    CallSlot() {
        while (true) {
            {
                std::lock_guard<std::mutex> lock(g_slotMutex);
                if (g_activeCalls < kMaxConcurrent) {
                    ++g_activeCalls;
                    return;
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }
    ~CallSlot() {
        std::lock_guard<std::mutex> lock(g_slotMutex);
        --g_activeCalls;
    }
};

}  // namespace

namespace ClaudeCodeClient {

void refreshAsync() {
    bool expected = false;
    if (!g_checkInFlight.compare_exchange_strong(expected, true)) return;
    std::thread([]() {
        CheckAvailabilityNow();
        g_checkInFlight = false;
    }).detach();
}

bool isAvailable() {
    if (CheckIsStale()) refreshAsync();
    return g_availability.load() == Availability::Yes && limitedUntil() == 0 && backingOffUntil() == 0;
}

long long backingOffUntil() {
    const long long until = g_backoffUntil.load();
    if (until != 0 && NowSeconds() >= until) {
        g_backoffUntil = 0;  // cool-down over: the next question tries Claude again
        return 0;
    }
    return until;
}

bool isInstalled() {
    return !ClaudeBinaryPath().empty();
}

#ifdef _WIN32
bool openSetupInTerminal() {
    const std::string path = WinUtil::AppDataSubdir("") + "\\set-up-claude.ps1";
    FILE* f = _wfopen(WinUtil::Widen(path).c_str(), L"wb");
    if (!f) return false;
    // Runs in its own PowerShell window so the interactive sign-in works.
    // Uses Anthropic's official Windows installer, same as the macOS path.
    std::fputs(
        "$Host.UI.RawUI.WindowTitle = 'LectureNotes: set up Claude'\r\n"
        "Write-Host 'LectureNotes: set up Claude (optional)'\r\n"
        "Write-Host 'Needs a Claude plan that includes Claude Code (e.g. Pro or Max).'\r\n"
        "Write-Host ''\r\n"
        "$claude = Join-Path $env:USERPROFILE '.local\\bin\\claude.exe'\r\n"
        "if (-not (Test-Path $claude)) {\r\n"
        "  Write-Host \"Installing Claude Code with Anthropic's official installer...\"\r\n"
        "  try { irm https://claude.ai/install.ps1 | iex } catch { Write-Host \"Install failed: $_\" }\r\n"
        "}\r\n"
        "if (-not (Test-Path $claude)) { Write-Host ''; Write-Host 'Install failed.'; Read-Host 'Press Enter to close'; exit 1 }\r\n"
        "$status = (& $claude auth status 2>$null) | Out-String\r\n"
        "if ($status -match '\"loggedIn\":\\s*true') {\r\n"
        "  Write-Host 'Already signed in.'\r\n"
        "} else {\r\n"
        "  Write-Host 'Sign in with your Claude account in the browser window that opens.'\r\n"
        "  Write-Host ''\r\n"
        "  & $claude auth login --claudeai\r\n"
        "}\r\n"
        "Write-Host ''\r\n"
        "Write-Host 'Done. You can close this window; LectureNotes picks it up automatically.'\r\n"
        "Read-Host 'Press Enter to close'\r\n",
        f);
    std::fclose(f);
    return WinUtil::Launch("powershell.exe", {"-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path},
                           /*hidden=*/false);
}
#else
bool openSetupInTerminal() {
    const char* home = std::getenv("HOME");
    if (!home) return false;
    const std::string dir = std::string(home) + "/Library/Application Support/LectureNotes";
    mkdir(dir.c_str(), 0755);
    const std::string path = dir + "/set-up-claude.command";
    FILE* f = std::fopen(path.c_str(), "w");
    if (!f) return false;
    // A .command file opened through LaunchServices runs in Terminal without
    // any automation permission prompt, and interactive steps (the sign-in)
    // work there. Written by the app, so it carries no quarantine flag.
    std::fputs(
        "#!/bin/bash\n"
        "clear\n"
        "echo \"LectureNotes: set up Claude (optional)\"\n"
        "echo \"Needs a Claude plan that includes Claude Code (e.g. Pro or Max).\"\n"
        "echo\n"
        "CLAUDE=\"$HOME/.local/bin/claude\"\n"
        "[ -x \"$CLAUDE\" ] || CLAUDE=\"$(command -v claude 2>/dev/null)\"\n"
        "if [ -z \"$CLAUDE\" ] || [ ! -x \"$CLAUDE\" ]; then\n"
        "  echo \"Installing Claude Code with Anthropic's official installer...\"\n"
        "  curl -fsSL https://claude.ai/install.sh | bash || { echo; echo \"Install failed.\"; read -n1 -p \"Press any key to close.\"; exit 1; }\n"
        "  CLAUDE=\"$HOME/.local/bin/claude\"\n"
        "  echo\n"
        "fi\n"
        "if \"$CLAUDE\" auth status 2>/dev/null | grep -q '\"loggedIn\": true'; then\n"
        "  echo \"Already signed in.\"\n"
        "else\n"
        "  echo \"Sign in with your Claude account in the browser window that opens.\"\n"
        "  echo\n"
        "  \"$CLAUDE\" auth login --claudeai\n"
        "fi\n"
        "echo\n"
        "echo \"Done. You can close this window; LectureNotes picks it up automatically.\"\n",
        f);
    std::fclose(f);
    chmod(path.c_str(), 0755);
    const std::string cmd = "/usr/bin/open \"" + path + "\"";
    return std::system(cmd.c_str()) == 0;
}
#endif

bool isAvailableNow() {
    if (g_availability.load() != Availability::Yes && SinceLastCheck() > kSyncRecheckAfter) {
        // One check at a time: if another thread is already re-checking,
        // use the current state rather than stacking up auth-status runs
        // (each can take up to 15s if the CLI is mid-update).
        bool expected = false;
        if (g_checkInFlight.compare_exchange_strong(expected, true)) {
            CheckAvailabilityNow();
            g_checkInFlight = false;
        }
    }
    return isAvailable();
}

long long limitedUntil() {
    const long long until = g_limitedUntil.load();
    if (until != 0 && NowSeconds() >= until) {
        g_limitedUntil = 0;  // window has reset; try Claude again
        return 0;
    }
    return until;
}

float usageFraction() {
    return g_usageFraction.load();
}

#ifdef _WIN32
void cancelAll() {
    std::lock_guard<std::mutex> lock(g_childrenMutex);
    for (HANDLE h : g_children) TerminateProcess(h, 1);
}
#else
void cancelAll() {
    std::set<pid_t> children;
    {
        std::lock_guard<std::mutex> lock(g_childrenMutex);
        children = g_children;
    }
    for (pid_t pid : children) kill(pid, SIGTERM);
    if (children.empty()) return;
    // A CLI that's stuck (seen: blocked waiting on stdin) ignores SIGTERM,
    // so follow up with SIGKILL for anything still running -- Run() removes
    // a pid from g_children once it has been reaped.
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    std::lock_guard<std::mutex> lock(g_childrenMutex);
    for (pid_t pid : g_children) kill(pid, SIGKILL);
}
#endif

}  // namespace ClaudeCodeClient

namespace {

// Shared by ask() and askWithImage(). `payload` goes to the CLI's stdin:
// plain question text, or (when `jsonInput`) a stream-json user message.
std::string RunClaudeImpl(const std::string& payload, bool jsonInput, const std::string& system,
                          const std::string& effort, long timeoutSeconds,
                          const std::function<void(const std::string&)>& onPartial, std::string& stderrOut,
                          bool& stalled);

std::string RunClaude(const std::string& payload, bool jsonInput, const std::string& system,
                      const std::string& effort, long timeoutSeconds,
                      const std::function<void(const std::string&)>& onPartial) {
    const auto start = std::chrono::steady_clock::now();
    std::string stderrText;
    bool stalled = false;
    std::string result =
        RunClaudeImpl(payload, jsonInput, system, effort, timeoutSeconds, onPartial, stderrText, stalled);
    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    const bool failed = result.rfind("[error]", 0) == 0;
    std::string outcome = failed ? result.substr(0, 200) : "ok (" + std::to_string(result.size()) + " chars)";
    // Only stalls and connection-level failures count toward the breaker; an
    // answer-level error (is_error, empty result) means Claude is reachable.
    if (failed && stalled) {
        if (++g_consecutiveFailures >= kFailuresBeforeBackoff) {
            g_backoffUntil = NowSeconds() + std::chrono::duration_cast<std::chrono::seconds>(kBackoff).count();
            outcome += "  -> backing off to the local model for 3 min";
        }
    } else if (!failed) {
        g_consecutiveFailures = 0;
        g_backoffUntil = 0;
    }
    LogCall(seconds, outcome, stderrText);
    return result;
}

std::string RunClaudeImpl(const std::string& payload, bool jsonInput, const std::string& system,
                          const std::string& effort, long timeoutSeconds,
                          const std::function<void(const std::string&)>& onPartial, std::string& stderrOut,
                          bool& stalled) {
    const std::string binary = ClaudeBinaryPath();
    if (binary.empty()) {
        return "[error] Claude Code isn't installed.";
    }

    std::vector<std::string> argv = {
        binary,
        "-p",
        "--model", kModel,
        "--max-turns", "1",
        // The token savings: no tool definitions, no MCP servers, and the
        // app's own short prompt instead of Claude Code's agent prompt.
        "--tools", "",
        "--strict-mcp-config",
        "--system-prompt", system,
        // Not token savings, but wanted: don't run the user's personal
        // hooks on every question, and don't save lecture transcripts into
        // their Claude Code session history.
        "--setting-sources", "",
        "--disable-slash-commands",
        "--no-session-persistence",
    };
    if (!effort.empty()) {
        argv.push_back("--effort");
        argv.push_back(effort);
    }

    // Always streamed, even when the caller doesn't want partial text: the
    // stream is the only output mode that carries the rate-limit info used
    // to back off when the user's usage limit runs out. The final line is
    // the same "result" object the plain JSON mode would print.
    std::string streamed;
    std::string finalLine;
    // Any model output at all -- thinking included -- not just answer text:
    // at high effort (Think Harder) Opus can think for well over 20s before
    // writing any text, and that's progress, not a stall.
    bool sawModelOutput = false;
    for (const char* a : {"--output-format", "stream-json", "--verbose", "--include-partial-messages"}) {
        argv.push_back(a);
    }
    if (jsonInput) {
        argv.push_back("--input-format");
        argv.push_back("stream-json");
    }
    std::function<void(const std::string&)> onLine = [&](const std::string& line) {
        // One malformed or unexpected event (e.g. a null where a number was
        // expected) must not throw out of here: this runs on a detached
        // thread, where an escaped exception would kill the app.
        try {
            const nlohmann::json ev = nlohmann::json::parse(line);
            const std::string type = ev.value("type", std::string());
            if (type == "result") {
                finalLine = line;
            } else if (type == "rate_limit_event" && ev.contains("rate_limit_info")) {
                RecordRateLimitInfo(ev["rate_limit_info"]);
            } else if (type == "stream_event" && ev.contains("event")) {
                sawModelOutput = true;
                const nlohmann::json& e = ev["event"];
                if (e.value("type", std::string()) == "content_block_delta" && e.contains("delta") &&
                    e["delta"].value("type", std::string()) == "text_delta") {
                    streamed += e["delta"].value("text", std::string());
                    if (onPartial) onPartial(streamed);
                }
            }
        } catch (const nlohmann::json::exception&) {
        }
    };

    ProcessResult r;
    {
        CallSlot slot;
        const auto started = std::chrono::steady_clock::now();
        auto noTextYet = [&]() {
            return !sawModelOutput &&
                   std::chrono::steady_clock::now() - started > std::chrono::seconds(kFirstTextSeconds);
        };
        r = Run(argv, payload, NeutralWorkingDirectory(), timeoutSeconds, onLine, kIdleTimeoutSeconds, noTextYet);
    }
    stderrOut = r.err;
    if (!r.started) {
        stalled = true;
        return "[error] Couldn't start Claude Code.";
    }
    if (r.timedOut) {
        stalled = true;
        if (r.noText) {
            return "[error] Claude didn't start responding within " + std::to_string(kFirstTextSeconds) + "s.";
        }
        return r.wentIdle ? "[error] Claude stopped responding."
                          : "[error] Claude took longer than " + std::to_string(timeoutSeconds) + "s to answer.";
    }

    nlohmann::json j;
    try {
        j = nlohmann::json::parse(finalLine);
    } catch (const nlohmann::json::exception&) {
        // Typically "not logged in" or a CLI-level failure printed as text.
        // Mark unavailable so later questions go straight to the local model
        // instead of paying this failure every time; the periodic re-check
        // flips it back once the user signs in again.
        g_availability.store(Availability::No);
        stalled = true;
        const std::string detail = !r.err.empty() ? r.err : r.out;
        return "[error] Claude Code failed: " + detail.substr(0, 200);
    }

    const std::string text = (j.contains("result") && j["result"].is_string()) ? j["result"].get<std::string>() : "";
    // api_error_status is null on success, and json::value() throws on a
    // present-but-null key instead of returning the default.
    const bool rateLimited = j.contains("api_error_status") && j["api_error_status"].is_number() &&
                             j["api_error_status"].get<int>() == 429;
    const bool isError = j.contains("is_error") && j["is_error"].is_boolean() && j["is_error"].get<bool>();
    if (isError && rateLimited && ClaudeCodeClient::limitedUntil() == 0) {
        // Rejected for rate limiting without a rate_limit_event saying until
        // when: back off briefly rather than failing every question.
        g_limitedUntil = NowSeconds() + 10 * 60;
    }
    if (isError || text.empty()) {
        return "[error] Claude: " + (text.empty() ? std::string("empty response") : text.substr(0, 300));
    }
    return text;
}

}  // namespace

namespace ClaudeCodeClient {

std::string ask(const std::string& question, const std::string& system, const std::string& effort,
                long timeoutSeconds, const std::function<void(const std::string&)>& onPartial) {
    return RunClaude(question, /*jsonInput=*/false, system, effort, timeoutSeconds, onPartial);
}

std::string askWithImage(const std::vector<uint8_t>& pngBytes, const std::string& question,
                         const std::string& system, const std::string& effort, long timeoutSeconds,
                         const std::function<void(const std::string&)>& onPartial) {
    const nlohmann::json message = {
        {"type", "user"},
        {"message",
         {{"role", "user"},
          {"content",
           nlohmann::json::array({
               {{"type", "image"},
                {"source", {{"type", "base64"}, {"media_type", "image/png"}, {"data", base64Encode(pngBytes)}}}},
               {{"type", "text"}, {"text", question}},
           })}}},
    };
    return RunClaude(message.dump(-1, ' ', false, nlohmann::json::error_handler_t::replace) + "\n", /*jsonInput=*/true, system, effort, timeoutSeconds, onPartial);
}

}  // namespace ClaudeCodeClient
