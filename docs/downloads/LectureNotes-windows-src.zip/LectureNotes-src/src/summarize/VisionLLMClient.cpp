#include "VisionLLMClient.h"

#include <nlohmann/json.hpp>

#include "Base64.h"
#include "OllamaClient.h"

namespace {

// Deliberately the same model as LocalLLMClient's kModelName. Qwen3.5 is
// natively multimodal, so one resident model serves both Q&A and the
// camera: no second ~3GB model competing with whisper.cpp for memory, and
// no cold-load stall on a capture, because the Q&A path keeps it warm.
// Replaced qwen2.5vl:3b (2026-09-28, see experiments/ in this repo).
constexpr const char* kVisionModelName = "qwen3.5:4b";

// MUST match LocalLLMClient.cpp's kKeepAlive, since the two now share a
// model. Ollama's keep_alive is per-model and every request resets it, so
// the short "2m" this used back when it had its own model would make each
// camera capture quietly cut the always-warm Q&A model's lifetime to two
// minutes, and the next lecture question would stall on a reload.
constexpr const char* kKeepAlive = "30m";

constexpr const char* kSystemPrompt =
    "You are looking at a screenshot the user captured of something on their "
    "screen -- often a homework problem, code snippet, diagram, or question from "
    "a video or webpage. Read whatever text/math/code is in the image accurately, "
    "then explain it or solve it plainly and conversationally, the way a "
    "knowledgeable person would explain it out loud. If the user also typed a "
    "specific question, answer that question about the image directly. Keep it "
    "focused -- a clear explanation or worked solution, not a long essay. If "
    "it's a problem with a numeric result, finish with the result on its own "
    "last line starting with \"Answer:\".";

// Claude only -- see LocalLLMClient.cpp's kPlainTextRule for why the local
// model isn't given this.
constexpr const char* kPlainTextRule =
    "\n\nPlain text only -- this is shown in a simple text box, so no Markdown "
    "(no **, #, or backticks) and no LaTeX (no $, \\frac, ^{}). Write math "
    "inline with Unicode: 1.2 × 10⁻⁶ F, v², √2, Δx, θ, ≈.";

}  // namespace

std::string VisionLLMClient::systemPrompt() {
    return std::string(kSystemPrompt) + kPlainTextRule;
}

std::string VisionLLMClient::defaultPrompt() {
    return "Solve or explain what's shown in this image.";
}

std::string VisionLLMClient::analyze(const std::vector<uint8_t>& pngBytes, const std::string& question) {
    if (pngBytes.empty()) {
        return "[error] Screenshot capture failed. Check that Screen Recording permission is granted in "
               "System Settings > Privacy & Security > Screen Recording, then try again.";
    }

    const std::string prompt = question.empty() ? defaultPrompt() : question;

    nlohmann::json body = {
        {"model", kVisionModelName},
        {"prompt", prompt},
        {"system", kSystemPrompt},
        {"images", nlohmann::json::array({base64Encode(pngBytes)})},
        {"stream", false},
        {"keep_alive", kKeepAlive},
        // See LocalLLMClient.cpp: Qwen3.5 reasons at length by default,
        // far too slow for an interactive capture.
        {"think", false},
    };
    // Longer than the text model's 60s ceiling: images add prompt-processing
    // time, and if nothing has run for 30 minutes the model has to reload
    // before generating.
    return OllamaClient::generate(body, 90);
}
