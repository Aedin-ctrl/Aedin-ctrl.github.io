#pragma once

#include <nlohmann/json.hpp>
#include <string>

// Shared HTTP/error-handling layer for talking to Ollama's /api/generate
// endpoint -- used by both LocalLLMClient (text) and VisionLLMClient
// (vision), which each used to carry their own near-identical copy of
// this (WriteCallback, trim, curl setup, the same three failure modes).
// One place now for connection failures, non-2xx responses, and
// unparseable responses.
namespace OllamaClient {

// Sends `body` (a fully-assembled Ollama /api/generate request -- model,
// prompt, system, images, stream, keep_alive, whatever the caller needs)
// via blocking HTTP POST to localhost:11434 and returns the trimmed
// "response" field, or a string starting with "[error]" on any failure
// (connection, non-2xx status, unparseable response). A "model not
// found" response is annotated with an `ollama pull <model>` hint using
// body["model"].
std::string generate(const nlohmann::json& body, long timeoutSeconds);

}  // namespace OllamaClient
