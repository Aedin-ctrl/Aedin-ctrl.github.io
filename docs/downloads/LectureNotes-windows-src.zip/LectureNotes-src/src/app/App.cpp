#include "App.h"

#include "util/LocalTime.h"

#include <algorithm>
#include <cctype>
#include <ctime>
#include <deque>
#include <functional>
#include <thread>

#include "asr/QuestionDetector.h"
#include "audio/OutputRouter.h"
#include "setup/ClaudeKeyStore.h"
#include "setup/SetupChecker.h"
#include "storage/SessionWriter.h"
#include "summarize/ClaudeClient.h"
#include "summarize/ClaudeCodeClient.h"
#include "summarize/LocalLLMClient.h"
#include "summarize/Utf8.h"
#include "summarize/VisionLLMClient.h"

namespace {

struct RoutedAnswer {
    std::string text;
    bool failed = false;
    std::string answeredBy;
};

bool IsError(const std::string& answer) {
    return answer.rfind("[error]", 0) == 0;
}

// What the model actually receives: the question, preceded by what the
// speaker said just before it. Labelled as a raw transcript so the model
// treats garbled chunk-boundary fragments as noise rather than content.
std::string WithContext(const std::string& question, const std::string& context) {
    if (context.empty()) return question;
    return "Recent lecture transcript, just before the question (speech-to-text, may contain "
           "errors or repeated fragments):\n\"" + context + "\"\n\nQuestion: " + question;
}

// Every detected question goes to Claude when the user's own Claude Code is
// signed in on this machine, and to the local model otherwise. Any Claude
// failure (usage limit, logged out, offline, timeout) falls back to the
// local model for that question, so a lecture never gets a blank answer
// just because Claude was briefly unavailable.
// "local model (Claude limit reached, back at 6:20 AM)" when the user's
// Claude usage limit is why the local model answered.
std::string LocalLabel() {
    const long long limited = ClaudeCodeClient::limitedUntil();
    const long long backoff = ClaudeCodeClient::backingOffUntil();
    if (limited == 0 && backoff == 0) return "local model";
    const long long until = limited != 0 ? limited : backoff;
    const std::time_t t = static_cast<std::time_t>(until);
    const std::tm local = LocalTm(t);  // not std::localtime: called from several answer threads at once
    char when[16] = "";
    std::strftime(when, sizeof(when), "%-I:%M %p", &local);
    return std::string(limited != 0 ? "local model (Claude limit reached, back at "
                                    : "local model (Claude not responding, retrying at ") +
           when + ")";
}

RoutedAnswer AnswerQuestion(const std::string& rawQuestion, const std::string& context,
                            const std::function<void(const std::string&)>& onPartial) {
    const std::string question = WithContext(rawQuestion, context);
    if (ClaudeCodeClient::isAvailableNow()) {
        // Low effort: measured 12/12 on the Physics 2 benchmark, same as the
        // default effort, at the same ~6.5s, with fewer output tokens.
        // Streamed, so the first words show up in ~2-3s.
        std::string answer = ClaudeCodeClient::ask(question, LocalLLMClient::systemPrompt(), "low",
                                                   /*timeoutSeconds=*/60, onPartial);
        if (!IsError(answer)) {
            return {answer, false, "Claude Opus"};
        }
        std::string local = LocalLLMClient::ask(question);
        const std::string label = (ClaudeCodeClient::limitedUntil() || ClaudeCodeClient::backingOffUntil())
                                      ? LocalLabel()
                                      : "local model (Claude unavailable)";
        return {local, IsError(local), label};
    }
    std::string local = LocalLLMClient::ask(question);
    return {local, IsError(local), LocalLabel()};
}

}  // namespace

App::App()
    : themRing_(std::make_shared<RingBuffer>(16000 * 30)),
      meRing_(std::make_shared<RingBuffer>(16000 * 30)),
      store_(std::make_shared<TranscriptStore>()),
      qaStore_(std::make_shared<QAStore>()),
      generalStore_(std::make_shared<QAStore>()),
      documentStore_(std::make_shared<DocumentStore>()),
      docScanState_(std::make_shared<DocumentScanState>()),
      modelPath_(SetupChecker::whisperModelPath()) {
    // Resolve whether Claude Code is usable before the first question
    // arrives, so that question doesn't go to the local model by default.
    ClaudeCodeClient::refreshAsync();
}

void App::invalidateScan() {
    docScanState_->status.store(DocumentScanStatus::NotScanned, std::memory_order_release);
    LocalLLMClient::setReferenceContext("");
}

void App::addDocument(std::string filename, std::string text) {
    documentStore_->add(std::move(filename), std::move(text));
    invalidateScan();
}

void App::removeDocument(const std::string& id) {
    documentStore_->remove(id);
    invalidateScan();
}

void App::clearDocuments() {
    documentStore_->clear();
    invalidateScan();
}

void App::requestVisionAnalysis(std::vector<uint8_t> pngBytes, std::string question) {
    const std::string label = question.empty() ? "Screenshot" : question;
    std::string id = qaStore_->addPending(label, /*context=*/"", /*canThinkHarder=*/false);

    // Defensive: empty bytes means the capture itself already failed (e.g.
    // Screen Recording permission denied, or macOS < 14 where the feature
    // isn't available at all) -- fail immediately with a clear message
    // instead of spawning a thread just to have VisionLLMClient discover
    // the same thing and send a blank image to the model for nothing.
    if (pngBytes.empty()) {
        qaStore_->updateAnswer(
            id, "[error] Screenshot capture failed or isn't supported on this system.", true);
        SetupChecker::noteScreenCaptureFailed();
        return;
    }

    SetupChecker::noteScreenCaptureSucceeded();

    std::shared_ptr<QAStore> qaStore = qaStore_;
    std::thread([qaStore, id, pngBytes = std::move(pngBytes), question = std::move(question)]() {
        // Same routing as spoken questions: Claude when the user's Claude
        // Code is signed in (Opus read both benchmark screenshots correctly,
        // circuit diagram included), the local vision model otherwise or if
        // Claude fails.
        if (ClaudeCodeClient::isAvailableNow()) {
            const std::string prompt = question.empty() ? VisionLLMClient::defaultPrompt() : question;
            std::string answer = ClaudeCodeClient::askWithImage(
                pngBytes, prompt, VisionLLMClient::systemPrompt(), "low", /*timeoutSeconds=*/90,
                [&](const std::string& soFar) { qaStore->updatePartial(id, soFar); });
            if (!IsError(answer)) {
                qaStore->updateAnswer(id, answer, false, /*viaThinkHarder=*/false, "Claude Opus");
                return;
            }
        }
        std::string answer = VisionLLMClient::analyze(pngBytes, question);
        qaStore->updateAnswer(id, answer, IsError(answer), /*viaThinkHarder=*/false, LocalLabel());
    }).detach();
}

void App::askGeneral(std::string question) {
    std::string id = generalStore_->addPending(question);
    std::shared_ptr<QAStore> store = generalStore_;
    std::thread([store, id, question = std::move(question)]() {
        RoutedAnswer routed = AnswerQuestion(question, /*context=*/"", [&](const std::string& soFar) {
            store->updatePartial(id, soFar);
        });
        store->updateAnswer(id, routed.text, routed.failed, /*viaThinkHarder=*/false, routed.answeredBy);
    }).detach();
}

void App::requestThinkHarder(const std::string& id) {
    // Snapshot rather than holding qaStore_'s internal lock while reading
    // -- same reasoning as everywhere else in this file, just cheaper
    // here since the list is normally tiny (a handful of open tabs).
    const std::vector<QAEntry> snapshot = qaStore_->snapshot();
    const auto it = std::find_if(snapshot.begin(), snapshot.end(),
                                  [&](const QAEntry& e) { return e.id == id; });
    if (it == snapshot.end() || it->pending || it->rechecking || !it->canThinkHarder) {
        return;
    }
    const std::string question = WithContext(it->question, it->context);
    qaStore_->beginRecheck(id);

    std::shared_ptr<QAStore> qaStore = qaStore_;
    std::thread([qaStore, id, question]() {
        // Strongest backend available. With Claude Code signed in, the first
        // answer already came from Opus, so the retry asks Opus again with
        // more reasoning effort. Otherwise: Claude via API key if one's
        // configured, else the larger local model. Never the same fast model
        // re-checking its own answer, which tends to just repeat whatever
        // mistake it made the first time.
        std::string answer;
        std::string by;
        if (ClaudeCodeClient::isAvailableNow()) {
            answer = ClaudeCodeClient::ask(question, LocalLLMClient::systemPrompt(), "high",
                                           /*timeoutSeconds=*/120);
            by = "Claude Opus, high effort";
        }
        if (answer.empty() || IsError(answer)) {
            if (ClaudeKeyStore::hasKey()) {
                answer = ClaudeClient::ask(question);
                by = "Claude API";
            } else {
                answer = LocalLLMClient::askThinkHarder(question);
                by = "bigger local model";
            }
        }
        qaStore->updateAnswer(id, answer, IsError(answer), /*viaThinkHarder=*/true, by);
    }).detach();
}

void App::requestDocumentScan() {
    DocumentScanStatus current = docScanState_->status.load(std::memory_order_acquire);
    if (current == DocumentScanStatus::Scanning || current == DocumentScanStatus::Processing) {
        return;
    }
    docScanState_->status.store(DocumentScanStatus::Scanning, std::memory_order_release);

    // Captures shared_ptrs, not `this` -- same reasoning as
    // requestStart()'s background thread (see App.h): the user can quit
    // mid-scan, and this thread must not touch a destroyed App.
    std::shared_ptr<DocumentStore> documentStore = documentStore_;
    std::shared_ptr<DocumentScanState> scanState = docScanState_;

    std::thread([documentStore, scanState]() {
        std::string combined = documentStore->combinedContext();
        if (combined.empty()) {
            scanState->status.store(DocumentScanStatus::NotScanned, std::memory_order_release);
            return;
        }

        scanState->status.store(DocumentScanStatus::Processing, std::memory_order_release);
        std::string summary = LocalLLMClient::summarizeDocuments(combined);
        if (summary.rfind("[error]", 0) == 0) {
            {
                std::lock_guard<std::mutex> lock(scanState->errorMutex);
                scanState->error = summary;
            }
            scanState->status.store(DocumentScanStatus::Failed, std::memory_order_release);
            return;
        }

        LocalLLMClient::setReferenceContext(summary);
        scanState->status.store(DocumentScanStatus::Ready, std::memory_order_release);
    }).detach();
}

App::~App() {
    if (isRecording()) {
        stopRecording(/*userInitiated=*/false);
    }
    ClaudeCodeClient::cancelAll();
}

bool App::isRecording() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return recording_;
}

bool App::audioDeviceProblemDetected() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (!recording_) return false;
    if (themCapture_ && !themCapture_->isDeviceAlive()) return true;
    if (meCapture_ && !meCapture_->isDeviceAlive()) return true;
    return false;
}

std::string App::takeStartError() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    std::string err = std::move(startError_);
    startError_.clear();
    return err;
}

std::string App::takeStartNotice() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    std::string notice;
    notice.swap(startNotice_);
    return notice;
}

float App::themLevel() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return themCapture_ ? themCapture_->currentLevelRMS() : 0.0f;
}

float App::meLevel() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return meCapture_ ? meCapture_->currentLevelRMS() : 0.0f;
}

void App::requestStart() {
    if (isStarting() || isRecording()) {
        return;
    }
    starting_.store(true, std::memory_order_release);

    // shared_ptr copies, not raw pointers: this thread (and the
    // per-question thread it spawns below) can legitimately outlive
    // `this` if the app quits while a model load or an LLM call is
    // still in flight. Holding shared_ptrs means that's just a delayed
    // release of these small objects instead of a use-after-free.
    std::shared_ptr<RingBuffer> themRing = themRing_;
    std::shared_ptr<RingBuffer> meRing = meRing_;
    std::shared_ptr<TranscriptStore> store = store_;
    std::shared_ptr<QAStore> qaStore = qaStore_;
    const std::string modelPath = modelPath_;

    std::thread([this, themRing, meRing, store, qaStore, modelPath]() {
        // The slow part: loading the whisper model from disk
        // (whisper_init_from_file_with_params), off the UI thread.
        auto worker = std::make_unique<WhisperWorker>(modelPath, *themRing, *meRing, *store);
        worker->setFallbackModel(SetupChecker::fastWhisperModelPath());

        // Auto-Q&A: any kept segment that looks like a question gets its
        // own tab immediately (shown as "pending") and its own
        // background thread to ask the local model, regardless of which
        // speaker it came from -- a question can come from what you're
        // listening to ("Them") or something you ask out loud yourself
        // ("Me"). Detached rather than tracked/joined so stopRecording()
        // can't block waiting on a slow call; the known tradeoff is that
        // an in-flight request could still be running if the app quits
        // mid-answer -- safe now that qaStore is a shared_ptr the thread
        // holds its own reference to, rather than a raw pointer into
        // App. QAStore::updateAnswer no-ops if the tab was already
        // closed by the time the answer comes back. Deliberately no
        // app-level concurrency limit on these threads: local-council
        // research concluded Ollama's default single-request-at-a-time
        // serialization is the safe default here (raising it risks
        // GPU/memory contention with whisper.cpp's own continuous Metal
        // transcription), and a bounded queue's main benefit -- accurate
        // "queued" vs. "thinking" UI state -- isn't worth the added
        // complexity yet.
        //
        // One-segment lookback per speaker, to catch multi-part questions
        // or slow speakers whose question spans two 8-second
        // transcription windows: whatever the *previous* kept segment
        // from that speaker was gets prepended once a "?" finally shows
        // up, then cleared. Bounded to just one segment back (not
        // unlimited accumulation) so an unrelated topic said a while ago
        // doesn't leak into a later, unrelated question. This callback
        // only ever runs on WhisperWorker's own single worker thread, one
        // call at a time, so the plain (non-atomic) strings below are
        // safe without their own lock.
        // The last few non-question segments per speaker. One segment isn't
        // enough: whisper's chunk boundaries regularly split a sentence and
        // re-transcribe the overlap as a garbled fragment, so the segment
        // right before a question can be junk while the numbers the
        // question depends on sit one or two segments earlier (seen in a
        // real end-to-end test, 2026-09-28).
        using Recent = std::deque<std::string>;
        auto recentBySpeaker = std::make_shared<std::pair<Recent, Recent>>();  // {me, them}
        auto lastAskedBySpeaker = std::make_shared<std::pair<std::string, std::string>>();
        worker->setOnSegment([qaStore, recentBySpeaker, lastAskedBySpeaker](Speaker speaker,
                                                                             const std::string& text) {
            Recent& recent = (speaker == Speaker::Me) ? recentBySpeaker->first : recentBySpeaker->second;
            std::string& lastAsked =
                (speaker == Speaker::Me) ? lastAskedBySpeaker->first : lastAskedBySpeaker->second;
            constexpr size_t kMaxSegments = 4;
            constexpr size_t kMaxContextChars = 600;

            auto keepAsContext = [&]() {
                recent.push_back(text);
                while (recent.size() > kMaxSegments) recent.pop_front();
            };
            std::string question;
            if (QuestionDetector::looksLikeQuestion(text)) {
                question = QuestionDetector::extractQuestion(text);
            } else {
                question = QuestionDetector::unpunctuatedQuestion(text);
                if (question.empty()) {
                    keepAsContext();
                    return;
                }
            }

            // Whisper often merges a spoken question together with
            // whatever was said right after it into one segment (e.g.
            // "What is your biggest weakness? Most people say...") --
            // keep just the question part, not the trailing continuation.
            // Classroom filler ("You see?", "..., right?") isn't worth a tab
            // or a Claude call, and a lecturer repeating the same question
            // shouldn't open a second one. Either way it's still context.
            std::string normalized;
            for (unsigned char c : question) {
                if (std::isalnum(c)) normalized += static_cast<char>(std::tolower(c));
            }
            if (!QuestionDetector::isWorthAnswering(question) || normalized == lastAsked) {
                keepAsContext();
                return;
            }
            lastAsked = normalized;
            std::string context;
            for (const std::string& segment : recent) {
                context += (context.empty() ? "" : " ") + segment;
            }
            context = Utf8::Tail(context, kMaxContextChars);
            recent.clear();

            std::string id = qaStore->addPending(question, context);
            std::thread([qaStore, id, question, context]() {
                RoutedAnswer routed = AnswerQuestion(question, context, [&](const std::string& soFar) {
                    qaStore->updatePartial(id, soFar);
                });
                qaStore->updateAnswer(id, routed.text, routed.failed, /*viaThinkHarder=*/false,
                                      routed.answeredBy);
            }).detach();
        });

        if (!worker->start()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            startError_ = worker->lastError();
            starting_.store(false, std::memory_order_release);
            return;
        }

        // Routes system audio through BlackHole so "Them" actually
        // receives something, while still reaching whatever the user is
        // really listening on (speakers, AirPods, anything) -- see
        // OutputRouter.h. Reversed in stopRecording().
        const std::string routeError = OutputRouter::routeThroughBlackHole();
        if (!routeError.empty()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            startError_ = "Failed to route system audio through BlackHole: " + routeError;
            worker->stop();
            starting_.store(false, std::memory_order_release);
            return;
        }

        auto them = std::make_unique<AudioCapture>("BlackHole", *themRing);
        if (!them->start()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            startError_ = "Failed to start \"Them\" (BlackHole) capture: " + them->lastError();
            worker->stop();
            OutputRouter::restoreOriginalOutput();
            starting_.store(false, std::memory_order_release);
            return;
        }

        // The mic is optional: a PC without one (or with it blocked) still
        // gets the lecture transcript, with a note saying why "Me" is silent.
        auto me = std::make_unique<AudioCapture>(std::string(), *meRing);
        if (!me->start()) {
            std::lock_guard<std::mutex> lock(stateMutex_);
            startNotice_ = "Recording the lecture audio only -- " + me->lastError();
            me.reset();
        }

        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            whisperWorker_ = std::move(worker);
            themCapture_ = std::move(them);
            meCapture_ = std::move(me);
            recording_ = true;
            startError_.clear();
        }
        // Best-effort: get the model loaded into memory now rather than
        // paying that cost on whatever question happens to be asked
        // first.
        LocalLLMClient::warmUp();
        starting_.store(false, std::memory_order_release);
    }).detach();
}

void App::stopRecording(bool userInitiated) {
    std::unique_ptr<AudioCapture> them;
    std::unique_ptr<AudioCapture> me;
    std::unique_ptr<WhisperWorker> worker;

    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        if (!recording_) {
            return;
        }
        them = std::move(themCapture_);
        me = std::move(meCapture_);
        worker = std::move(whisperWorker_);
        recording_ = false;
    }

    if (them) {
        them->stop();
    }
    if (me) {
        me->stop();
    }
    if (worker) {
        worker->stop();
    }

    // Restores whatever the user was actually listening on before
    // requestStart() rerouted through BlackHole -- see OutputRouter.h.
    // No-op (falls back to the built-in output) if that device isn't
    // available anymore, e.g. Bluetooth headphones were turned off
    // mid-recording.
    OutputRouter::restoreOriginalOutput();

    const std::vector<TranscriptSegment> segments = store_->snapshot();
    lastSavedPath_ = SessionWriter::writeTranscript(segments, qaStore_->snapshot());
    if (userInitiated) {
        generateNotes(segments, lastSavedPath_);
    }
}

void App::generateNotes(const std::vector<TranscriptSegment>& segments, const std::string& savedPath) {
    // Short sessions (a quick test, an accidental Start) aren't worth notes
    // or the Claude call.
    constexpr size_t kMinWords = 150;
    std::string transcript;
    size_t words = 0;
    for (const TranscriptSegment& seg : segments) {
        transcript += (seg.speaker == Speaker::Me ? "Me: " : "Lecturer: ") + seg.text + "\n";
        words += static_cast<size_t>(std::count(seg.text.begin(), seg.text.end(), ' ')) + 1;
    }
    if (words < kMinWords) return;

    std::shared_ptr<QAStore> qaStore = qaStore_;
    const std::string id = qaStore->addPending("Lecture notes", /*context=*/"", /*canThinkHarder=*/false);
    std::thread([qaStore, id, transcript, savedPath]() {
        std::string notes;
        std::string by;
        if (ClaudeCodeClient::isAvailableNow()) {
            notes = ClaudeCodeClient::ask(transcript, LocalLLMClient::notesSystemPrompt(), "low",
                                          /*timeoutSeconds=*/240,
                                          [&](const std::string& soFar) { qaStore->updatePartial(id, soFar); });
            by = "Claude Opus";
        }
        if (notes.empty() || IsError(notes)) {
            notes = LocalLLMClient::makeNotes(transcript);
            by = LocalLabel();
        }
        const bool failed = IsError(notes);
        qaStore->updateAnswer(id, notes, failed, /*viaThinkHarder=*/false, by);
        if (!failed && !savedPath.empty()) {
            SessionWriter::insertNotes(savedPath, notes);
        }
    }).detach();
}
