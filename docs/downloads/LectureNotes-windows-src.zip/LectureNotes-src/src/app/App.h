#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "audio/AudioCapture.h"
#include "audio/RingBuffer.h"
#include "asr/TranscriptStore.h"
#include "asr/WhisperWorker.h"
#include "qa/DocumentStore.h"
#include "qa/QAStore.h"

// Owns the dual audio capture pipelines, the shared whisper worker, and the
// transcript store; wires them together and exposes a small API for the UI.
class App {
public:
    App();
    ~App();

    // Kicks off recording on a background thread and returns immediately
    // -- loading the whisper model from disk is a multi-second blocking
    // call (whisper_init_from_file_with_params), and doing that
    // synchronously on the UI thread (the old startRecording() contract)
    // froze the whole window for however long it took, which looked like
    // the app hanging. The UI should show a "starting..." state while
    // isStarting() is true, then check isRecording()/takeStartError()
    // once it flips back to false.
    void requestStart();

    // Stops both captures and the whisper worker, then writes the transcript
    // to disk via SessionWriter, recording the resulting path. Synchronous:
    // unlike starting, stopping doesn't load anything and is expected to be
    // fast.
    // `userInitiated` is false for automatic stop+restart recovery (audio
    // device lost, sleep/wake) and app shutdown: those still save the
    // session but skip generating notes -- mid-lecture notes on a partial
    // session aren't wanted, and on quit the Claude call would outlive the
    // app and spend tokens on notes nobody sees. The transcript keeps
    // accumulating across restarts, so the final Stop's notes cover it all.
    void stopRecording(bool userInitiated = true);

    bool isStarting() const { return starting_.load(std::memory_order_acquire); }
    bool isRecording() const;
    // Returns the error from the last failed start attempt, if any, and
    // clears it -- so the UI shows it exactly once.
    std::string takeStartError();

    float themLevel() const;
    float meLevel() const;

    // True if recording is active and either audio capture's bound device
    // has actually died (see AudioCapture::isDeviceAlive) -- the UI polls
    // this once per frame and, on a rising edge, stops and restarts the
    // whole pipeline once rather than continuing to silently "record"
    // nothing from a dead device indefinitely.
    bool audioDeviceProblemDetected() const;

    std::vector<TranscriptSegment> transcriptSnapshot() const { return store_->snapshot(); }
    uint64_t transcriptVersion() const { return store_->version(); }
    const std::string& lastSavedPath() const { return lastSavedPath_; }

    std::vector<QAEntry> qaSnapshot() const { return qaStore_->snapshot(); }
    uint64_t qaVersion() const { return qaStore_->version(); }
    void closeQuestion(const std::string& id) { qaStore_->close(id); }

    // The permanent "gen" tab: questions the user types themselves. Answered
    // the same way as spoken ones (Claude, else the local model) but with no
    // lecture context, and kept in their own list so they don't open tabs.
    void askGeneral(std::string question);
    std::vector<QAEntry> generalSnapshot() const { return generalStore_->snapshot(); }
    uint64_t generalVersion() const { return generalStore_->version(); }

    // "Think harder" retry for an already-answered (or already-failed)
    // question: re-asks it through Claude (if the user configured an API
    // key in Setup) or, if not, a larger local model -- deliberately never
    // the same fast model re-checking its own work, since that tends to
    // just repeat whatever mistake it made the first time. No-op if `id`
    // is unknown, still pending, or already mid-recheck. Fire-and-forget
    // like requestVisionAnalysis, same shared_ptr-for-thread-lifetime
    // reasoning.
    void requestThinkHarder(const std::string& id);

    // Screen-region "solve this" flow (the camera button): a screenshot
    // the user framed with the capture overlay, plus whatever they
    // optionally typed, gets its own Q&A tab -- same QAStore/tab UI as a
    // spoken question, just a different source. Fire-and-forget like the
    // per-question threads in requestStart(); qaStore_ is already a
    // shared_ptr the spawned thread holds its own reference to, so this
    // is safe even if the app quits mid-analysis.
    void requestVisionAnalysis(std::vector<uint8_t> pngBytes, std::string question);

    // Resume/reference documents the user has uploaded. Adding, removing,
    // or clearing any of them invalidates whatever the model currently
    // knows (resets scan status to NotScanned and clears LocalLLMClient's
    // reference context) rather than leaving a stale summary in place
    // silently -- see DocumentStore.h's DocumentScanStatus comment.
    void addDocument(std::string filename, std::string text);
    void removeDocument(const std::string& id);
    void clearDocuments();
    std::vector<UploadedDocument> documentSnapshot() const { return documentStore_->snapshot(); }
    uint64_t documentVersion() const { return documentStore_->version(); }

    // Reads over every uploaded document and condenses them into the
    // local LLM's reference context (see LocalLLMClient::summarizeDocuments).
    // Async and fire-and-forget like requestStart(); poll
    // documentScanStatus() (and documentScanError() once it reports
    // Failed) from the UI. No-ops if a scan is already in flight.
    void requestDocumentScan();
    DocumentScanStatus documentScanStatus() const {
        return docScanState_->status.load(std::memory_order_acquire);
    }
    std::string documentScanError() const {
        std::lock_guard<std::mutex> lock(docScanState_->errorMutex);
        return docScanState_->error;
    }

private:
    // Turns the finished session's transcript into study notes in a
    // "Lecture notes" tab (Claude if available, local model otherwise) and
    // inserts them at the top of the saved session file. Runs in the
    // background; skipped for very short sessions.
    void generateNotes(const std::vector<TranscriptSegment>& segments, const std::string& savedPath);

    // Heap-allocated and reference-counted (not plain members) so a
    // detached background thread -- requestStart()'s outer thread while
    // it's still loading the whisper model, or the per-question thread
    // asking the local LLM -- can hold its own shared_ptr keeping these
    // alive even if the user quits the app mid-flight. Capturing raw
    // `&store_`/`&qaStore_` pointers into those threads (the previous
    // approach) was a real use-after-free if App was destroyed before
    // the thread finished; found via local-council audit, not a
    // hypothetical.
    std::shared_ptr<RingBuffer> themRing_;
    std::shared_ptr<RingBuffer> meRing_;
    std::shared_ptr<TranscriptStore> store_;
    std::shared_ptr<QAStore> qaStore_;
    std::shared_ptr<QAStore> generalStore_;
    std::shared_ptr<DocumentStore> documentStore_;

    // Same shared_ptr-for-thread-lifetime reasoning as above, for
    // requestDocumentScan()'s background thread: it needs to write the
    // scan's progress somewhere that survives App being destroyed mid-scan
    // (e.g. the user quits right after clicking "Scan").
    struct DocumentScanState {
        std::atomic<DocumentScanStatus> status{DocumentScanStatus::NotScanned};
        std::mutex errorMutex;
        std::string error;
    };
    std::shared_ptr<DocumentScanState> docScanState_;

    // Any edit to the uploaded document set invalidates whatever the
    // model currently knows -- rather than silently keep answering
    // questions against a now-stale summary, drop back to NotScanned and
    // clear the live reference context so it's obvious a re-scan is
    // needed.
    void invalidateScan();

    // Guards recording_, startError_, and the three unique_ptrs below --
    // requestStart()'s background thread writes them once when it
    // finishes (success or failure), while the UI thread reads them
    // every frame (isRecording(), meLevel(), themLevel(), stopRecording()).
    mutable std::mutex stateMutex_;
    std::unique_ptr<AudioCapture> themCapture_;
    std::unique_ptr<AudioCapture> meCapture_;
    std::unique_ptr<WhisperWorker> whisperWorker_;
    bool recording_ = false;
    std::string startError_;

    std::atomic<bool> starting_{false};

    std::string lastSavedPath_;
    std::string modelPath_;
};
