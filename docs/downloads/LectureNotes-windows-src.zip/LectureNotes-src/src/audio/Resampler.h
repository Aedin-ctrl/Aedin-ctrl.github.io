#pragma once

#include <cstddef>
#include <vector>

// Downmixes interleaved multi-channel float audio to mono (channel average)
// and linearly resamples it to a target sample rate (default 16 kHz).
//
// Carries fractional phase and one carried-over mono sample across calls so
// interpolation is continuous across audio-callback buffer boundaries,
// avoiding discontinuity clicks at chunk edges.
class Resampler {
public:
    Resampler(double sourceRate, int sourceChannels, double targetRate = 16000.0);

    // Downmixes `interleaved` (frameCount * sourceChannels_ samples) to mono,
    // resamples to targetRate_, and appends the result to `out`.
    void process(const float* interleaved, size_t frameCount, std::vector<float>& out);

    void reset();

private:
    double sourceRate_;
    int sourceChannels_;
    double targetRate_;
    double ratio_; // sourceRate_ / targetRate_

    double phase_;       // fractional position (in source-sample units) of the
                          // next output sample, relative to the carried sample
    float prevSample_;   // last mono sample from the previous call (for continuity)
    bool havePrev_;       // whether prevSample_ is valid yet
};
