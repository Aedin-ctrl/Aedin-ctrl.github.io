// Windows implementation of AudioCapture.h on WASAPI (shared mode,
// event-driven). The mic is the default capture device; "BlackHole" -- what
// App asks for as the lecture/system stream -- is loopback capture of the
// default speakers, which Windows supports natively (Win10 1703+ for
// event-driven loopback). Output is 16 kHz mono float, like macOS.

#include "AudioCapture.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <audioclient.h>
#include <mmdeviceapi.h>
#include <mmreg.h>

#include <cmath>
#include <cstdio>
#include <cstring>
#include <future>

namespace {

constexpr REFERENCE_TIME kBufferDuration = 2000000;  // 200 ms, in 100-ns units

// KSDATAFORMAT_SUBTYPE_IEEE_FLOAT / _PCM, defined here so no extra import
// library is needed.
const GUID kSubtypeFloat = {0x00000003, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};
const GUID kSubtypePcm = {0x00000001, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};

enum class SampleKind { Float32, Int16, Int24, Int32, Unsupported };

SampleKind KindOf(const WAVEFORMATEX* wfx) {
    WORD tag = wfx->wFormatTag;
    if (tag == WAVE_FORMAT_EXTENSIBLE) {
        const auto* ext = reinterpret_cast<const WAVEFORMATEXTENSIBLE*>(wfx);
        if (IsEqualGUID(ext->SubFormat, kSubtypeFloat)) tag = WAVE_FORMAT_IEEE_FLOAT;
        else if (IsEqualGUID(ext->SubFormat, kSubtypePcm)) tag = WAVE_FORMAT_PCM;
    }
    if (tag == WAVE_FORMAT_IEEE_FLOAT && wfx->wBitsPerSample == 32) return SampleKind::Float32;
    if (tag == WAVE_FORMAT_PCM) {
        if (wfx->wBitsPerSample == 16) return SampleKind::Int16;
        if (wfx->wBitsPerSample == 24) return SampleKind::Int24;
        if (wfx->wBitsPerSample == 32) return SampleKind::Int32;
    }
    return SampleKind::Unsupported;
}

void ToFloat(const BYTE* src, size_t samples, SampleKind kind, float* dst) {
    switch (kind) {
        case SampleKind::Float32:
            std::memcpy(dst, src, samples * sizeof(float));
            break;
        case SampleKind::Int16: {
            const auto* p = reinterpret_cast<const int16_t*>(src);
            for (size_t i = 0; i < samples; ++i) dst[i] = p[i] / 32768.0f;
            break;
        }
        case SampleKind::Int24:
            for (size_t i = 0; i < samples; ++i) {
                const BYTE* b = src + i * 3;
                int32_t v = (int32_t(b[0]) << 8) | (int32_t(b[1]) << 16) | (int32_t(b[2]) << 24);
                dst[i] = (v >> 8) / 8388608.0f;
            }
            break;
        case SampleKind::Int32: {
            const auto* p = reinterpret_cast<const int32_t*>(src);
            for (size_t i = 0; i < samples; ++i) dst[i] = static_cast<float>(p[i] / 2147483648.0);
            break;
        }
        case SampleKind::Unsupported:
            std::memset(dst, 0, samples * sizeof(float));
            break;
    }
}

template <typename T>
void SafeRelease(T*& p) {
    if (p) {
        p->Release();
        p = nullptr;
    }
}

}  // namespace

AudioCapture::AudioCapture(std::string deviceNameSubstring, RingBuffer& sink)
    : deviceNameSubstring_(std::move(deviceNameSubstring)), sink_(sink) {}

AudioCapture::~AudioCapture() {
    stop();
}

bool AudioCapture::start() {
    if (running_.load()) return true;
    stopRequested_ = false;
    deviceAlive_ = true;
    std::promise<std::string> started;  // empty string = success
    std::future<std::string> result = started.get_future();
    worker_ = std::thread([this, &started]() { captureThread(&started); });
    const std::string error = result.get();
    if (!error.empty()) {
        if (worker_.joinable()) worker_.join();
        lastError_ = error;
        return false;
    }
    running_ = true;
    return true;
}

void AudioCapture::stop() {
    stopRequested_ = true;
    if (worker_.joinable()) worker_.join();
    running_ = false;
    levelRms_ = 0.0f;
}

void AudioCapture::captureThread(void* startedPromise) {
    auto* started = static_cast<std::promise<std::string>*>(startedPromise);
    bool reported = false;
    auto report = [&](const std::string& error) {
        if (!reported) {
            reported = true;
            started->set_value(error);
        }
    };

    const bool loopback = deviceNameSubstring_ == "BlackHole";
    const HRESULT coInit = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IMMDeviceEnumerator* enumerator = nullptr;
    IMMDevice* device = nullptr;
    IAudioClient* client = nullptr;
    IAudioCaptureClient* capture = nullptr;
    WAVEFORMATEX* wfx = nullptr;
    HANDLE event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    HRESULT hr = S_OK;

    do {
        hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator),
                              reinterpret_cast<void**>(&enumerator));
        if (FAILED(hr)) {
            report("Windows audio isn't available (MMDeviceEnumerator failed).");
            break;
        }
        hr = enumerator->GetDefaultAudioEndpoint(loopback ? eRender : eCapture, eConsole, &device);
        if (FAILED(hr)) {
            report(loopback ? "No speakers/headphones found to record system audio from."
                            : "No microphone found. Plug one in or check Windows sound settings.");
            break;
        }
        hr = device->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(&client));
        if (SUCCEEDED(hr)) hr = client->GetMixFormat(&wfx);
        if (FAILED(hr)) {
            report("Couldn't open the audio device.");
            break;
        }
        const SampleKind kind = KindOf(wfx);
        if (kind == SampleKind::Unsupported) {
            report("Unsupported audio format on this device.");
            break;
        }
        DWORD flags = AUDCLNT_STREAMFLAGS_EVENTCALLBACK;
        if (loopback) flags |= AUDCLNT_STREAMFLAGS_LOOPBACK;
        hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, flags, kBufferDuration, 0, wfx, nullptr);
        if (hr == E_ACCESSDENIED) {
            report("Microphone access is blocked. Turn on \"Let desktop apps access your microphone\" in "
                   "Windows Settings > Privacy & security > Microphone.");
            break;
        }
        if (SUCCEEDED(hr)) hr = client->SetEventHandle(event);
        if (SUCCEEDED(hr)) hr = client->GetService(__uuidof(IAudioCaptureClient), reinterpret_cast<void**>(&capture));
        if (SUCCEEDED(hr)) hr = client->Start();
        if (FAILED(hr)) {
            report("Couldn't start audio capture (error 0x" + [&] {
                char buf[16];
                std::snprintf(buf, sizeof(buf), "%08lX", static_cast<unsigned long>(hr));
                return std::string(buf);
            }() + ").");
            break;
        }

        const int channels = wfx->nChannels;
        resampler_ = std::make_unique<Resampler>(static_cast<double>(wfx->nSamplesPerSec), channels, 16000.0);
        report("");

        while (!stopRequested_.load()) {
            // Loopback delivers no packets (and no events) while nothing is
            // playing; the timeout keeps stop() responsive and the meter honest.
            if (WaitForSingleObject(event, 200) == WAIT_TIMEOUT) {
                levelRms_.store(0.0f, std::memory_order_relaxed);
                continue;
            }
            UINT32 packet = 0;
            while (SUCCEEDED(hr = capture->GetNextPacketSize(&packet)) && packet > 0) {
                BYTE* data = nullptr;
                UINT32 frames = 0;
                DWORD bufferFlags = 0;
                hr = capture->GetBuffer(&data, &frames, &bufferFlags, nullptr, nullptr);
                if (FAILED(hr)) break;
                const size_t samples = static_cast<size_t>(frames) * channels;
                scratchBuffer_.resize(samples);
                if (bufferFlags & AUDCLNT_BUFFERFLAGS_SILENT) {
                    std::fill(scratchBuffer_.begin(), scratchBuffer_.end(), 0.0f);
                } else {
                    ToFloat(data, samples, kind, scratchBuffer_.data());
                }
                capture->ReleaseBuffer(frames);

                double sumSquares = 0.0;
                for (float s : scratchBuffer_) sumSquares += static_cast<double>(s) * s;
                levelRms_.store(samples ? static_cast<float>(std::sqrt(sumSquares / samples)) : 0.0f,
                                std::memory_order_relaxed);

                resampleOutScratch_.clear();
                resampler_->process(scratchBuffer_.data(), frames, resampleOutScratch_);
                if (!resampleOutScratch_.empty()) sink_.write(resampleOutScratch_.data(), resampleOutScratch_.size());
            }
            if (hr == AUDCLNT_E_DEVICE_INVALIDATED || hr == AUDCLNT_E_SERVICE_NOT_RUNNING) {
                // Unplugged/disabled or the audio service restarted: App sees
                // this and restarts the pipeline (same as macOS).
                deviceAlive_.store(false, std::memory_order_relaxed);
                break;
            }
        }
        client->Stop();
    } while (false);

    report(FAILED(hr) ? "Audio capture failed." : "");
    SafeRelease(capture);
    SafeRelease(client);
    SafeRelease(device);
    SafeRelease(enumerator);
    if (wfx) CoTaskMemFree(wfx);
    if (event) CloseHandle(event);
    if (SUCCEEDED(coInit)) CoUninitialize();
}
