#include "Resampler.h"

Resampler::Resampler(double sourceRate, int sourceChannels, double targetRate)
    : sourceRate_(sourceRate),
      sourceChannels_(sourceChannels > 0 ? sourceChannels : 1),
      targetRate_(targetRate),
      ratio_(sourceRate / targetRate),
      phase_(0.0),
      prevSample_(0.0f),
      havePrev_(false) {}

void Resampler::reset() {
    phase_ = 0.0;
    prevSample_ = 0.0f;
    havePrev_ = false;
}

void Resampler::process(const float* interleaved, size_t frameCount, std::vector<float>& out) {
    if (frameCount == 0) return;

    // Downmix to mono. We build a small working array consisting of the
    // carried-over previous sample (if any) followed by this call's mono
    // samples, so linear interpolation can look back across the boundary.
    std::vector<float> mono;
    mono.reserve(frameCount + 1);

    size_t startIdx = 0;
    if (havePrev_) {
        mono.push_back(prevSample_);
    } else if (frameCount > 0) {
        // No previous sample yet: seed with the first frame's downmix and
        // start phase at 0 relative to that seed (no interpolation before it).
        float sum = 0.0f;
        for (int c = 0; c < sourceChannels_; ++c) {
            sum += interleaved[c];
        }
        mono.push_back(sum / static_cast<float>(sourceChannels_));
        startIdx = 1;
        havePrev_ = true;
    }

    for (size_t f = startIdx; f < frameCount; ++f) {
        float sum = 0.0f;
        const float* frame = interleaved + f * sourceChannels_;
        for (int c = 0; c < sourceChannels_; ++c) {
            sum += frame[c];
        }
        mono.push_back(sum / static_cast<float>(sourceChannels_));
    }

    // mono[0] is the carried-over sample (position -1 relative to this
    // call's new samples), mono[1..] are the new samples at positions 0..N-1.
    // phase_ tracks the next output sample's position in this same coordinate
    // space (i.e. phase_ == 0 means "at mono[1]", phase_ == -1 means at mono[0]).
    size_t numNew = mono.size() - 1;
    if (numNew == 0) {
        return;
    }

    double pos = phase_; // position measured in source samples, 0 == mono[1]

    while (true) {
        // mono index for interpolation: idx0 = pos (relative to mono[1]),
        // actual array index = idx0 + 1.
        double arrIdxD = pos + 1.0;
        long idx0 = static_cast<long>(arrIdxD);
        double frac = arrIdxD - static_cast<double>(idx0);

        if (idx0 + 1 >= static_cast<long>(mono.size())) {
            break; // need more input data
        }
        if (idx0 < 0) {
            // Shouldn't happen since pos starts at/above -1, but guard anyway.
            pos += ratio_;
            continue;
        }

        float s0 = mono[static_cast<size_t>(idx0)];
        float s1 = mono[static_cast<size_t>(idx0 + 1)];
        float sample = static_cast<float>(s0 + (s1 - s0) * frac);
        out.push_back(sample);

        pos += ratio_;
    }

    // Update phase_ relative to the new "previous sample" (last element of mono),
    // which is at array position mono.size()-1, i.e. coordinate (mono.size()-2).
    double lastCoord = static_cast<double>(mono.size()) - 2.0;
    phase_ = pos - lastCoord;
    prevSample_ = mono.back();
}
