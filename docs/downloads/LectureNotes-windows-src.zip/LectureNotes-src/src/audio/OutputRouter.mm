#import <CoreAudio/CoreAudio.h>
#import <Foundation/Foundation.h>

#include "OutputRouter.h"

#include <vector>

namespace {

constexpr const char* kAggregateDeviceName = "LectureNotes Multi-Output";
constexpr const char* kAggregateDeviceUID = "com.aedinlai.lecturenotes.multioutput";

// Set by routeThroughBlackHole(), consumed and cleared by
// restoreOriginalOutput(). UID (not AudioDeviceID) survives the device
// being reconnected with a new ID during the gap between the two calls
// -- shouldn't happen across one recording session, but costs nothing to
// be robust to.
std::string g_savedOutputUID;
bool g_hasSavedOutput = false;

std::vector<AudioDeviceID> AllDevices() {
    AudioObjectPropertyAddress addr = {kAudioHardwarePropertyDevices, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    UInt32 size = 0;
    AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &addr, 0, NULL, &size);
    std::vector<AudioDeviceID> devices(size / sizeof(AudioDeviceID));
    if (!devices.empty()) {
        AudioObjectGetPropertyData(kAudioObjectSystemObject, &addr, 0, NULL, &size, devices.data());
    }
    return devices;
}

NSString* DeviceUID(AudioDeviceID device) {
    AudioObjectPropertyAddress addr = {kAudioDevicePropertyDeviceUID, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    CFStringRef uid = NULL;
    UInt32 size = sizeof(uid);
    OSStatus st = AudioObjectGetPropertyData(device, &addr, 0, NULL, &size, &uid);
    if (st != noErr || !uid) return nil;
    return (NSString*)CFBridgingRelease(uid);
}

NSString* DeviceName(AudioDeviceID device) {
    AudioObjectPropertyAddress addr = {kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    CFStringRef name = NULL;
    UInt32 size = sizeof(name);
    OSStatus st = AudioObjectGetPropertyData(device, &addr, 0, NULL, &size, &name);
    if (st != noErr || !name) return nil;
    return (NSString*)CFBridgingRelease(name);
}

bool IsBuiltIn(AudioDeviceID device) {
    AudioObjectPropertyAddress addr = {kAudioDevicePropertyTransportType, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    UInt32 transport = 0;
    UInt32 size = sizeof(transport);
    OSStatus st = AudioObjectGetPropertyData(device, &addr, 0, NULL, &size, &transport);
    return st == noErr && transport == kAudioDeviceTransportTypeBuiltIn;
}

UInt32 OutputChannelCount(AudioDeviceID device) {
    AudioObjectPropertyAddress addr = {kAudioDevicePropertyStreamConfiguration, kAudioDevicePropertyScopeOutput,
                                        kAudioObjectPropertyElementMain};
    UInt32 dataSize = 0;
    OSStatus st = AudioObjectGetPropertyDataSize(device, &addr, 0, NULL, &dataSize);
    if (st != noErr || dataSize == 0) return 0;
    std::vector<uint8_t> buf(dataSize);
    AudioBufferList* bufferList = reinterpret_cast<AudioBufferList*>(buf.data());
    st = AudioObjectGetPropertyData(device, &addr, 0, NULL, &dataSize, bufferList);
    if (st != noErr) return 0;
    UInt32 channels = 0;
    for (UInt32 i = 0; i < bufferList->mNumberBuffers; ++i) {
        channels += bufferList->mBuffers[i].mNumberChannels;
    }
    return channels;
}

AudioDeviceID FindDeviceByName(NSString* name) {
    for (AudioDeviceID device : AllDevices()) {
        NSString* candidate = DeviceName(device);
        if (candidate && [candidate isEqualToString:name]) return device;
    }
    return kAudioObjectUnknown;
}

AudioDeviceID FindDeviceByUID(NSString* uid) {
    if (!uid) return kAudioObjectUnknown;
    for (AudioDeviceID device : AllDevices()) {
        NSString* candidate = DeviceUID(device);
        if (candidate && [candidate isEqualToString:uid]) return device;
    }
    return kAudioObjectUnknown;
}

// Fallback when there's nothing sane to restore to (no saved UID, or the
// saved device disconnected while recording, e.g. Bluetooth headphones
// turned off) -- the one output device that's always physically present.
AudioDeviceID FindBuiltInOutputDevice() {
    for (AudioDeviceID device : AllDevices()) {
        if (IsBuiltIn(device) && OutputChannelCount(device) > 0) return device;
    }
    return kAudioObjectUnknown;
}

AudioDeviceID DefaultOutputDevice() {
    AudioObjectPropertyAddress addr = {kAudioHardwarePropertyDefaultOutputDevice, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    AudioDeviceID device = kAudioObjectUnknown;
    UInt32 size = sizeof(device);
    AudioObjectGetPropertyData(kAudioObjectSystemObject, &addr, 0, NULL, &size, &device);
    return device;
}

bool SetDefaultOutput(AudioDeviceID device, AudioObjectPropertySelector selector) {
    AudioObjectPropertyAddress addr = {selector, kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMain};
    OSStatus st = AudioObjectSetPropertyData(kAudioObjectSystemObject, &addr, 0, NULL, sizeof(AudioDeviceID), &device);
    return st == noErr;
}

void DestroyAggregateIfExists() {
    AudioDeviceID existing = FindDeviceByName(@(kAggregateDeviceName));
    if (existing != kAudioObjectUnknown) {
        AudioHardwareDestroyAggregateDevice(existing);
    }
}

}  // namespace

std::string OutputRouter::routeThroughBlackHole() {
    AudioDeviceID current = DefaultOutputDevice();
    NSString* currentName = DeviceName(current);
    const bool currentIsOurAggregate = currentName && [currentName isEqualToString:@(kAggregateDeviceName)];

    AudioDeviceID realOutput;
    if (currentIsOurAggregate) {
        // Leftover from a previous session that didn't clean up (e.g. a
        // crash mid-recording) -- nothing sane to remember as "what the
        // user was listening on", so fall back to the built-in output
        // and move the system off the stale aggregate device before
        // destroying it below.
        g_hasSavedOutput = false;
        realOutput = FindBuiltInOutputDevice();
        if (realOutput != kAudioObjectUnknown) {
            SetDefaultOutput(realOutput, kAudioHardwarePropertyDefaultOutputDevice);
            SetDefaultOutput(realOutput, kAudioHardwarePropertyDefaultSystemOutputDevice);
        }
    } else {
        realOutput = current;
        NSString* uid = DeviceUID(current);
        if (uid) {
            g_savedOutputUID = std::string([uid UTF8String]);
            g_hasSavedOutput = true;
        } else {
            g_hasSavedOutput = false;
        }
    }

    // Now safe to destroy any stale aggregate device -- it's no longer
    // the active default output.
    DestroyAggregateIfExists();

    AudioDeviceID blackhole = FindDeviceByName(@"BlackHole 2ch");
    if (blackhole == kAudioObjectUnknown) {
        return "BlackHole 2ch not found. Reinstall it and try again.";
    }
    if (realOutput == kAudioObjectUnknown) {
        return "Could not determine your current audio output device.";
    }

    NSString* blackholeUID = DeviceUID(blackhole);
    NSString* realUID = DeviceUID(realOutput);
    if (!blackholeUID || !realUID) {
        return "Could not read audio device identifiers.";
    }

    NSDictionary* subBlackhole = @{@kAudioSubDeviceUIDKey : blackholeUID};
    NSDictionary* subReal = @{@kAudioSubDeviceUIDKey : realUID};
    // Stacked == a Multi-Output Device (plays the same audio out of every
    // sub-device simultaneously -- both the real output and BlackHole),
    // as opposed to a plain Aggregate Device (which would just combine
    // their channels into one device instead).
    NSDictionary* description = @{
        @kAudioAggregateDeviceNameKey : @(kAggregateDeviceName),
        @kAudioAggregateDeviceUIDKey : @(kAggregateDeviceUID),
        @kAudioAggregateDeviceIsStackedKey : @YES,
        @kAudioAggregateDeviceMasterSubDeviceKey : realUID,
        @kAudioAggregateDeviceSubDeviceListKey : @[ subReal, subBlackhole ],
    };

    AudioDeviceID multiOutput = kAudioObjectUnknown;
    OSStatus st = AudioHardwareCreateAggregateDevice((__bridge CFDictionaryRef)description, &multiOutput);
    if (st != noErr) {
        return "Could not create the audio routing device (CoreAudio error " + std::to_string(st) + ").";
    }

    const bool ok1 = SetDefaultOutput(multiOutput, kAudioHardwarePropertyDefaultOutputDevice);
    const bool ok2 = SetDefaultOutput(multiOutput, kAudioHardwarePropertyDefaultSystemOutputDevice);
    if (!ok1 || !ok2) {
        return "Could not switch the system to the new audio routing device.";
    }
    return "";
}

void OutputRouter::restoreOriginalOutput() {
    AudioDeviceID restoreTo = kAudioObjectUnknown;
    if (g_hasSavedOutput && !g_savedOutputUID.empty()) {
        restoreTo = FindDeviceByUID(@(g_savedOutputUID.c_str()));
    }
    if (restoreTo == kAudioObjectUnknown) {
        // Saved device no longer present (e.g. Bluetooth headphones were
        // switched off mid-recording) -- fall back to the built-in
        // output rather than leaving the aggregate device selected.
        restoreTo = FindBuiltInOutputDevice();
    }
    if (restoreTo != kAudioObjectUnknown) {
        SetDefaultOutput(restoreTo, kAudioHardwarePropertyDefaultOutputDevice);
        SetDefaultOutput(restoreTo, kAudioHardwarePropertyDefaultSystemOutputDevice);
    }

    g_hasSavedOutput = false;
    g_savedOutputUID.clear();

    DestroyAggregateIfExists();
}
