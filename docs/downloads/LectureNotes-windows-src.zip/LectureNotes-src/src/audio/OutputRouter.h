#pragma once

#include <string>

// Dynamically routes system audio through BlackHole (so WhisperWorker's
// "Them" capture keeps working) while still reaching whatever the user is
// actually listening on right now -- built-in speakers, AirPods, any
// other output device -- instead of a hardcoded device name. See
// App::requestStart/stopRecording for when these are called.
//
// Not internally synchronized: relies on App already serializing
// start/stop (isStarting()/isRecording()), so routeThroughBlackHole() and
// restoreOriginalOutput() are never in flight at the same time.
namespace OutputRouter {

// Snapshots whatever the current default output device is (skipping over
// a leftover "LectureNotes Multi-Output" device from a previous session
// that didn't get torn down cleanly, e.g. a crash mid-recording), then
// creates a fresh Multi-Output aggregate device combining it with
// BlackHole 2ch and switches the default output/default system output to
// it. Returns an error string (empty on success).
std::string routeThroughBlackHole();

// Switches the default output and default system output back to
// whatever routeThroughBlackHole() snapshotted (falling back to the
// system's built-in output if that device is no longer present, e.g.
// Bluetooth headphones were turned off mid-recording), then destroys the
// aggregate device. Safe to call even if routeThroughBlackHole() was
// never called or failed.
void restoreOriginalOutput();

}  // namespace OutputRouter
