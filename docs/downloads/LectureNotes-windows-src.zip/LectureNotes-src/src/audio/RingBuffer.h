#pragma once

#include <atomic>
#include <cstddef>
#include <algorithm>
#include <vector>

// Lock-free single-producer/single-consumer float ring buffer.
// Fixed capacity. Producer (write) drops the oldest samples on overflow
// rather than blocking. Consumer (read) is non-blocking and returns the
// number of samples actually read.
class RingBuffer {
public:
    explicit RingBuffer(size_t capacity = 16000 * 30)
        : capacity_(capacity), buffer_(capacity), writeIdx_(0), readIdx_(0) {}

    // Producer side only.
    void write(const float* data, size_t count) {
        if (count == 0) return;

        // If the incoming chunk is larger than the whole buffer, only the
        // tail of it matters.
        if (count > capacity_) {
            data += (count - capacity_);
            count = capacity_;
        }

        size_t writePos = writeIdx_.load(std::memory_order_relaxed);

        for (size_t i = 0; i < count; ++i) {
            buffer_[(writePos + i) % capacity_] = data[i];
        }

        size_t newWritePos = writePos + count;
        size_t readPos = readIdx_.load(std::memory_order_acquire);
        size_t used = newWritePos - readPos; // samples logically stored

        if (used > capacity_) {
            // Overflow: drop oldest by advancing read index.
            size_t drop = used - capacity_;
            readIdx_.store(readPos + drop, std::memory_order_release);
        }

        writeIdx_.store(newWritePos, std::memory_order_release);
    }

    // Consumer side only. Returns number of samples actually read.
    size_t read(float* out, size_t maxCount) {
        size_t readPos = readIdx_.load(std::memory_order_relaxed);
        size_t writePos = writeIdx_.load(std::memory_order_acquire);
        size_t available = writePos - readPos;
        size_t toRead = std::min(available, maxCount);

        for (size_t i = 0; i < toRead; ++i) {
            out[i] = buffer_[(readPos + i) % capacity_];
        }

        readIdx_.store(readPos + toRead, std::memory_order_release);
        return toRead;
    }

    size_t availableSamples() const {
        size_t readPos = readIdx_.load(std::memory_order_acquire);
        size_t writePos = writeIdx_.load(std::memory_order_acquire);
        return writePos - readPos;
    }

    size_t capacity() const { return capacity_; }

private:
    size_t capacity_;
    std::vector<float> buffer_;
    std::atomic<size_t> writeIdx_;
    std::atomic<size_t> readIdx_;
};
