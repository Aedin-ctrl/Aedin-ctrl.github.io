// Windows: nothing to route. System audio is recorded with WASAPI loopback
// straight from the default speakers (see AudioCaptureWin.cpp), so what the
// user hears never has to go through a virtual device.

#include "OutputRouter.h"

namespace OutputRouter {

std::string routeThroughBlackHole() {
    return std::string();
}

void restoreOriginalOutput() {}

}  // namespace OutputRouter
