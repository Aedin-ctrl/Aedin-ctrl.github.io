#pragma once

#ifdef __APPLE__
#include <AudioUnit/AudioUnit.h>
#include <AudioToolbox/AudioToolbox.h>
#else
#include <thread>
#endif

#include <atomic>
#include <memory>
#include <string>
#include <vector>

#include "RingBuffer.h"
#include "Resampler.h"

// Captures audio from a CoreAudio device (either the system default input,
// or a specific device whose name contains `deviceNameSubstring`), resamples
// it to 16kHz mono, and pushes the result into a RingBuffer. Also tracks a
// live RMS level for UI metering.
class AudioCapture {
public:
    // If deviceNameSubstring is empty, the system default input device
    // (the mic) is used. Otherwise, kAudioHardwarePropertyDevices is
    // enumerated and the first device whose name contains the given
    // substring (case-sensitive) is used.
    //
    // On Windows, "BlackHole" (the name App passes for the lecture/system
    // audio stream) means WASAPI loopback of the default speakers instead:
    // Windows records system audio natively, no virtual driver needed.
    AudioCapture(std::string deviceNameSubstring, RingBuffer& sink);
    ~AudioCapture();

    AudioCapture(const AudioCapture&) = delete;
    AudioCapture& operator=(const AudioCapture&) = delete;

    // Finds the device, configures the AudioUnit, and starts capture.
    // Returns false on any failure; call lastError() for details.
    bool start();

    // Stops capture (safe to call even if not started / already stopped).
    void stop();

    bool isRunning() const { return running_.load(std::memory_order_acquire); }
    float currentLevelRMS() const { return levelRms_.load(std::memory_order_relaxed); }
    const std::string& lastError() const { return lastError_; }

    // False once the bound device has actually died mid-session (unplugged,
    // Bluetooth dropout, etc.) -- detected two ways: a
    // kAudioDevicePropertyDeviceIsAlive listener (the OS's own signal) and,
    // as a backstop, AudioUnitRender itself starting to fail every callback
    // (previously silently swallowed and never surfaced anywhere). App polls
    // this once per frame while recording so it can restart the pipeline
    // instead of transcribing silence indefinitely with no indication
    // anything went wrong.
    bool isDeviceAlive() const { return deviceAlive_.load(std::memory_order_relaxed); }

private:
#ifdef __APPLE__
    bool findDevice(AudioDeviceID& outDevice);
    bool setupAudioUnit(AudioDeviceID device);
    void teardownAudioUnit();

    static OSStatus renderCallback(void* inRefCon,
                                    AudioUnitRenderActionFlags* ioActionFlags,
                                    const AudioTimeStamp* inTimeStamp,
                                    UInt32 inBusNumber,
                                    UInt32 inNumberFrames,
                                    AudioBufferList* ioData);

    OSStatus handleInput(AudioUnitRenderActionFlags* ioActionFlags,
                          const AudioTimeStamp* inTimeStamp,
                          UInt32 inBusNumber,
                          UInt32 inNumberFrames);

    std::string deviceNameSubstring_;
    RingBuffer& sink_;

    AudioUnit audioUnit_ = nullptr;
    bool unitInitialized_ = false;

    // Cached in start(), never touched from the render callback except reads.
    double sourceSampleRate_ = 16000.0;
    UInt32 sourceChannels_ = 1;
    UInt32 maxFramesPerSlice_ = 4096;

    std::unique_ptr<Resampler> resampler_;
    std::vector<float> scratchBuffer_;      // reused AudioBufferList backing store
    std::vector<float> resampleOutScratch_; // reused output buffer for Resampler::process

    std::atomic<float> levelRms_{0.0f};
    std::atomic<bool> running_{false};
    std::atomic<bool> deviceAlive_{true};
    int consecutiveRenderFailures_ = 0;  // only touched from the realtime render thread

    // Needed to add/remove the device-alive property listener in
    // start()/teardownAudioUnit() -- kAudioObjectUnknown once torn down.
    AudioDeviceID boundDevice_ = 0;
    static OSStatus deviceAliveListener(AudioObjectID objectID, UInt32 numAddresses,
                                         const AudioObjectPropertyAddress* addresses, void* clientData);

#else
    // WASAPI capture thread: opens the stream, reports the result to start(),
    // then pumps packets into sink_ until stop().
    void captureThread(void* startedPromise);

    std::string deviceNameSubstring_;
    RingBuffer& sink_;
    std::thread worker_;
    std::atomic<bool> stopRequested_{false};
    std::unique_ptr<Resampler> resampler_;
    std::vector<float> scratchBuffer_;
    std::vector<float> resampleOutScratch_;
    std::atomic<float> levelRms_{0.0f};
    std::atomic<bool> running_{false};
    std::atomic<bool> deviceAlive_{true};
#endif

    std::string lastError_;
};
