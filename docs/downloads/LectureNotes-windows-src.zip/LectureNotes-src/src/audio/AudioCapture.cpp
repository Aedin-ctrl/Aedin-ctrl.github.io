#include "AudioCapture.h"

#include <CoreFoundation/CoreFoundation.h>

#include <cmath>
#include <cstdio>

namespace {

std::string cfStringToStd(CFStringRef cfStr) {
    if (!cfStr) return std::string();
    CFIndex length = CFStringGetLength(cfStr);
    CFIndex maxSize = CFStringGetMaximumSizeForEncoding(length, kCFStringEncodingUTF8) + 1;
    std::vector<char> buf(static_cast<size_t>(maxSize));
    if (CFStringGetCString(cfStr, buf.data(), maxSize, kCFStringEncodingUTF8)) {
        return std::string(buf.data());
    }
    return std::string();
}

std::string osStatusToString(OSStatus status) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%d", static_cast<int>(status));
    return std::string(buf);
}

} // namespace

// Fires when the OS itself detects the bound device died (unplugged,
// Bluetooth dropout, etc.) -- the intended, documented way to learn this,
// versus discovering it indirectly via render failures (handleInput's
// backstop below). Runs on a CoreAudio-managed thread, so it only ever
// touches the atomic flag, nothing else.
OSStatus AudioCapture::deviceAliveListener(AudioObjectID /*objectID*/, UInt32 /*numAddresses*/,
                                            const AudioObjectPropertyAddress* /*addresses*/, void* clientData) {
    auto* self = static_cast<AudioCapture*>(clientData);
    UInt32 alive = 1;
    UInt32 size = sizeof(alive);
    AudioObjectPropertyAddress addr = {kAudioDevicePropertyDeviceIsAlive, kAudioObjectPropertyScopeGlobal,
                                        kAudioObjectPropertyElementMain};
    OSStatus err = AudioObjectGetPropertyData(self->boundDevice_, &addr, 0, nullptr, &size, &alive);
    if (err == noErr && alive == 0) {
        self->deviceAlive_.store(false, std::memory_order_relaxed);
    }
    return noErr;
}

AudioCapture::AudioCapture(std::string deviceNameSubstring, RingBuffer& sink)
    : deviceNameSubstring_(std::move(deviceNameSubstring)), sink_(sink) {}

AudioCapture::~AudioCapture() {
    stop();
}

bool AudioCapture::findDevice(AudioDeviceID& outDevice) {
    if (deviceNameSubstring_.empty()) {
        AudioObjectPropertyAddress addr = {
            kAudioHardwarePropertyDefaultInputDevice,
            kAudioObjectPropertyScopeGlobal,
            kAudioObjectPropertyElementMain
        };
        AudioDeviceID deviceId = kAudioObjectUnknown;
        UInt32 size = sizeof(deviceId);
        OSStatus err = AudioObjectGetPropertyData(kAudioObjectSystemObject, &addr, 0, nullptr, &size, &deviceId);
        if (err != noErr || deviceId == kAudioObjectUnknown) {
            lastError_ = "Could not find default input device (mic). CoreAudio error " + osStatusToString(err);
            return false;
        }
        outDevice = deviceId;
        return true;
    }

    AudioObjectPropertyAddress addr = {
        kAudioHardwarePropertyDevices,
        kAudioObjectPropertyScopeGlobal,
        kAudioObjectPropertyElementMain
    };

    UInt32 dataSize = 0;
    OSStatus err = AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &addr, 0, nullptr, &dataSize);
    if (err != noErr || dataSize == 0) {
        lastError_ = "Could not enumerate audio devices. CoreAudio error " + osStatusToString(err);
        return false;
    }

    size_t deviceCount = dataSize / sizeof(AudioDeviceID);
    std::vector<AudioDeviceID> devices(deviceCount);
    err = AudioObjectGetPropertyData(kAudioObjectSystemObject, &addr, 0, nullptr, &dataSize, devices.data());
    if (err != noErr) {
        lastError_ = "Could not read audio device list. CoreAudio error " + osStatusToString(err);
        return false;
    }

    for (AudioDeviceID device : devices) {
        AudioObjectPropertyAddress nameAddr = {
            kAudioObjectPropertyName,
            kAudioObjectPropertyScopeGlobal,
            kAudioObjectPropertyElementMain
        };
        CFStringRef nameRef = nullptr;
        UInt32 nameSize = sizeof(nameRef);
        OSStatus nameErr = AudioObjectGetPropertyData(device, &nameAddr, 0, nullptr, &nameSize, &nameRef);
        if (nameErr != noErr || !nameRef) continue;

        std::string name = cfStringToStd(nameRef);
        CFRelease(nameRef);

        if (name.find(deviceNameSubstring_) != std::string::npos) {
            outDevice = device;
            return true;
        }
    }

    lastError_ = "Audio device matching \"" + deviceNameSubstring_ + "\" was not found. "
                 "If this is BlackHole, install it (brew install blackhole-2ch) and reboot, "
                 "then try again.";
    return false;
}

bool AudioCapture::setupAudioUnit(AudioDeviceID device) {
    AudioComponentDescription desc = {};
    desc.componentType = kAudioUnitType_Output;
    desc.componentSubType = kAudioUnitSubType_HALOutput;
    desc.componentManufacturer = kAudioUnitManufacturer_Apple;
    desc.componentFlags = 0;
    desc.componentFlagsMask = 0;

    AudioComponent comp = AudioComponentFindNext(nullptr, &desc);
    if (!comp) {
        lastError_ = "Could not find AUHAL audio component.";
        return false;
    }

    OSStatus err = AudioComponentInstanceNew(comp, &audioUnit_);
    if (err != noErr || !audioUnit_) {
        lastError_ = "Could not instantiate AUHAL audio unit. CoreAudio error " + osStatusToString(err);
        return false;
    }

    // Enable input on element 1, disable output on element 0.
    UInt32 enableIO = 1;
    err = AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_EnableIO,
                                kAudioUnitScope_Input, 1, &enableIO, sizeof(enableIO));
    if (err != noErr) {
        lastError_ = "Could not enable input IO. CoreAudio error " + osStatusToString(err);
        return false;
    }

    UInt32 disableIO = 0;
    err = AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_EnableIO,
                                kAudioUnitScope_Output, 0, &disableIO, sizeof(disableIO));
    if (err != noErr) {
        lastError_ = "Could not disable output IO. CoreAudio error " + osStatusToString(err);
        return false;
    }

    // Bind to the chosen device.
    err = AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_CurrentDevice,
                                kAudioUnitScope_Global, 0, &device, sizeof(device));
    if (err != noErr) {
        lastError_ = "Could not set current device on audio unit. CoreAudio error " + osStatusToString(err);
        return false;
    }

    // Read the device's native input format so we know its sample rate/channels.
    AudioStreamBasicDescription nativeFormat = {};
    UInt32 nativeFormatSize = sizeof(nativeFormat);
    err = AudioUnitGetProperty(audioUnit_, kAudioUnitProperty_StreamFormat,
                                kAudioUnitScope_Input, 1, &nativeFormat, &nativeFormatSize);
    if (err != noErr) {
        lastError_ = "Could not read native input stream format. CoreAudio error " + osStatusToString(err);
        return false;
    }

    sourceSampleRate_ = nativeFormat.mSampleRate > 0 ? nativeFormat.mSampleRate : 44100.0;
    sourceChannels_ = nativeFormat.mChannelsPerFrame > 0 ? nativeFormat.mChannelsPerFrame : 1;

    // Request Float32 packed interleaved on the output scope of element 1 -
    // this is the format our render callback will read via AudioUnitRender.
    AudioStreamBasicDescription desiredFormat = {};
    desiredFormat.mSampleRate = sourceSampleRate_;
    desiredFormat.mFormatID = kAudioFormatLinearPCM;
    desiredFormat.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
    desiredFormat.mBitsPerChannel = 32;
    desiredFormat.mChannelsPerFrame = sourceChannels_;
    desiredFormat.mBytesPerFrame = sizeof(Float32) * sourceChannels_;
    desiredFormat.mFramesPerPacket = 1;
    desiredFormat.mBytesPerPacket = desiredFormat.mBytesPerFrame * desiredFormat.mFramesPerPacket;

    err = AudioUnitSetProperty(audioUnit_, kAudioUnitProperty_StreamFormat,
                                kAudioUnitScope_Output, 1, &desiredFormat, sizeof(desiredFormat));
    if (err != noErr) {
        lastError_ = "Could not set desired Float32 stream format. CoreAudio error " + osStatusToString(err);
        return false;
    }

    UInt32 maxFrames = 4096;
    UInt32 maxFramesSize = sizeof(maxFrames);
    err = AudioUnitGetProperty(audioUnit_, kAudioUnitProperty_MaximumFramesPerSlice,
                                kAudioUnitScope_Global, 0, &maxFrames, &maxFramesSize);
    if (err == noErr && maxFrames > 0) {
        maxFramesPerSlice_ = maxFrames;
    }

    // Leave headroom in case a callback requests more frames than advertised.
    scratchBuffer_.assign(static_cast<size_t>(maxFramesPerSlice_) * sourceChannels_ * 4, 0.0f);
    resampleOutScratch_.reserve(static_cast<size_t>(maxFramesPerSlice_) * 4);

    resampler_ = std::make_unique<Resampler>(sourceSampleRate_, static_cast<int>(sourceChannels_), 16000.0);

    AURenderCallbackStruct callback = {};
    callback.inputProc = &AudioCapture::renderCallback;
    callback.inputProcRefCon = this;
    err = AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_SetInputCallback,
                                kAudioUnitScope_Global, 0, &callback, sizeof(callback));
    if (err != noErr) {
        lastError_ = "Could not install input render callback. CoreAudio error " + osStatusToString(err);
        return false;
    }

    err = AudioUnitInitialize(audioUnit_);
    if (err != noErr) {
        lastError_ = "Could not initialize audio unit. CoreAudio error " + osStatusToString(err);
        return false;
    }
    unitInitialized_ = true;

    return true;
}

bool AudioCapture::start() {
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }

    lastError_.clear();

    AudioDeviceID device = kAudioObjectUnknown;
    if (!findDevice(device)) {
        return false; // lastError_ already set
    }

    if (!setupAudioUnit(device)) {
        teardownAudioUnit();
        return false;
    }

    OSStatus err = AudioOutputUnitStart(audioUnit_);
    if (err != noErr) {
        lastError_ = "Could not start audio unit. CoreAudio error " + osStatusToString(err);
        teardownAudioUnit();
        return false;
    }

    boundDevice_ = device;
    deviceAlive_.store(true, std::memory_order_relaxed);
    AudioObjectPropertyAddress aliveAddr = {kAudioDevicePropertyDeviceIsAlive, kAudioObjectPropertyScopeGlobal,
                                             kAudioObjectPropertyElementMain};
    AudioObjectAddPropertyListener(boundDevice_, &aliveAddr, &AudioCapture::deviceAliveListener, this);

    running_.store(true, std::memory_order_release);
    return true;
}

void AudioCapture::teardownAudioUnit() {
    if (boundDevice_ != 0) {
        AudioObjectPropertyAddress aliveAddr = {kAudioDevicePropertyDeviceIsAlive, kAudioObjectPropertyScopeGlobal,
                                                 kAudioObjectPropertyElementMain};
        AudioObjectRemovePropertyListener(boundDevice_, &aliveAddr, &AudioCapture::deviceAliveListener, this);
        boundDevice_ = 0;
    }
    if (audioUnit_) {
        if (unitInitialized_) {
            AudioUnitUninitialize(audioUnit_);
            unitInitialized_ = false;
        }
        AudioComponentInstanceDispose(audioUnit_);
        audioUnit_ = nullptr;
    }
}

void AudioCapture::stop() {
    if (!running_.exchange(false, std::memory_order_acq_rel)) {
        // Still allow teardown even if not "running" but partially set up.
        teardownAudioUnit();
        return;
    }
    if (audioUnit_) {
        AudioOutputUnitStop(audioUnit_);
    }
    teardownAudioUnit();
}

OSStatus AudioCapture::renderCallback(void* inRefCon,
                                       AudioUnitRenderActionFlags* ioActionFlags,
                                       const AudioTimeStamp* inTimeStamp,
                                       UInt32 inBusNumber,
                                       UInt32 inNumberFrames,
                                       AudioBufferList* /*ioData*/) {
    AudioCapture* self = static_cast<AudioCapture*>(inRefCon);
    return self->handleInput(ioActionFlags, inTimeStamp, inBusNumber, inNumberFrames);
}

OSStatus AudioCapture::handleInput(AudioUnitRenderActionFlags* ioActionFlags,
                                    const AudioTimeStamp* inTimeStamp,
                                    UInt32 inBusNumber,
                                    UInt32 inNumberFrames) {
    size_t neededSamples = static_cast<size_t>(inNumberFrames) * sourceChannels_;
    if (neededSamples > scratchBuffer_.size()) {
        // Defensive: unexpectedly large callback, skip this cycle rather than
        // touching memory we haven't sized for (no allocation in the RT thread).
        return noErr;
    }

    AudioBufferList bufferList;
    bufferList.mNumberBuffers = 1;
    bufferList.mBuffers[0].mNumberChannels = sourceChannels_;
    bufferList.mBuffers[0].mDataByteSize = static_cast<UInt32>(neededSamples * sizeof(float));
    bufferList.mBuffers[0].mData = scratchBuffer_.data();

    OSStatus err = AudioUnitRender(audioUnit_, ioActionFlags, inTimeStamp, inBusNumber, inNumberFrames, &bufferList);
    if (err != noErr) {
        // Backstop for the kAudioDevicePropertyDeviceIsAlive listener: some
        // failure modes (e.g. a Bluetooth device silently dropping out
        // without ever flipping "alive" to false) only ever show up here.
        // Previously this error was just returned and swallowed by the
        // caller with nothing else ever finding out; require a few
        // consecutive failures before concluding the device is really gone
        // rather than reacting to one harmless glitch.
        if (++consecutiveRenderFailures_ >= 5) {
            deviceAlive_.store(false, std::memory_order_relaxed);
        }
        return err;
    }
    consecutiveRenderFailures_ = 0;

    // RMS level across all channels/samples in this buffer for UI metering.
    double sumSquares = 0.0;
    for (size_t i = 0; i < neededSamples; ++i) {
        float s = scratchBuffer_[i];
        sumSquares += static_cast<double>(s) * static_cast<double>(s);
    }
    float rms = neededSamples > 0 ? static_cast<float>(std::sqrt(sumSquares / static_cast<double>(neededSamples))) : 0.0f;
    levelRms_.store(rms, std::memory_order_relaxed);

    resampleOutScratch_.clear();
    resampler_->process(scratchBuffer_.data(), inNumberFrames, resampleOutScratch_);
    if (!resampleOutScratch_.empty()) {
        sink_.write(resampleOutScratch_.data(), resampleOutScratch_.size());
    }

    return noErr;
}
