#pragma once

#include <string>

// Cleans one line of a model's answer for display in the plain-text answer
// view: strips Markdown (**bold**, # headings, `code`), turns "- " bullets
// into "• ", and converts LaTeX math into readable Unicode text
// (\frac{a}{b} -> (a)/(b), 10^{-6} -> 10⁻⁶, C_{1} -> C₁, \Omega -> Ω).
namespace AnswerText {

std::string CleanLine(std::string line);

}  // namespace AnswerText
