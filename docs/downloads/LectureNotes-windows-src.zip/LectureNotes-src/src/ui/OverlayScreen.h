#pragma once

// The overlay's whole ImGui UI, shared by the macOS (UIApp.mm) and Windows
// (WinApp.cpp) front ends. The front end owns the window, the GPU and the
// frame loop; each frame it calls draw() between ImGui::NewFrame() and
// ImGui::Render(). Anything platform-specific goes through OverlayHost.

#include <cstdint>
#include <string>
#include <vector>

#include "asr/TranscriptStore.h"
#include "qa/DocumentStore.h"
#include "qa/QAStore.h"

class App;

class OverlayHost {
public:
    virtual ~OverlayHost() = default;

    // Camera button. Return true to enter capture mode (the content area
    // goes see-through for framing); false with `error` set to explain why
    // not (e.g. missing permission).
    virtual bool beginScreenCapture(std::string& error) = 0;
    // Check button: capture the content rect (ImGui coordinates, top-left
    // origin, window-relative points) and hand it to App. Return false with
    // `error` set to stay in capture mode.
    virtual bool confirmScreenCapture(float x, float y, float width, float height, std::string& error) = 0;

    virtual void presentDocumentUploadPanel() = 0;
    virtual void quitApp() = 0;
    // The txt box was clicked: make the window receive typing.
    virtual void takeKeyboardFocus() = 0;
    // Called every frame with the content rect (same coordinates as above).
    virtual void contentRectChanged(float x, float y, float width, float height, bool captureMode) = 0;
    // Bottom-right grip: `started` on the first frame of a drag, `active`
    // while dragging. Resize the window, keeping its top-left corner fixed.
    virtual void resizeFromGrip(bool started, bool active, float minWidth, float minHeight) = 0;
};

class OverlayScreen {
public:
    OverlayScreen(App& app, OverlayHost& host);

    // Draws the full-window ImGui UI (Begin ... End).
    void draw();

    void willSleep();
    void didWake();

private:
    void beginScreenCapture();
    void confirmScreenCapture();
    void pollAudioHealthAndRecover();
    void drawResizeGrip();
    void drawMainUI();
    void drawGeneralTab();
    void drawDocumentsPanel();

    App* _app;
    OverlayHost& host_;

    std::string _lastError;
    std::string _selectedTabId = "transcript";  // "transcript", "general", or a QAEntry's id

    // Continuous redraw means these run at display refresh rate; the stores'
    // snapshots are full deep copies under a mutex, so cache the last one and
    // only re-fetch when the store's version() has changed. UINT64_MAX never
    // matches a real version, so the first frame always fetches.
    uint64_t _cachedTranscriptVersion = UINT64_MAX;
    std::vector<TranscriptSegment> _cachedTranscript;
    uint64_t _cachedQAVersion = UINT64_MAX;
    std::vector<QAEntry> _cachedQA;
    // "txt" tab: typed questions, their answers, and the input box.
    uint64_t _cachedGeneralVersion = UINT64_MAX;
    std::vector<QAEntry> _cachedGeneral;
    char _genInput[1024];
    bool _genInputActive = false;  // typing: don't yank the user to a new question tab
    bool _genFocusInput = false;
    bool _genScrollToNewest = false;
    uint64_t _cachedDocVersion = UINT64_MAX;
    std::vector<UploadedDocument> _cachedDocuments;

    bool _showDocumentsPanel = false;

    // True exactly while framing a screen capture: the corner button shows
    // check + cancel and the content area is see-through. The user reframes
    // by moving/resizing the window itself.
    bool _captureModeActive = false;

    // Content-area rect, refreshed every frame (see drawMainUI).
    float _contentRectX = 0;
    float _contentRectY = 0;
    float _contentRectWidth = 0;
    float _contentRectHeight = 0;

    bool _wasRecordingBeforeSleep = false;

    // Shown in green after an automatic recovery (sleep/wake, dead audio
    // device) so the user knows why recording restarted.
    std::string _lastNotice;

    // One recovery attempt per dead-device episode, not one per frame.
    bool _recoveringFromAudioProblem = false;
};
