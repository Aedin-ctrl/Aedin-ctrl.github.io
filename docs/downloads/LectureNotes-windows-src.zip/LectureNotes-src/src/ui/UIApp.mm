// Dear ImGui macOS + Metal front end.
//
// Structure adapted from Dear ImGui's official example_apple_metal/main.mm
// (see build/_deps/imgui-src/examples/example_apple_metal/main.mm), with the
// demo window replaced by our own UI and NSApplicationMain replaced by a
// manual NSApplication bring-up (no nib/storyboard needed for a pure-CMake
// build).
//
// Two separate windows, shown one at a time, sharing one ImGui context +
// Metal device (see EnsureImGuiInitialized/ApplyGlassStyle/ApplySetupStyle):
//   - SetupViewController: a normal opaque titled window with the first-run
//     checklist (mic/BlackHole/model) on the left and a locked preview of
//     the real app on the right, blocked by a red X until everything's
//     satisfied. Shown only when something's still missing.
//   - AppViewController: the actual note-taking app — borderless, genuinely
//     transparent (no blur/vibrancy layer), thin outlines instead of solid
//     fills, always-on-top overlay that can float over another app's
//     fullscreen Space. Shown directly (skipping setup entirely) once
//     everything checks out.

#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <PDFKit/PDFKit.h>
#import <QuartzCore/QuartzCore.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <sys/stat.h>

#include "imgui.h"
#include "imgui_impl_metal.h"
#include "imgui_impl_osx.h"

#include "app/App.h"
#include "asr/Speaker.h"
#include "capture/ScreenCapture.h"
#include "setup/ClaudeKeyStore.h"
#include <thread>

#include "setup/SetupChecker.h"
#include "ui/AnswerText.h"
#include "ui/Widgets.h"
#include "ui/OverlayScreen.h"
#include "ui/SetupScreen.h"
#include "summarize/ClaudeCodeClient.h"

namespace {

// Corner radius shared by the overlay NSWindow's clipping layer and its
// ImGui child panels — kept small (terminal-window scale) rather than a
// big glassy pill radius.
constexpr CGFloat kWindowCornerRadius = 9.0f;

// Extracts plain text from a resume/reference document at `url` for the
// "+" upload button, or empty on failure. PDFKit and NSAttributedString's
// document importers are both built into macOS -- no third-party PDF/DOCX
// parsing library needed for the common resume formats (this is the same
// machinery TextEdit uses to open a .docx).
std::string ExtractDocumentText(NSURL* url) {
    NSString* ext = [[url pathExtension] lowercaseString];

    if ([ext isEqualToString:@"pdf"]) {
        PDFDocument* doc = [[PDFDocument alloc] initWithURL:url];
        if (!doc) return "";
        NSMutableString* text = [NSMutableString string];
        for (NSUInteger i = 0; i < doc.pageCount; ++i) {
            NSString* pageText = [doc pageAtIndex:i].string;
            if (pageText) {
                [text appendString:pageText];
                [text appendString:@"\n"];
            }
        }
        const char* utf8 = [text UTF8String];
        return utf8 ? std::string(utf8) : std::string();
    }

    if ([ext isEqualToString:@"docx"] || [ext isEqualToString:@"doc"] ||
        [ext isEqualToString:@"rtf"] || [ext isEqualToString:@"rtfd"]) {
        NSError* error = nil;
        NSAttributedString* attr = [[NSAttributedString alloc] initWithURL:url
                                                                     options:@{}
                                                          documentAttributes:nil
                                                                       error:&error];
        if (!attr) return "";
        const char* utf8 = [attr.string UTF8String];
        return utf8 ? std::string(utf8) : std::string();
    }

    // Plain text, markdown, or anything else: try reading it as UTF-8 text.
    NSError* error = nil;
    NSString* raw = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    if (!raw) return "";
    const char* utf8 = [raw UTF8String];
    return utf8 ? std::string(utf8) : std::string();
}

// One shared ImGui context + Metal device + Dear ImGui Metal backend for
// the whole process: the Setup window and the overlay window are never
// shown at the same time, so there's no need for either its own ImGui
// context (each screen just applies its own ApplyGlassStyle/
// ApplySetupStyle at the top of its own drawInMTKView instead) or its own
// Metal device — only its own MTKView + command queue.
id<MTLDevice> g_sharedDevice = nil;
bool g_imguiInitialized = false;

id<MTLDevice> EnsureImGuiInitialized() {
    if (g_imguiInitialized) {
        return g_sharedDevice;
    }
    g_sharedDevice = MTLCreateSystemDefaultDevice();
    if (!g_sharedDevice) {
        NSLog(@"Metal is not supported on this device");
        abort();
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    LoadModernFont(NSScreen.mainScreen.backingScaleFactor);
    ImGui_ImplMetal_Init(g_sharedDevice);
    g_imguiInitialized = true;
    return g_sharedDevice;
}

} // namespace

#pragma mark - Overlay window/view subclasses (real click handling on a borderless window)

// A plain NSWindow with NSWindowStyleMaskBorderless defaults to
// canBecomeKeyWindow == NO (per Apple's docs: the default implementation
// returns YES only if the window has a title bar or resize bar).
// Overriding this is the standard fix for a custom borderless window that
// needs to behave like a real interactive window -- kept as a belt-and-
// suspenders fix even though it turned out not to be the cause of the
// click bug below.
// A non-activating panel: it can become the key window (so the txt tab's
// text box receives typing) without activating this app, so Zoom or
// whatever is in front stays the active app. It only becomes key when the
// text box asks for it (becomesKeyOnlyIfNeeded + makeKeyWindow in
// drawGeneralTab), so clicking Start/tabs never steals the keyboard.
@interface LNOverlayWindow : NSPanel
@end

@implementation LNOverlayWindow
- (BOOL)canBecomeKeyWindow { return YES; }
- (BOOL)canBecomeMainWindow { return YES; }
@end

// The actual bug: Dear ImGui's macOS backend (imgui_impl_osx.mm) only
// updates its tracked mouse position from NSEventTypeMouseMoved/
// *MouseDragged events -- the MouseDown/MouseUp handling in
// ImGui_ImplOSX_HandleEvent updates button state only, never position
// (confirmed by reading that file directly). A real physical mouse
// masks this because it naturally emits tiny "moved" events on the way
// to a click. A trackpad *tap* that doesn't slide at all does not: it's
// just Down then Up with no Moved event in between, so ImGui never
// learns where the tap landed and Button()/etc. never see it as a click
// on anything. Confirmed by testing: a synthetic click with no preceding
// move event silently did nothing; the same click preceded by a move
// worked immediately. Fix: feed position from the click events'  own
// locations too, not just Moved/Dragged, mirroring the coordinate-
// flipping logic in imgui_impl_osx.mm's own Moved handling.
@interface LNOverlayMTKView : MTKView
@end

@implementation LNOverlayMTKView

- (BOOL)acceptsFirstMouse:(NSEvent*)event { return YES; }

// Used by the position-feed monitor each view controller installs in
// viewDidLoad (see InstallMousePositionFeedMonitor below) -- NOT from a
// mouseDown:/mouseUp: override on this view, because by the time AppKit
// dispatches the event to this view's responder methods, Dear ImGui's own
// NSEvent local monitor (installed by ImGui_ImplOSX_Init) has *already*
// run and already queued the button-state change. Local monitors fire
// before normal responder dispatch, so a position update from inside
// mouseDown: always arrives one step too late for that click's hit-test.
- (void)feedMousePositionFromEvent:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (!self.isFlipped) {
        p = NSMakePoint(p.x, self.bounds.size.height - p.y);
    }
    ImGui::GetIO().AddMousePosEvent((float)p.x, (float)p.y);
}

@end

namespace {
// The real fix for taps not registering: install this BEFORE calling
// ImGui_ImplOSX_Init (see each view controller's viewDidLoad) so it runs
// first when both monitors match the same event -- local monitors fire
// in registration order. Feeds mouse position from the click event's own
// location, since Dear ImGui's OSX backend (imgui_impl_osx.mm) only ever
// updates tracked position from NSEventTypeMouseMoved/MouseDragged, never
// from MouseDown/MouseUp -- fine for a physical mouse (which emits tiny
// "moved" events on the way to any click) but not for a trackpad tap that
// doesn't slide at all, which is Down-then-Up with nothing in between.
// Confirmed by testing: a synthetic click with no preceding move event
// did nothing; the same click preceded by a move worked immediately.
id InstallMousePositionFeedMonitor(LNOverlayMTKView* view) {
    NSEventMask mask = NSEventMaskLeftMouseDown | NSEventMaskLeftMouseUp;
    return [NSEvent addLocalMonitorForEventsMatchingMask:mask
                                                  handler:^NSEvent*(NSEvent* event) {
                                                      if (event.window == view.window) {
                                                          [view feedMousePositionFromEvent:event];
                                                      }
                                                      return event;
                                                  }];
}
} // namespace

#pragma mark - AppViewController (the real, transparent overlay note-taking app)

@interface AppViewController : NSViewController<NSWindowDelegate>
@end

@interface AppViewController () <MTKViewDelegate>
@property (nonatomic, strong) MTKView* mtkView;
@property (nonatomic, strong) id<MTLDevice> device;
@property (nonatomic, strong) id<MTLCommandQueue> commandQueue;

// The single blurred backdrop is split into two independently-positioned
// NSVisualEffectViews -- one for the chrome strip (tab bar + Start/Stop
// row, always blurred), one for the content area below it (transcript or
// Q&A text normally; hidden during screen capture so that area becomes
// genuinely see-through, not just frosted). Repositioned every frame in
// drawMainUI to exactly match wherever ImGui's own layout puts the
// content area, so the split always lines up regardless of window size,
// tab, or an error message pushing content down a line.
@property (nonatomic, strong) NSVisualEffectView* chromeBlurView;
@property (nonatomic, strong) NSVisualEffectView* contentBlurView;
// Permanent margin strips around contentBlurView -- left/right span the
// full height below the chrome strip, marginBottomBlurView fills just the
// gap directly under the content rect. Together with chromeBlurView they
// tile the entire window with no seams, and unlike contentBlurView they
// are NEVER hidden -- during screen-capture mode only the exact content
// rect (contentBlurView) goes see-through; the surrounding margin stays
// blurred, matching the rest of the chrome.
@property (nonatomic, strong) NSVisualEffectView* marginLeftBlurView;
@property (nonatomic, strong) NSVisualEffectView* marginRightBlurView;
@property (nonatomic, strong) NSVisualEffectView* marginBottomBlurView;
@end

// Forwards OverlayScreen's platform requests to the view controller.
class MacOverlayHost : public OverlayHost {
public:
    explicit MacOverlayHost(AppViewController* controller) : controller_(controller) {}
    bool beginScreenCapture(std::string& error) override;
    bool confirmScreenCapture(float x, float y, float width, float height, std::string& error) override;
    void presentDocumentUploadPanel() override;
    void quitApp() override;
    void takeKeyboardFocus() override;
    void contentRectChanged(float x, float y, float width, float height, bool captureMode) override;
    void resizeFromGrip(bool started, bool active, float minWidth, float minHeight) override;

private:
    __weak AppViewController* controller_;
};

@implementation AppViewController {
    std::unique_ptr<App> _app;
    std::unique_ptr<MacOverlayHost> _host;
    std::unique_ptr<OverlayScreen> _screen;  // the shared ImGui UI (ui/OverlayScreen.h)
    id _mousePositionMonitor;

    // Anchors for the resize grip's drag math -- captured once when the
    // drag starts (see resizeFromGripStarted:).
    NSRect _resizeDragStartFrame;
    NSPoint _resizeDragStartMouseScreen;
}

// Opens a native multi-select file picker for resume/reference documents
// (see App::addDocument / DocumentStore). Uses NSOpenPanel's blocking
// runModal, same as any other one-off native dialog -- there's already no
// expectation of the UI staying responsive while this is up.
- (void)presentDocumentUploadPanel {
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = YES;
    panel.prompt = @"Upload";
    panel.message = @"Upload a resume or reference documents to help answer questions";

    if ([panel runModal] != NSModalResponseOK) {
        return;
    }
    for (NSURL* url in panel.URLs) {
        std::string text = ExtractDocumentText(url);
        if (text.empty()) continue;
        const char* nameUtf8 = [[url lastPathComponent] UTF8String];
        _app->addDocument(nameUtf8 ? std::string(nameUtf8) : std::string("document"), text);
    }
}

// The three states of the camera/"solve this" button (see the
// corner-button block in drawInMTKView): camera -> capture mode active
// (content area goes transparent, contentBlurView hidden, user reframes
// by moving/resizing this window itself) -> confirm (captures the
// current content rect + hands off to App::requestVisionAnalysis) or
// cancel (discards). _captureModeActive is the state itself.
- (bool)beginScreenCaptureWithError:(std::string&)error {
    // The capture feature needs ScreenCaptureKit's one-shot screenshot API
    // (SCScreenshotManager, macOS 14+) -- the only alternative APIs
    // (CGWindowListCreateImage, CGDisplayCreateImage/ForRect) are all fully
    // obsoleted on the macOS 15 SDK this project builds against, not just
    // deprecated, so there is no legacy fallback to compile against here.
    // A dlopen/dlsym-based workaround bypassing the SDK's own removal was
    // considered and rejected: it would rely on undocumented behavior
    // Apple has explicitly signaled is going away, for a benefit that only
    // matters on an OS version older than what this SDK can even target.
    // Gating clearly, rather than letting the button appear to work and
    // silently send a blank image, is the correct tradeoff.
    if (@available(macOS 14.0, *)) {
        if (SetupChecker::hasScreenRecordingPermission()) {
            return true;
        } else {
            // requestScreenRecordingAccess() now only ever triggers the OS
            // prompt once, ever (see SetupChecker.mm) -- so this is safe to
            // call on every attempt without re-nagging. If it's still not
            // granted afterward (either a decision is pending on the very
            // first ask, or it was already denied before), don't enter
            // capture mode against a permission we don't have -- show a
            // clear in-app message pointing at Settings instead.
            SetupChecker::requestScreenRecordingAccess();
            if (SetupChecker::hasScreenRecordingPermission()) {
                return true;
            } else {
                error =
                    "Screen Recording access is needed for this feature. Enable it for "
                    "LectureNotes in System Settings > Privacy & Security > Screen Recording, "
                    "then try again.";
            }
        }
    } else {
        error = "The screenshot/solve feature needs macOS 14 (Sonoma) or later.";
    }
    return false;
}

- (bool)confirmScreenCaptureX:(float)cx y:(float)cy width:(float)cw height:(float)ch error:(std::string&)error {
    NSWindow* window = self.view.window;
    NSScreen* screen = window.screen ?: NSScreen.mainScreen;
    const NSRect windowFrame = window.frame;

    // _contentRect* is in ImGui screen-space: top-left origin, points,
    // relative to the MTKView -- which exactly fills the window's
    // content area (borderless, no title bar), so windowFrame.origin is
    // directly the MTKView's own screen origin too. AppKit screen space
    // is bottom-left origin, so the y axis flips against the window's
    // own height first.
    const CGFloat appKitScreenX = windowFrame.origin.x + cx;
    const CGFloat appKitScreenY =
        windowFrame.origin.y + (windowFrame.size.height - cy - ch);
    const NSRect contentAppKitRect = NSMakeRect(appKitScreenX, appKitScreenY, cw, ch);

    // ScreenCapture.mm resolves a single SCDisplay from the capture
    // rect's origin point -- if the window straddles two monitors, that
    // would otherwise silently clip to whichever display owns the
    // top-left corner instead of erroring. Catch it here instead: leave
    // capture mode active (don't reset it below) so the user can just
    // drag the window back onto one screen and click the check again,
    // rather than having to reopen the camera button.
    if (!NSContainsRect(screen.frame, contentAppKitRect)) {
        error = "This region spans more than one display -- move the window fully onto a single screen and try again.";
        return false;
    }

    // Quartz global-display space (what ScreenCaptureKit wants) is
    // top-left origin again, but measured from the *main* display
    // regardless of which screen this window is on, so it flips a second
    // time against the main display's height.
    const CGFloat mainDisplayHeight = NSScreen.screens.firstObject.frame.size.height;

    ScreenRect rect;
    rect.x = appKitScreenX;
    rect.y = mainDisplayHeight - (appKitScreenY + ch);
    rect.width = cw;
    rect.height = ch;

    // No need to hide this window first (unlike a normal screenshot
    // tool): the content area is already rendering as genuine alpha=0 --
    // no ImGui fill, contentBlurView hidden -- so ScreenCaptureKit's
    // capture of that exact screen region already shows whatever's
    // behind us, the same way this window's transparency has always
    // worked. Capturing through our own window here is intentional,
    // not a bug to work around.
    const CGFloat scale = screen.backingScaleFactor ?: 1.0;
    const int pixelWidth = (int)(rect.width * scale);
    const int pixelHeight = (int)(rect.height * scale);

    App* appPtr = _app.get();
    ScreenCapture::captureRegionAsPNG(rect, pixelWidth, pixelHeight, [appPtr](std::vector<uint8_t> pngBytes) {
      appPtr->requestVisionAnalysis(std::move(pngBytes), std::string());
    });
    return true;
}

- (instancetype)initWithNibName:(nullable NSString*)nibNameOrNil bundle:(nullable NSBundle*)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    self.device = EnsureImGuiInitialized();
    self.commandQueue = [self.device newCommandQueue];

    _app = std::make_unique<App>();
    _host = std::make_unique<MacOverlayHost>(self);
    _screen = std::make_unique<OverlayScreen>(*_app, *_host);

    return self;
}

- (void)loadView {
    // Frosted/blurred (not fully transparent) per explicit user request:
    // legibility over an unpredictable background mattered more than the
    // earlier "genuinely transparent" look. NSVisualEffectView with
    // .behindWindow blending samples whatever's actually behind the
    // window (desktop, other apps) and blurs it -- inserted behind the
    // MTKView so the ImGui-drawn outline UI still renders on top of the
    // blur, not blurred itself.
    //
    // Split into two views (chrome strip + content area) rather than one
    // covering the whole window, so the content one alone can be hidden
    // during screen capture -- the "outer box stays styled, inner box
    // goes fully transparent" look requested for that feature. Both
    // start at a placeholder frame; drawMainUI repositions them every
    // frame to exactly match ImGui's own layout (see _contentRect*).
    NSView* container = [[NSView alloc] initWithFrame:CGRectMake(0, 0, 420, 320)];
    container.wantsLayer = YES;
    container.layer.cornerRadius = kWindowCornerRadius;
    container.layer.masksToBounds = YES;
    container.layer.backgroundColor = [NSColor clearColor].CGColor;
    container.layer.borderWidth = 1.0;
    container.layer.borderColor = [NSColor colorWithWhite:1.0 alpha:0.45].CGColor;

    // Light frosted glass (the text colors in Pal assume it), even when the
    // system is in dark mode.
    container.appearance = [NSAppearance appearanceNamed:NSAppearanceNameVibrantLight];
    self.chromeBlurView = [[NSVisualEffectView alloc] initWithFrame:NSMakeRect(0, 0, container.bounds.size.width, 0)];
    self.chromeBlurView.material = NSVisualEffectMaterialPopover;
    self.chromeBlurView.blendingMode = NSVisualEffectBlendingModeBehindWindow;
    self.chromeBlurView.state = NSVisualEffectStateActive;
    [container addSubview:self.chromeBlurView];

    self.contentBlurView = [[NSVisualEffectView alloc] initWithFrame:NSZeroRect];
    self.contentBlurView.material = NSVisualEffectMaterialPopover;
    self.contentBlurView.blendingMode = NSVisualEffectBlendingModeBehindWindow;
    self.contentBlurView.state = NSVisualEffectStateActive;
    [container addSubview:self.contentBlurView];

    self.marginLeftBlurView = [[NSVisualEffectView alloc] initWithFrame:NSZeroRect];
    self.marginRightBlurView = [[NSVisualEffectView alloc] initWithFrame:NSZeroRect];
    self.marginBottomBlurView = [[NSVisualEffectView alloc] initWithFrame:NSZeroRect];
    for (NSVisualEffectView* v in @[ self.marginLeftBlurView, self.marginRightBlurView, self.marginBottomBlurView ]) {
        v.material = NSVisualEffectMaterialPopover;
        v.blendingMode = NSVisualEffectBlendingModeBehindWindow;
        v.state = NSVisualEffectStateActive;
        [container addSubview:v];
    }

    self.mtkView = [[LNOverlayMTKView alloc] initWithFrame:container.bounds];
    self.mtkView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [container addSubview:self.mtkView];

    self.view = container;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.enableSetNeedsDisplay = YES;

    // Let whatever's behind the window show through anything ImGui
    // doesn't paint.
    self.mtkView.layer.opaque = NO;
    ((CAMetalLayer*)self.mtkView.layer).opaque = NO;
    self.mtkView.layer.backgroundColor = [NSColor clearColor].CGColor;

    // Must be installed before ImGui_ImplOSX_Init so it fires first (see
    // InstallMousePositionFeedMonitor's comment).
    _mousePositionMonitor = InstallMousePositionFeedMonitor((LNOverlayMTKView*)self.mtkView);
    ImGui_ImplOSX_Init(self.view);

    // Deliberately not calling [NSApp activateIgnoringOtherApps:YES] here:
    // fully activating this app is what was forcing macOS to switch back
    // to its own desktop Space even over a fullscreen app. Ordering just
    // this window to the front (done in AppDelegate via
    // makeKeyAndOrderFront, combined with the accessory activation policy
    // set once setup is done) lets it appear as an overlay in place
    // instead.

    // CoreAudio devices (especially AUHAL/aggregate ones, which is exactly
    // what OutputRouter builds) are known to come back in a zombie state
    // after system sleep -- the unit reports started but nothing actually
    // flows. Recording across a lid-close otherwise had no recovery path
    // at all.
    NSNotificationCenter* workspaceCenter = [[NSWorkspace sharedWorkspace] notificationCenter];
    [workspaceCenter addObserver:self
                         selector:@selector(handleWillSleep:)
                             name:NSWorkspaceWillSleepNotification
                           object:nil];
    [workspaceCenter addObserver:self
                         selector:@selector(handleDidWake:)
                             name:NSWorkspaceDidWakeNotification
                           object:nil];
}

- (void)handleWillSleep:(NSNotification*)notification {
    _screen->willSleep();
}

- (void)handleDidWake:(NSNotification*)notification {
    _screen->didWake();
}


- (void)drawInMTKView:(MTKView*)view {
    ApplyGlassStyle();

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.backingScaleFactor ?: NSScreen.mainScreen.backingScaleFactor;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor == nil) {
        [commandBuffer commit];
        return;
    }

    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui_ImplOSX_NewFrame(view);
    ImGui::NewFrame();

    _screen->draw();

    ImGui::Render();
    ImDrawData* drawData = ImGui::GetDrawData();

    // Fully transparent clear so whatever's behind the window shows
    // through everywhere ImGui itself doesn't draw translucent panels.
    renderPassDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 0);
    id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"Dear ImGui rendering"];
    ImGui_ImplMetal_RenderDrawData(drawData, commandBuffer, renderEncoder);
    [renderEncoder popDebugGroup];
    [renderEncoder endEncoding];

    [commandBuffer presentDrawable:view.currentDrawable];
    [commandBuffer commit];

    // UI updates from live audio/transcript state, not user input alone;
    // keep redrawing continuously rather than only on events.
    [view setNeedsDisplay:YES];
}

// Borderless windows don't reliably get the standard edge/corner
// resize-drag cursor and hit-testing that titled windows do, so this
// draws and drives a small manual grip in the bottom-right corner
// instead: an invisible drag button, plus two diagonal lines as a visual
// affordance, that directly resizes the NSWindow's frame on drag.
- (void)resizeFromGripStarted:(bool)started active:(bool)active minWidth:(float)minWidth minHeight:(float)minHeight {
    NSWindow* window = self.view.window;
    if (started) {
        // Anchor once, at drag start, to the window's frame and the
        // mouse's ABSOLUTE screen position -- not io.MouseDelta. Resizing
        // also moves the window's origin every frame (to keep the top-left
        // corner fixed), which shifts the coordinate frame NSEvent reports
        // the next mouse position in, so accumulating deltas compounded a
        // shift that had nothing to do with real mouse movement.
        _resizeDragStartFrame = window.frame;
        _resizeDragStartMouseScreen = [NSEvent mouseLocation];
    }
    if (active) {
        const NSPoint current = [NSEvent mouseLocation];
        const CGFloat dx = current.x - _resizeDragStartMouseScreen.x;         // + = mouse moved right
        const CGFloat downward = _resizeDragStartMouseScreen.y - current.y;   // + = mouse moved down
        const CGFloat newWidth = std::max<CGFloat>(_resizeDragStartFrame.size.width + dx, minWidth);
        const CGFloat newHeight = std::max<CGFloat>(_resizeDragStartFrame.size.height + downward, minHeight);
        // Keep the top-left corner fixed: the top edge's screen Y
        // (origin.y + height) must stay constant as height changes.
        const CGFloat newOriginY = _resizeDragStartFrame.origin.y + _resizeDragStartFrame.size.height - newHeight;
        [window setFrame:NSMakeRect(_resizeDragStartFrame.origin.x, newOriginY, newWidth, newHeight)
                 display:YES
                 animate:NO];
    }
}

// Lays the blur views out to match ImGui's layout (see OverlayScreen's
// content rect). Split so only the content rect goes see-through while
// framing a screen capture; the chrome strip and margins stay blurred.
- (void)layoutBlurForContentX:(float)x y:(float)y width:(float)w height:(float)h captureMode:(bool)captureMode {
    const ImGuiIO& io = ImGui::GetIO();
    self.chromeBlurView.frame = NSMakeRect(0, io.DisplaySize.y - y, io.DisplaySize.x, y);
    const CGFloat contentBottomY = io.DisplaySize.y - y - h;
    self.contentBlurView.frame = NSMakeRect(x, contentBottomY, w, h);
    self.contentBlurView.hidden = captureMode;
    const CGFloat belowChromeHeight = io.DisplaySize.y - y;
    self.marginLeftBlurView.frame = NSMakeRect(0, 0, x, belowChromeHeight);
    self.marginRightBlurView.frame = NSMakeRect(x + w, 0, io.DisplaySize.x - (x + w), belowChromeHeight);
    self.marginBottomBlurView.frame = NSMakeRect(x, 0, w, contentBottomY);
}

- (void)takeKeyboardFocus {
    if (!self.view.window.isKeyWindow) {
        [self.view.window makeKeyWindow];  // take typing without activating the app
    }
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {
}

- (void)viewWillAppear {
    [super viewWillAppear];
    self.view.window.delegate = self;
}

- (void)windowWillClose:(NSNotification*)notification {
    if (_app->isRecording()) {
        _app->stopRecording(/*userInitiated=*/false);  // closing the app: no notes
    }
    [[[NSWorkspace sharedWorkspace] notificationCenter] removeObserver:self];
    if (_mousePositionMonitor) {
        [NSEvent removeMonitor:_mousePositionMonitor];
        _mousePositionMonitor = nil;
    }
    ImGui_ImplMetal_Shutdown();
    ImGui_ImplOSX_Shutdown();
    ImGui::DestroyContext();
}

@end

#pragma mark - SetupViewController (opaque checklist + locked app preview)

bool MacOverlayHost::beginScreenCapture(std::string& error) {
    return [controller_ beginScreenCaptureWithError:error];
}

bool MacOverlayHost::confirmScreenCapture(float x, float y, float width, float height, std::string& error) {
    return [controller_ confirmScreenCaptureX:x y:y width:width height:height error:error];
}

void MacOverlayHost::presentDocumentUploadPanel() {
    [controller_ presentDocumentUploadPanel];
}

void MacOverlayHost::quitApp() {
    [NSApp terminate:nil];
}

void MacOverlayHost::takeKeyboardFocus() {
    [controller_ takeKeyboardFocus];
}

void MacOverlayHost::contentRectChanged(float x, float y, float width, float height, bool captureMode) {
    [controller_ layoutBlurForContentX:x y:y width:width height:height captureMode:captureMode];
}

void MacOverlayHost::resizeFromGrip(bool started, bool active, float minWidth, float minHeight) {
    [controller_ resizeFromGripStarted:started active:active minWidth:minWidth minHeight:minHeight];
}

@interface SetupViewController : NSViewController
// Called once the checklist is fully satisfied and the user clicks
// "Launch App". Owner (AppDelegate) uses this to tear this window down
// and bring up the real overlay app.
@property (nonatomic, copy) void (^onLaunch)(void);
@end

@interface SetupViewController () <MTKViewDelegate>
@property (nonatomic, strong) MTKView* mtkView;
@property (nonatomic, strong) id<MTLDevice> device;
@property (nonatomic, strong) id<MTLCommandQueue> commandQueue;
@end

@implementation SetupViewController {
    SetupScreen _screen;  // the shared checklist UI (ui/SetupScreen.h)
    id _mousePositionMonitor;
}

- (instancetype)initWithNibName:(nullable NSString*)nibNameOrNil bundle:(nullable NSBundle*)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    self.device = EnsureImGuiInitialized();
    self.commandQueue = [self.device newCommandQueue];
    return self;
}

- (void)loadView {
    // Plain opaque view — a normal window, no transparency/rounding
    // tricks. The native titlebar provides the close control.
    NSView* container = [[NSView alloc] initWithFrame:CGRectMake(0, 0, 760, 640)];
    self.mtkView = [[LNOverlayMTKView alloc] initWithFrame:container.bounds];
    self.mtkView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [container addSubview:self.mtkView];
    self.view = container;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.enableSetNeedsDisplay = YES;
    // Must be installed before ImGui_ImplOSX_Init so it fires first (see
    // InstallMousePositionFeedMonitor's comment).
    _mousePositionMonitor = InstallMousePositionFeedMonitor((LNOverlayMTKView*)self.mtkView);
    ImGui_ImplOSX_Init(self.view);
}

// Called by AppDelegate right before it shuts down the shared OSX/Metal
// ImGui backend to hand off to the overlay -- removes this window's own
// event monitor first so it can't outlive this view as an orphaned extra
// monitor (see transitionToMainApp's comment for why that's exactly the
// bug this whole mechanism exists to avoid).
- (void)teardownForTransition {
    if (_mousePositionMonitor) {
        [NSEvent removeMonitor:_mousePositionMonitor];
        _mousePositionMonitor = nil;
    }
}

- (void)drawInMTKView:(MTKView*)view {
    ApplySetupStyle();

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.backingScaleFactor ?: NSScreen.mainScreen.backingScaleFactor;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor == nil) {
        [commandBuffer commit];
        return;
    }

    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui_ImplOSX_NewFrame(view);
    ImGui::NewFrame();

    if (_screen.draw() && self.onLaunch) {
        self.onLaunch();
    }

    ImGui::Render();
    ImDrawData* drawData = ImGui::GetDrawData();

    renderPassDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(0.96, 0.96, 0.97, 1.0);
    id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"Dear ImGui rendering (setup)"];
    ImGui_ImplMetal_RenderDrawData(drawData, commandBuffer, renderEncoder);
    [renderEncoder popDebugGroup];
    [renderEncoder endEncoding];

    [commandBuffer presentDrawable:view.currentDrawable];
    [commandBuffer commit];

    // Keep polling permission/file state live (e.g. right after the user
    // finishes an external BlackHole install) rather than only on events.
    [view setNeedsDisplay:YES];
}


- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {
}

@end

#pragma mark - AppDelegate (orchestrates Setup vs. the real app)

@interface AppDelegate : NSObject <NSApplicationDelegate>
@property (nonatomic, strong) NSWindow* setupWindow;
@property (nonatomic, strong) NSWindow* mainWindow;
@end

@implementation AppDelegate

// AppKit exits without running C++ destructors, so ~App isn't a reliable
// place for this: stop any Claude Code processes still answering, or they
// keep running (and spending tokens) after the app is gone.
- (void)applicationWillTerminate:(NSNotification*)notification {
    ClaudeCodeClient::cancelAll();
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    return YES;
}

- (instancetype)init {
    if (self = [super init]) {
        // The checklist always appears on first launch, so everyone sees the
        // optional Claude setup at least once. After that it only appears
        // when something required is missing, and otherwise launch goes
        // straight to the app with no clicks. Ollama is checked
        // synchronously: its cached status isn't filled in yet at startup,
        // which used to put the checklist (and a "Launch App" click) in
        // front of every launch.
        // Start an installed-but-stopped Ollama right away, independent of
        // the other checks below (they short-circuit on the first missing
        // item, which used to mean Ollama wasn't started when e.g. the
        // speech model also needed downloading).
        std::thread([] { SetupChecker::startOllamaIfInstalled(); }).detach();

        NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
        // Holding Option while opening the app brings the checklist back
        // (e.g. to set up Claude later).
        const bool optionHeld = ([NSEvent modifierFlags] & NSEventModifierFlagOption) != 0;
        const bool seenChecklist = [defaults boolForKey:@"ChecklistShownOnce"] && !optionHeld;
        const bool allOK = seenChecklist &&
                           SetupChecker::microphonePermissionStatus() == SetupChecker::MicPermission::Authorized &&
                           SetupChecker::isBlackHoleInstalled() && SetupChecker::isWhisperModelDownloaded() &&
                           SetupChecker::hasScreenRecordingPermission() && SetupChecker::isScreenCaptureConfirmed() &&
                           SetupChecker::checkOllamaModelsReadyNow();
        if (!seenChecklist) [defaults setBool:YES forKey:@"ChecklistShownOnce"];
        if (allOK) {
            // Already fully set up (e.g. every run after the first) —
            // skip the checklist entirely and go straight to the app, with
            // no Dock icon flash along the way. transitionToMainApp
            // switches to Accessory itself, before creating the window.
            [self transitionToMainApp];
        } else {
            [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
            [self showSetupWindow];
        }
    }
    return self;
}

- (void)showSetupWindow {
    SetupViewController* setupViewController = [[SetupViewController alloc] initWithNibName:nil bundle:nil];
    setupViewController.onLaunch = ^{
        [self transitionToMainApp];
    };

    // Height bumped from the original 460 -- the checklist grew from 3 to
    // 5 required rows plus the new optional "Smarter answers" section
    // over time, and 460 no longer comfortably fits everything without
    // scrolling.
    self.setupWindow = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 760, 640)
                                                    styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable |
                                                              NSWindowStyleMaskMiniaturizable
                                                      backing:NSBackingStoreBuffered
                                                        defer:NO];
    self.setupWindow.title = @"Lecture Notes Setup";
    self.setupWindow.contentViewController = setupViewController;
    [self.setupWindow center];
    [self.setupWindow makeKeyAndOrderFront:self];
    [NSApp activateIgnoringOtherApps:YES];
}

- (void)transitionToMainApp {
    // Switched to Accessory *before* creating the overlay window below --
    // confirmed via isolated testing (throwaway probe windows, same
    // level/collectionBehavior setup, outside this codebase) that this
    // ordering is the actual root cause of "stays on top of its original
    // Space but doesn't follow into a different one, even a pre-existing
    // fullscreen Space": a window created while the app is still Regular,
    // with the policy switched to Accessory only afterward, permanently
    // loses the ability to properly join a newly-activated Space no
    // matter what's done to it afterward (collectionBehavior toggling,
    // orderFrontRegardless, even a full orderOut+orderFront cycle all
    // failed). A window created while the app is *already* Accessory
    // doesn't have this problem at all. This exact reordering was the
    // fix confirmed by that testing -- everything below it (the
    // orderOut+orderFront reassertion on every Space change) is a
    // separate, still-worthwhile reinforcement for other edge cases, not
    // a workaround for this specific bug anymore.
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];

    // ImGui_ImplOSX_Init()/Shutdown() are per-view (each installs its own
    // NSEvent local monitor for mouse/keyboard input) and were only ever
    // being called once, in whichever view controller's viewDidLoad ran
    // -- never Shutdown when switching away from the Setup window. The
    // guard against double-Init inside imgui_impl_osx.mm is a plain
    // assert(), which is compiled out in this project's Release build,
    // so calling Init again for the overlay's view silently *added a
    // second monitor* instead of failing loudly. That stale, orphaned
    // monitor kept firing for every subsequent click using Setup's old
    // view (wrong coordinate space/bounds) to compute position, feeding
    // garbage position data that raced with the correct one from the new
    // monitor -- the actual cause of clicks intermittently not
    // registering on the overlay. Explicitly tearing down the OSX
    // backend before the overlay's view initializes its own fixes this.
    if (self.setupWindow != nil) {
        [(SetupViewController*)self.setupWindow.contentViewController teardownForTransition];
        ImGui_ImplOSX_Shutdown();
    }

    NSViewController* rootViewController = [[AppViewController alloc] initWithNibName:nil bundle:nil];

    // Borderless so there's no opaque titlebar breaking the glass look.
    // NSWindowStyleMaskResizable's usual edge-drag hit-testing is
    // unreliable on borderless windows in practice, so resizing is done
    // by hand via a custom grip drawn in the bottom-right corner (see
    // drawMainUI) rather than relying on that.
    NSWindow* overlayWindow = [[LNOverlayWindow alloc] initWithContentRect:NSMakeRect(0, 0, 420, 320)
                                                                  styleMask:NSWindowStyleMaskBorderless |
                                                                            NSWindowStyleMaskResizable |
                                                                            NSWindowStyleMaskNonactivatingPanel
                                                                    backing:NSBackingStoreBuffered
                                                                      defer:NO];
    overlayWindow.title = @"Lecture Notes";
    overlayWindow.opaque = NO;
    overlayWindow.backgroundColor = [NSColor clearColor];
    overlayWindow.hasShadow = YES;
    overlayWindow.movableByWindowBackground = YES;
    ((NSPanel*)overlayWindow).becomesKeyOnlyIfNeeded = YES;
    overlayWindow.hidesOnDeactivate = NO;

    // Always-on-top overlay: sit above every normal window level (same
    // trick used by screen-recording HUDs/utilities), and be willing to
    // show alongside *any* Space — including another app's native
    // fullscreen Space (a game, Chrome fullscreen, etc.) — instead of
    // being tied to whichever Space it was created on. Without
    // fullScreenAuxiliary, bringing this window forward while a
    // fullscreen app is active would force macOS to switch you back to
    // this app's own desktop Space; with it, the overlay just appears on
    // top of the fullscreen app in place.
    overlayWindow.level = NSScreenSaverWindowLevel;
    // Stationary deliberately dropped -- it's meant for Dock/menu-bar-like
    // windows that stay fixed during Mission Control/Exposé animations,
    // and was a candidate suspect for why CanJoinAllSpaces stopped
    // actually accompanying the window into a newly-entered fullscreen
    // Space (reported: stays on top of its original Space, but doesn't
    // follow into a different one).
    overlayWindow.collectionBehavior =
        NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorFullScreenAuxiliary;

    // Excludes this window from screenshots, screen recordings, and
    // screen sharing (e.g. Zoom) — the whole point is private lecture
    // notes floating over a call, not something that ends up on a
    // recording of the call itself.
    overlayWindow.sharingType = NSWindowSharingNone;

    overlayWindow.contentViewController = rootViewController;
    [overlayWindow center];
    [overlayWindow makeKeyAndOrderFront:self];
    self.mainWindow = overlayWindow;

    // Belt-and-suspenders for "always on top, follows you to whatever
    // Space/fullscreen app is active": collectionBehavior
    // (CanJoinAllSpaces + FullScreenAuxiliary) above is supposed to be
    // sufficient on its own, but macOS's window-server ordering for an
    // auxiliary window on a *newly*-activated fullscreen Space isn't
    // always honored reliably in practice -- explicitly re-asserting
    // front-most on every Space switch is the standard workaround other
    // always-on-top utilities use. orderFrontRegardless only changes
    // z-order, not key/focus, so it never steals keyboard input from
    // whatever you're actually using.
    [[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
                                                            selector:@selector(handleActiveSpaceChanged:)
                                                                name:NSWorkspaceActiveSpaceDidChangeNotification
                                                              object:nil];

    // Close the Setup window *after* the overlay is already up, so there's
    // never a moment with zero windows open that could trigger
    // applicationShouldTerminateAfterLastWindowClosed prematurely.
    if (self.setupWindow) {
        [self.setupWindow close];
        self.setupWindow = nil;
    }
}

- (void)reassertOverlayOnTop {
    if (self.mainWindow == nil) {
        return;
    }
    // Confirmed via a standalone isolated test (a throwaway probe window,
    // same level/collectionBehavior/Accessory setup, outside this
    // codebase): reassigning collectionBehavior (even clearing it to 0
    // first) and calling orderFrontRegardless do NOT make an
    // already-existing window join a Space it wasn't already a member of
    // -- Space membership for an existing window is decided once and
    // isn't retroactively re-evaluated by touching those properties. A
    // full order-OUT then order-back-IN cycle *does* force a fresh
    // membership re-evaluation, confirmed by that same probe actually
    // appearing on a different, already-active fullscreen Space
    // immediately after doing this. collectionBehavior is still
    // reasserted first in case it was somehow reset, but the orderOut +
    // orderFrontRegardless pair is what actually does the work here.
    self.mainWindow.level = NSScreenSaverWindowLevel;
    self.mainWindow.collectionBehavior =
        NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorFullScreenAuxiliary;
    [self.mainWindow orderOut:nil];
    [self.mainWindow orderFrontRegardless];
}

- (void)handleActiveSpaceChanged:(NSNotification*)note {
    // The notification can fire slightly before macOS finishes actually
    // building the new Space's window set, so a same-tick reassertion
    // alone isn't reliable -- try immediately, then once more shortly
    // after in case the first attempt was too early.
    [self reassertOverlayOnTop];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      [self reassertOverlayOnTop];
    });
}

@end

namespace {
// Borderless windows have no titlebar Quit control, so wire up a minimal
// main menu purely so Cmd+Q still works regardless of which window (Setup
// or the overlay) is currently showing.
void InstallMinimalMainMenu() {
    NSMenu* mainMenu = [[NSMenu alloc] init];
    NSMenuItem* appMenuItem = [[NSMenuItem alloc] init];
    [mainMenu addItem:appMenuItem];

    NSMenu* appMenu = [[NSMenu alloc] init];
    NSMenuItem* quitItem = [[NSMenuItem alloc] initWithTitle:@"Quit Lecture Notes"
                                                       action:@selector(terminate:)
                                                keyEquivalent:@"q"];
    [appMenu addItem:quitItem];
    appMenuItem.submenu = appMenu;

    [NSApp setMainMenu:mainMenu];
}
} // namespace

int RunUIApp() {
    @autoreleasepool {
        [NSApplication sharedApplication];
        AppDelegate* delegate = [[AppDelegate alloc] init];
        [NSApp setDelegate:delegate];
        InstallMinimalMainMenu();
        [NSApp run];
    }
    return 0;
}
