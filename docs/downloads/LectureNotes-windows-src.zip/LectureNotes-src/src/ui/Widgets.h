#pragma once

// Shared Dear ImGui look and widgets for the overlay and the Setup window,
// used by both the macOS (UIApp.mm) and Windows (WinApp.cpp) front ends.

#include <string>

#include "imgui.h"

inline constexpr float kPanelRounding = 6.0f;
inline constexpr float kControlRounding = 5.0f;

// Overlay palette: dark text on the light frosted-glass background.
namespace Pal {
inline constexpr ImVec4 Ink(0.11f, 0.12f, 0.14f, 1.0f);
inline constexpr ImVec4 Muted(0.40f, 0.42f, 0.47f, 1.0f);
inline constexpr ImVec4 Blue(0.08f, 0.40f, 0.88f, 1.0f);
inline constexpr ImVec4 Green(0.08f, 0.52f, 0.27f, 1.0f);
inline constexpr ImVec4 Red(0.82f, 0.19f, 0.17f, 1.0f);
inline constexpr ImVec4 Amber(0.70f, 0.45f, 0.04f, 1.0f);
}  // namespace Pal

inline constexpr float kTabHeight = 21.0f;
inline constexpr float kTabHorizontalPadding = 7.0f;
inline constexpr float kTabCloseReserve = 15.0f;
inline constexpr float kTabSpacing = 0.0f;  // tabs sit flush against each other

// The tab bar and the camera/"+"/"x" corner buttons are drawn at the same
// y position (both pinned to the very top of the window), so the
// shrink-to-fit sizing pass in drawMainUI has to leave this much room on
// the right or a wide-enough tab bar draws underneath/through them
// instead of stopping short. 20px close + 4px gap + 20px plus + 4px gap +
// 20px camera + a bit of breathing room. kTopRightControlsReserveCapturing
// adds the extra red cancel-X button that only appears mid-capture.
inline constexpr float kTopRightControlsReserve = 80.0f;
inline constexpr float kTopRightControlsReserveCapturing = 24.0f;

// Loads the system UI font (San Francisco / Segoe UI) at `scale` times the
// design size, with math/symbol fallbacks merged in.
void LoadModernFont(float scale);

void ApplyGlassStyle();
void ApplySetupStyle();

void ShadowedText(const ImVec4& color, const char* text);
void ShadowedTextWrapped(const ImVec4& color, const char* text);
void DrawAnswerText(const std::string& answer);
void DrawSpeakerDot(const char* label, float level, ImU32 activeColor, bool useShadow);
bool OutlineButton(const char* label, const ImVec4& accent, const ImVec2& size = ImVec2(0, 0));

float TabWidthForLabel(const std::string& label, bool closeable);
bool DrawTab(const char* uniqueId, const std::string& label, bool isSelected, bool closeable, bool* closeRequested,
             bool divider = false);
std::string TruncateForTab(const std::string& text, size_t maxChars);

void DrawSetupCheckIcon(bool satisfied);
void DrawCameraIcon(const ImVec2& center, ImU32 color);

enum class CornerIcon { Camera, Check, Cancel, Plus, Close };
bool CornerIconButton(const char* id, float size, CornerIcon icon, ImU32 tint, bool active = false,
                      bool dangerHover = false);
