// Dear ImGui Windows + Direct3D 11 front end: the Windows counterpart of
// UIApp.mm. It owns the windows, the GPU and the frame loop; the screens
// themselves (OverlayScreen, SetupScreen) are shared with macOS.
//
//   - Setup window: a normal titled window with the first-run checklist.
//   - Overlay: a borderless, always-on-top, see-through window drawn through
//     a DirectComposition swap chain with premultiplied alpha. It never takes
//     focus from Zoom (WS_EX_NOACTIVATE) except while typing in the txt box,
//     and it's hidden from screen sharing (WDA_EXCLUDEFROMCAPTURE).
//
// ImGui runs in logical (96-DPI) units, like points on macOS, so the shared
// layout is the same size on a 150% display: mouse input is divided by the
// DPI scale on the way in and the draw data is multiplied on the way out,
// with fonts rasterized at full resolution.

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d11.h>
#include <dcomp.h>
#include <dwmapi.h>
#include <dxgi1_3.h>
#include <shobjidl.h>
#include <windowsx.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

#include "app/App.h"
#include "capture/ScreenCapture.h"
#include "platform/win/DocumentTextWin.h"
#include "platform/win/WinUtil.h"
#include "setup/SetupChecker.h"
#include "summarize/ClaudeCodeClient.h"
#include "ui/OverlayScreen.h"
#include "ui/SetupScreen.h"
#include "ui/Widgets.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace {

constexpr float kOverlayWidth = 420.0f;   // logical units, same as the macOS window
constexpr float kOverlayHeight = 320.0f;
constexpr float kSetupWidth = 760.0f;
constexpr float kSetupHeight = 640.0f;
constexpr float kWindowCornerRadius = 9.0f;
const wchar_t* kWindowClass = L"LectureNotesWindow";
const wchar_t* kSettingsKey = L"Software\\LectureNotes";

template <typename T>
void SafeRelease(T*& p) {
    if (p) {
        p->Release();
        p = nullptr;
    }
}

// ---- persisted flags ---------------------------------------------------------

bool ReadFlag(const wchar_t* name) {
    DWORD value = 0;
    DWORD size = sizeof(value);
    return RegGetValueW(HKEY_CURRENT_USER, kSettingsKey, name, RRF_RT_REG_DWORD, nullptr, &value, &size) ==
               ERROR_SUCCESS &&
           value != 0;
}

void WriteFlag(const wchar_t* name, bool on) {
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kSettingsKey, 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, nullptr) ==
        ERROR_SUCCESS) {
        const DWORD value = on ? 1 : 0;
        RegSetValueExW(key, name, 0, REG_DWORD, reinterpret_cast<const BYTE*>(&value), sizeof(value));
        RegCloseKey(key);
    }
}

// ---- Direct3D ---------------------------------------------------------------------

ID3D11Device* g_device = nullptr;
ID3D11DeviceContext* g_context = nullptr;

bool CreateDevice() {
    const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1, D3D_FEATURE_LEVEL_10_0};
    D3D_FEATURE_LEVEL got;
    // BGRA support is required for DirectComposition swap chains.
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                                   levels, 3, D3D11_SDK_VERSION, &g_device, &got, &g_context);
    if (FAILED(hr)) {  // no usable GPU driver: software rendering still works
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, levels, 3,
                               D3D11_SDK_VERSION, &g_device, &got, &g_context);
    }
    WinUtil::Log("Direct3D 11 device: %s (hr=0x%08lX)", SUCCEEDED(hr) ? "ok" : "FAILED", static_cast<unsigned long>(hr));
    return SUCCEEDED(hr);
}

IDXGIFactory2* DxgiFactory() {
    IDXGIDevice* dxgiDevice = nullptr;
    IDXGIAdapter* adapter = nullptr;
    IDXGIFactory2* factory = nullptr;
    if (SUCCEEDED(g_device->QueryInterface(IID_PPV_ARGS(&dxgiDevice))) && SUCCEEDED(dxgiDevice->GetAdapter(&adapter))) {
        adapter->GetParent(IID_PPV_ARGS(&factory));
    }
    SafeRelease(adapter);
    SafeRelease(dxgiDevice);
    return factory;
}

struct Window {
    HWND hwnd = nullptr;
    bool overlay = false;
    float scale = 1.0f;  // DPI / 96
    IDXGISwapChain1* swapChain = nullptr;
    ID3D11RenderTargetView* rtv = nullptr;
    IDCompositionDevice* dcomp = nullptr;
    IDCompositionTarget* target = nullptr;
    IDCompositionVisual* visual = nullptr;
    UINT width = 0;
    UINT height = 0;

    void createRenderTarget() {
        ID3D11Texture2D* back = nullptr;
        if (SUCCEEDED(swapChain->GetBuffer(0, IID_PPV_ARGS(&back)))) {
            g_device->CreateRenderTargetView(back, nullptr, &rtv);
            back->Release();
        }
    }

    bool createSwapChain() {
        RECT rc;
        GetClientRect(hwnd, &rc);
        width = std::max<UINT>(1, rc.right - rc.left);
        height = std::max<UINT>(1, rc.bottom - rc.top);
        IDXGIFactory2* factory = DxgiFactory();
        if (!factory) return false;
        DXGI_SWAP_CHAIN_DESC1 desc{};
        desc.Width = width;
        desc.Height = height;
        desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
        desc.SampleDesc.Count = 1;
        desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        desc.BufferCount = 2;
        HRESULT hr;
        if (overlay) {
            desc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
            desc.AlphaMode = DXGI_ALPHA_MODE_PREMULTIPLIED;
            desc.Scaling = DXGI_SCALING_STRETCH;
            hr = factory->CreateSwapChainForComposition(g_device, &desc, nullptr, &swapChain);
            if (SUCCEEDED(hr)) {
                IDXGIDevice* dxgiDevice = nullptr;
                g_device->QueryInterface(IID_PPV_ARGS(&dxgiDevice));
                hr = DCompositionCreateDevice(dxgiDevice, IID_PPV_ARGS(&dcomp));
                SafeRelease(dxgiDevice);
                if (SUCCEEDED(hr)) hr = dcomp->CreateTargetForHwnd(hwnd, TRUE, &target);
                if (SUCCEEDED(hr)) hr = dcomp->CreateVisual(&visual);
                if (SUCCEEDED(hr)) hr = visual->SetContent(swapChain);
                if (SUCCEEDED(hr)) hr = target->SetRoot(visual);
                if (SUCCEEDED(hr)) hr = dcomp->Commit();
            }
        } else {
            desc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
            desc.AlphaMode = DXGI_ALPHA_MODE_IGNORE;
            desc.Scaling = DXGI_SCALING_NONE;
            hr = factory->CreateSwapChainForHwnd(g_device, hwnd, &desc, nullptr, nullptr, &swapChain);
            if (FAILED(hr)) {  // older Windows 10 without SCALING_NONE support
                desc.Scaling = DXGI_SCALING_STRETCH;
                hr = factory->CreateSwapChainForHwnd(g_device, hwnd, &desc, nullptr, nullptr, &swapChain);
            }
        }
        factory->Release();
        WinUtil::Log("%s swap chain %ux%u: %s (hr=0x%08lX)", overlay ? "overlay (composition)" : "setup", width, height,
                     SUCCEEDED(hr) ? "ok" : "FAILED", static_cast<unsigned long>(hr));
        if (FAILED(hr)) return false;
        createRenderTarget();
        return true;
    }

    void resize(UINT w, UINT h) {
        if (!swapChain || w == 0 || h == 0 || (w == width && h == height)) return;
        SafeRelease(rtv);
        swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
        width = w;
        height = h;
        createRenderTarget();
    }

    void destroy() {
        SafeRelease(rtv);
        SafeRelease(visual);
        SafeRelease(target);
        SafeRelease(dcomp);
        SafeRelease(swapChain);
        if (hwnd) DestroyWindow(hwnd);
        hwnd = nullptr;
    }
};

float ScaleForWindow(HWND hwnd) {
    const UINT dpi = GetDpiForWindow(hwnd);
    return dpi ? dpi / 96.0f : 1.0f;
}

float ScaleForPrimaryMonitor() {
    const POINT origin{0, 0};
    HMONITOR monitor = MonitorFromPoint(origin, MONITOR_DEFAULTTOPRIMARY);
    UINT dpiX = 96, dpiY = 96;
    using GetDpiForMonitorFn = HRESULT(WINAPI*)(HMONITOR, int, UINT*, UINT*);
    if (HMODULE shcore = LoadLibraryW(L"shcore.dll")) {
        if (auto fn = reinterpret_cast<GetDpiForMonitorFn>(GetProcAddress(shcore, "GetDpiForMonitor"))) {
            fn(monitor, 0 /* MDT_EFFECTIVE_DPI */, &dpiX, &dpiY);
        }
    }
    return dpiX / 96.0f;
}

// ---- application state -------------------------------------------------------------

Window g_window;
float g_fontScale = 0.0f;
bool g_quit = false;
bool g_launchRequested = false;

std::unique_ptr<App> g_app;
std::unique_ptr<SetupScreen> g_setup;
std::unique_ptr<OverlayScreen> g_overlay;

void RebuildFontsIfNeeded(float scale) {
    if (scale == g_fontScale) return;
    g_fontScale = scale;
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->Clear();
    LoadModernFont(scale);
    ImGui_ImplDX11_InvalidateDeviceObjects();
    ImGui_ImplDX11_CreateDeviceObjects();
}

// ---- overlay host --------------------------------------------------------------------

class WinOverlayHost : public OverlayHost {
public:
    bool beginScreenCapture(std::string& error) override {
        (void)error;
        captureMode_ = true;
        return true;  // no permission needed on Windows
    }

    bool confirmScreenCapture(float x, float y, float width, float height, std::string& error) override {
        POINT origin{0, 0};
        ClientToScreen(g_window.hwnd, &origin);
        const float s = g_window.scale;
        ScreenRect rect;
        rect.x = origin.x + x * s;
        rect.y = origin.y + y * s;
        rect.width = width * s;
        rect.height = height * s;
        const RECT r{static_cast<LONG>(rect.x), static_cast<LONG>(rect.y), static_cast<LONG>(rect.x + rect.width),
                     static_cast<LONG>(rect.y + rect.height)};
        if (MonitorFromPoint(POINT{r.left, r.top}, MONITOR_DEFAULTTONULL) !=
            MonitorFromPoint(POINT{r.right - 1, r.bottom - 1}, MONITOR_DEFAULTTONULL)) {
            error = "This region spans more than one display -- move the window fully onto a single screen and try again.";
            return false;
        }
        captureMode_ = false;
        App* app = g_app.get();
        ScreenCapture::captureRegionAsPNG(rect, static_cast<int>(rect.width), static_cast<int>(rect.height),
                                          [app](std::vector<uint8_t> png) {
                                              app->requestVisionAnalysis(std::move(png), std::string());
                                          });
        return true;
    }

    void presentDocumentUploadPanel() override {
        IFileOpenDialog* dialog = nullptr;
        if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dialog)))) {
            return;
        }
        DWORD options = 0;
        dialog->GetOptions(&options);
        dialog->SetOptions(options | FOS_ALLOWMULTISELECT | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST);
        const COMDLG_FILTERSPEC filters[] = {{L"Documents (PDF, Word, text, Markdown)", L"*.pdf;*.docx;*.txt;*.md"},
                                             {L"All files", L"*.*"}};
        dialog->SetFileTypes(2, filters);
        dialog->SetTitle(L"Upload a resume or reference documents");
        dialog->SetOkButtonLabel(L"Upload");
        if (SUCCEEDED(dialog->Show(g_window.hwnd))) {
            IShellItemArray* items = nullptr;
            if (SUCCEEDED(dialog->GetResults(&items))) {
                DWORD count = 0;
                items->GetCount(&count);
                for (DWORD i = 0; i < count; ++i) {
                    IShellItem* item = nullptr;
                    if (FAILED(items->GetItemAt(i, &item))) continue;
                    PWSTR path = nullptr;
                    if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path)) && path) {
                        const std::string p = WinUtil::Narrow(path);
                        const std::string text = ExtractDocumentText(p);
                        if (!text.empty()) {
                            const size_t slash = p.find_last_of("\\/");
                            g_app->addDocument(slash == std::string::npos ? p : p.substr(slash + 1), text);
                        }
                        CoTaskMemFree(path);
                    }
                    item->Release();
                }
                items->Release();
            }
        }
        dialog->Release();
    }

    void quitApp() override { g_quit = true; }

    void takeKeyboardFocus() override {
        // The overlay normally never activates (WS_EX_NOACTIVATE) so Zoom
        // keeps focus. Typing needs real focus on Windows; the click that got
        // us here makes this SetForegroundWindow allowed.
        if (GetForegroundWindow() != g_window.hwnd) {
            SetForegroundWindow(g_window.hwnd);
            SetFocus(g_window.hwnd);
        }
    }

    void contentRectChanged(float x, float y, float width, float height, bool captureMode) override {
        contentX_ = x;
        contentY_ = y;
        contentW_ = width;
        contentH_ = height;
        captureMode_ = captureMode;
    }

    void resizeFromGrip(bool started, bool active, float minWidth, float minHeight) override {
        POINT cursor;
        GetCursorPos(&cursor);
        if (started) {
            GetWindowRect(g_window.hwnd, &dragStartRect_);
            dragStartCursor_ = cursor;
        }
        if (active) {
            const float s = g_window.scale;
            const int w = std::max<int>(static_cast<int>(minWidth * s),
                                        (dragStartRect_.right - dragStartRect_.left) + (cursor.x - dragStartCursor_.x));
            const int h = std::max<int>(static_cast<int>(minHeight * s),
                                        (dragStartRect_.bottom - dragStartRect_.top) + (cursor.y - dragStartCursor_.y));
            SetWindowPos(g_window.hwnd, nullptr, 0, 0, w, h, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }

    // The window's own background: a light, mostly opaque rounded panel
    // (the look of the macOS frosted glass without relying on undocumented
    // blur APIs). While framing a screenshot the content rect is left clear
    // so the user sees exactly what will be captured.
    void drawBackground() const {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const ImVec2 size = ImGui::GetIO().DisplaySize;
        const ImU32 fill = IM_COL32(236, 236, 239, 255);
        const ImU32 border = IM_COL32(0, 0, 0, 60);
        const float r = kWindowCornerRadius;
        if (!captureMode_) {
            dl->AddRectFilled(ImVec2(0, 0), size, fill, r);
        } else {
            const float x0 = contentX_, y0 = contentY_, x1 = contentX_ + contentW_, y1 = contentY_ + contentH_;
            dl->AddRectFilled(ImVec2(0, 0), ImVec2(size.x, y0), fill, r, ImDrawFlags_RoundCornersTop);
            dl->AddRectFilled(ImVec2(0, y1), size, fill, r, ImDrawFlags_RoundCornersBottom);
            dl->AddRectFilled(ImVec2(0, y0), ImVec2(x0, y1), fill);
            dl->AddRectFilled(ImVec2(x1, y0), ImVec2(size.x, y1), fill);
        }
        dl->AddRect(ImVec2(0.5f, 0.5f), ImVec2(size.x - 0.5f, size.y - 0.5f), border, r, 0, 1.0f);
    }

    // Drag the window by any spot that isn't a control, like macOS's
    // movable-by-background window.
    void updateWindowDrag() {
        if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !ImGui::IsAnyItemHovered() && !ImGui::IsAnyItemActive() &&
            ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow)) {
            dragging_ = true;
            GetWindowRect(g_window.hwnd, &dragStartRect_);
            GetCursorPos(&dragStartCursor_);
        }
        if (dragging_) {
            if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
                dragging_ = false;
                return;
            }
            POINT cursor;
            GetCursorPos(&cursor);
            SetWindowPos(g_window.hwnd, nullptr, dragStartRect_.left + (cursor.x - dragStartCursor_.x),
                         dragStartRect_.top + (cursor.y - dragStartCursor_.y), 0, 0,
                         SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }

private:
    float contentX_ = 0, contentY_ = 0, contentW_ = 0, contentH_ = 0;
    bool captureMode_ = false;
    bool dragging_ = false;
    RECT dragStartRect_{};
    POINT dragStartCursor_{};
};

WinOverlayHost g_overlayHost;

// ---- windows --------------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

void RegisterWindowClass(HINSTANCE instance) {
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hIcon = LoadIcon(instance, MAKEINTRESOURCE(1));
    wc.lpszClassName = kWindowClass;
    RegisterClassExW(&wc);
}

bool CreateAppWindow(HINSTANCE instance, bool overlay) {
    const float scale = ScaleForPrimaryMonitor();
    const int w = static_cast<int>((overlay ? kOverlayWidth : kSetupWidth) * scale);
    const int h = static_cast<int>((overlay ? kOverlayHeight : kSetupHeight) * scale);
    RECT work{};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    DWORD style, exStyle;
    RECT rect{0, 0, w, h};
    if (overlay) {
        style = WS_POPUP;
        exStyle = WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOREDIRECTIONBITMAP | WS_EX_NOACTIVATE;
    } else {
        style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
        exStyle = WS_EX_APPWINDOW;
        AdjustWindowRectExForDpi(&rect, style, FALSE, exStyle, static_cast<UINT>(scale * 96));
    }
    const int ww = rect.right - rect.left;
    const int wh = rect.bottom - rect.top;
    const int x = work.left + ((work.right - work.left) - ww) / 2;
    const int y = work.top + ((work.bottom - work.top) - wh) / 2;

    g_window = Window{};
    g_window.overlay = overlay;
    g_window.hwnd = CreateWindowExW(exStyle, kWindowClass, overlay ? L"Lecture Notes" : L"Lecture Notes Setup", style,
                                    x, y, ww, wh, nullptr, nullptr, instance, nullptr);
    if (!g_window.hwnd) {
        WinUtil::Log("CreateWindowEx failed (error %lu)", GetLastError());
        return false;
    }
    g_window.scale = ScaleForWindow(g_window.hwnd);
    WinUtil::Log("%s window created, DPI scale %.2f", overlay ? "Overlay" : "Setup", g_window.scale);
    if (overlay) {
        // Hidden from Zoom/Teams/OBS screen sharing and screenshots (Win10
        // 2004+); you still see it.
        if (!SetWindowDisplayAffinity(g_window.hwnd, WDA_EXCLUDEFROMCAPTURE)) {
            WinUtil::Log("SetWindowDisplayAffinity failed (error %lu); overlay may show in screen shares",
                         GetLastError());
        }
    }
    if (!g_window.createSwapChain()) return false;
    ShowWindow(g_window.hwnd, overlay ? SW_SHOWNOACTIVATE : SW_SHOW);
    if (!overlay) SetForegroundWindow(g_window.hwnd);
    ImGui_ImplWin32_Init(g_window.hwnd);
    RebuildFontsIfNeeded(g_window.scale);
    return true;
}

void DestroyAppWindow() {
    ImGui_ImplWin32_Shutdown();
    g_window.destroy();
}

// Mouse messages carry physical client coordinates; ImGui works in logical
// units (see the file comment).
LPARAM ScaleMouseLParam(LPARAM lParam) {
    const float s = g_window.scale;
    const int x = static_cast<int>(GET_X_LPARAM(lParam) / s);
    const int y = static_cast<int>(GET_Y_LPARAM(lParam) / s);
    return MAKELPARAM(x, y);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_MOUSEMOVE:
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONUP:
            if (hwnd == g_window.hwnd) lParam = ScaleMouseLParam(lParam);
            break;
        default:
            break;
    }
    if (ImGui::GetCurrentContext() && ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam)) return true;

    switch (msg) {
        case WM_SIZE:
            if (hwnd == g_window.hwnd && wParam != SIZE_MINIMIZED) {
                g_window.resize(LOWORD(lParam), HIWORD(lParam));
            }
            return 0;
        case WM_DPICHANGED: {
            if (hwnd == g_window.hwnd) {
                g_window.scale = HIWORD(wParam) / 96.0f;
                const RECT* suggested = reinterpret_cast<const RECT*>(lParam);
                SetWindowPos(hwnd, nullptr, suggested->left, suggested->top, suggested->right - suggested->left,
                             suggested->bottom - suggested->top, SWP_NOZORDER | SWP_NOACTIVATE);
            }
            return 0;
        }
        case WM_MOUSEACTIVATE:
            // Clicking the overlay never steals focus from Zoom; the txt box
            // asks for focus explicitly (takeKeyboardFocus).
            if (g_window.overlay && hwnd == g_window.hwnd) return MA_NOACTIVATE;
            break;
        case WM_POWERBROADCAST:
            if (g_overlay) {
                if (wParam == PBT_APMSUSPEND) g_overlay->willSleep();
                if (wParam == PBT_APMRESUMEAUTOMATIC) g_overlay->didWake();
            }
            return TRUE;
        case WM_SYSCOMMAND:
            if ((wParam & 0xfff0) == SC_KEYMENU) return 0;  // no Alt menu beep
            break;
        case WM_CLOSE:
            g_quit = true;
            return 0;
        case WM_DESTROY:
            return 0;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// Scales ImGui's logical-unit draw data up to physical pixels.
void ScaleDrawData(ImDrawData* data, float s) {
    if (s == 1.0f) return;
    for (ImDrawList* list : data->CmdLists) {
        for (ImDrawVert& v : list->VtxBuffer) {
            v.pos.x *= s;
            v.pos.y *= s;
        }
    }
    data->ScaleClipRects(ImVec2(s, s));
    data->DisplaySize.x *= s;
    data->DisplaySize.y *= s;
}

void RenderFrame() {
    RebuildFontsIfNeeded(g_window.scale);
    const float s = g_window.scale;
    if (g_window.overlay) ApplyGlassStyle();
    else ApplySetupStyle();

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(g_window.width / s, g_window.height / s);
    io.DisplayFramebufferScale = ImVec2(s, s);
    ImGui::NewFrame();

    if (g_window.overlay) {
        g_overlayHost.drawBackground();
        g_overlay->draw();
        g_overlayHost.updateWindowDrag();
    } else if (g_setup->draw()) {
        g_launchRequested = true;
    }

    ImGui::Render();
    ImDrawData* drawData = ImGui::GetDrawData();
    ScaleDrawData(drawData, s);
    const float clearOverlay[4] = {0, 0, 0, 0};  // transparent: see-through where nothing is drawn
    const float clearSetup[4] = {0.96f, 0.96f, 0.97f, 1.0f};
    g_context->OMSetRenderTargets(1, &g_window.rtv, nullptr);
    g_context->ClearRenderTargetView(g_window.rtv, g_window.overlay ? clearOverlay : clearSetup);
    ImGui_ImplDX11_RenderDrawData(drawData);
    g_window.swapChain->Present(1, 0);
}

bool EverythingReady() {
    return (SetupChecker::isMicrophoneMissing() ||
            SetupChecker::microphonePermissionStatus() == SetupChecker::MicPermission::Authorized) &&
           SetupChecker::isWhisperModelDownloaded() && SetupChecker::checkOllamaModelsReadyNow();
}

// Last-chance handler: note the crash in the log and tell the user where it
// is, instead of vanishing silently.
LONG WINAPI OnCrash(EXCEPTION_POINTERS* info) {
    const auto* rec = info ? info->ExceptionRecord : nullptr;
    WinUtil::Log("CRASH: exception 0x%08lX at %p", rec ? static_cast<unsigned long>(rec->ExceptionCode) : 0UL,
                 rec ? rec->ExceptionAddress : nullptr);
    const std::wstring text = L"LectureNotes ran into a problem and has to close.\n\nDetails were saved to:\n" +
                              WinUtil::Widen(WinUtil::LogPath());
    MessageBoxW(nullptr, text.c_str(), L"LectureNotes", MB_ICONERROR);
    return EXCEPTION_EXECUTE_HANDLER;
}

}  // namespace

int RunUIApp() {
    HINSTANCE instance = GetModuleHandleW(nullptr);
    SetUnhandledExceptionFilter(OnCrash);
    WinUtil::Log("---- LectureNotes starting (%s build) ----",
#if defined(__aarch64__)
                 "arm64"
#else
                 "x64"
#endif
    );
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    if (!CreateDevice()) {
        MessageBoxW(nullptr, L"LectureNotes couldn't start Direct3D 11. Updating your graphics driver usually fixes this.",
                    L"LectureNotes", MB_ICONERROR);
        return 1;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui_ImplDX11_Init(g_device, g_context);
    RegisterWindowClass(instance);

    // Start an installed-but-stopped Ollama right away (see UIApp.mm), and
    // fetch the fast fallback speech model if it's missing.
    std::thread([] { SetupChecker::startOllamaIfInstalled(); }).detach();
    SetupChecker::ensureFastWhisperModelAsync();

    // First launch always shows the checklist (so everyone sees the optional
    // Claude setup once); after that only when something required is
    // missing. Holding Shift while opening the app brings it back.
    const bool shiftHeld = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    const bool seenChecklist = ReadFlag(L"ChecklistShownOnce") && !shiftHeld;
    const bool allOK = seenChecklist && EverythingReady();
    WinUtil::Log("Checklist seen before: %d, everything ready: %d", seenChecklist ? 1 : 0, allOK ? 1 : 0);
    if (!seenChecklist) WriteFlag(L"ChecklistShownOnce", true);

    g_app = std::make_unique<App>();
    if (allOK) {
        g_overlay = std::make_unique<OverlayScreen>(*g_app, g_overlayHost);
        if (!CreateAppWindow(instance, /*overlay=*/true)) return 1;
    } else {
        g_setup = std::make_unique<SetupScreen>();
        if (!CreateAppWindow(instance, /*overlay=*/false)) return 1;
    }

    MSG msg;
    while (!g_quit) {
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) g_quit = true;
        }
        if (g_quit) break;
        if (IsIconic(g_window.hwnd)) {
            Sleep(50);
            continue;
        }
        RenderFrame();
        if (g_launchRequested) {
            g_launchRequested = false;
            DestroyAppWindow();
            g_setup.reset();
            g_overlay = std::make_unique<OverlayScreen>(*g_app, g_overlayHost);
            if (!CreateAppWindow(instance, /*overlay=*/true)) break;
        }
    }

    if (g_app && g_app->isRecording()) g_app->stopRecording(/*userInitiated=*/false);  // quitting: no notes
    ClaudeCodeClient::cancelAll();
    g_overlay.reset();
    g_setup.reset();
    DestroyAppWindow();
    ImGui_ImplDX11_Shutdown();
    ImGui::DestroyContext();
    g_app.reset();
    SafeRelease(g_context);
    SafeRelease(g_device);
    CoUninitialize();
    return 0;
}
