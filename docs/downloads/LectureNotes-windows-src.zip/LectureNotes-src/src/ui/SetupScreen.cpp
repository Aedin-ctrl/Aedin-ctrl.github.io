// The first-run Setup checklist's ImGui UI, shared by the macOS and Windows
// front ends. Every platform check goes through SetupChecker, which hides
// the rows a platform doesn't need (BlackHole and Screen Recording are
// macOS-only).

#include "ui/SetupScreen.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <string>
#include <thread>

#include "imgui.h"

#include "setup/ClaudeKeyStore.h"
#include "setup/SetupChecker.h"
#include "summarize/ClaudeCodeClient.h"
#include "ui/Widgets.h"

namespace {

#ifdef _WIN32
#define kOpenSettingsLabel "Open Windows Settings"
#define kTerminalName "PowerShell"
#define kSetupModifierKey "Shift"
#define kSpeechModelSize "~875 MB"
#else
#define kOpenSettingsLabel "Open System Settings"
#define kTerminalName "Terminal"
#define kSetupModifierKey "Option"
#define kSpeechModelSize "~550 MB"
#endif

double NowSeconds() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

}  // namespace

SetupScreen::SetupScreen() {
    std::memset(_claudeKeyInputBuffer, 0, sizeof(_claudeKeyInputBuffer));
}

bool SetupScreen::draw() {
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
    ImGui::Begin("Setup", nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                      ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar |
                      ImGuiWindowFlags_NoScrollWithMouse);

    const bool micMissing = SetupChecker::isMicrophoneMissing();
    // No microphone at all isn't a blocker: the lecture audio still works.
    const bool micOK =
        micMissing || SetupChecker::microphonePermissionStatus() == SetupChecker::MicPermission::Authorized;
    const bool bhOK = SetupChecker::isBlackHoleInstalled();
    const bool modelOK = SetupChecker::isWhisperModelDownloaded();
    const bool screenPermission = SetupChecker::hasScreenRecordingPermission();
    const bool screenOK = screenPermission && SetupChecker::isScreenCaptureConfirmed();
    const bool ollamaOK = SetupChecker::areOllamaModelsReady();
    const bool allOK = micOK && bhOK && modelOK && screenOK && ollamaOK;

    const float centerWidth = 460.0f;
    ImGui::SetCursorPosX(std::max(0.0f, (ImGui::GetWindowWidth() - centerWidth) * 0.5f));
    // The list scrolls; the Launch button is pinned below it. It used to be
    // the last item in the list, and once the optional rows made the list
    // taller than the window it scrolled out of sight.
    constexpr float kLaunchBarHeight = 46.0f;
    ImGui::BeginChild("ChecklistPane", ImVec2(centerWidth, -kLaunchBarHeight), false);
    drawChecklist(micOK, bhOK, modelOK, screenOK, ollamaOK, allOK);
    ImGui::EndChild();

    ImGui::Separator();
    ImGui::Spacing();
    ImGui::SetCursorPosX(std::max(0.0f, (ImGui::GetWindowWidth() - centerWidth) * 0.5f));
    const ImVec4 launchGreen(0.15f, 0.65f, 0.35f, 1.00f);
    const ImVec4 launchDim(0.55f, 0.57f, 0.62f, 1.00f);
    ImGui::BeginDisabled(!allOK);
    const bool launchClicked = OutlineButton(allOK ? "You're all set -- Launch App" : "Launch App",
                                             allOK ? launchGreen : launchDim, ImVec2(centerWidth, 30));
    ImGui::EndDisabled();

    ImGui::End();
    return launchClicked && allOK;
}

void SetupScreen::drawChecklist(bool micOK, bool bhOK, bool modelOK, bool screenOK, bool ollamaOK, bool allOK) {
    ImGui::TextColored(ImVec4(0.10f, 0.10f, 0.12f, 1.0f), "Setup");
    ImGui::Spacing();
    ImGui::Spacing();

    const ImVec4 dim(0.40f, 0.40f, 0.43f, 1.00f);
    const ImVec4 blue(0.10f, 0.45f, 0.95f, 1.00f);
    const ImVec4 green(0.15f, 0.65f, 0.35f, 1.00f);
    const ImVec4 red(0.85f, 0.20f, 0.16f, 1.00f);
    const ImVec4 title(0.10f, 0.10f, 0.12f, 1.00f);

    // Row 1: microphone.
    DrawSetupCheckIcon(micOK);
    ImGui::TextColored(title, "Microphone access");
    ImGui::Indent(24);
    if (SetupChecker::isMicrophoneMissing()) {
        ImGui::TextWrapped("No microphone found. LectureNotes will still transcribe the lecture audio; "
                           "plug in a microphone to include your own voice.");
        if (OutlineButton("Sound settings##mic", blue)) {
            SetupChecker::openSoundSettings();
        }
    } else {
        ImGui::TextWrapped("Needed to capture your own voice.");
    }
    if (!micOK) {
        const SetupChecker::MicPermission status = SetupChecker::microphonePermissionStatus();
        if (status == SetupChecker::MicPermission::NotDetermined) {
            // Requesting access here (inside this app's own bundle/
            // process) is what makes the mic usable later by the real
            // note-taking app too — macOS grants mic access per app
            // bundle, not per API, so once granted here the lecture-note
            // audio capture won't need to ask again.
            if (OutlineButton("Grant Access##mic", blue)) {
                SetupChecker::requestMicrophoneAccess();
            }
        } else if (OutlineButton(kOpenSettingsLabel "##mic", blue)) {
            SetupChecker::openSystemMicrophoneSettings();
        }
    }
    ImGui::Unindent(24);
    ImGui::Spacing();

    // Row 2: BlackHole (system/lecture audio capture). macOS only: Windows
    // records system audio natively (WASAPI loopback).
    if (SetupChecker::needsAudioDriver()) {
    DrawSetupCheckIcon(bhOK);
    ImGui::TextColored(title, "System audio (BlackHole)");
    ImGui::Indent(24);
    ImGui::TextWrapped("Lets the app hear lecture/Zoom audio, not just your mic.");
    if (!bhOK) {
        ImGui::BeginDisabled(SetupChecker::isBlackHoleInstallerDownloading());
        if (OutlineButton(SetupChecker::isBlackHoleInstallerDownloading() ? "Downloading..." : "Install BlackHole",
                          green)) {
            SetupChecker::installBlackHoleAsync();
        }
        ImGui::EndDisabled();
        ImGui::TextWrapped("Opens the official installer: click through it and enter your Mac password. "
                           "This checks automatically when it's done.");
    }
    ImGui::Unindent(24);
    ImGui::Spacing();
    }

    // Row 3: Whisper speech model.
    DrawSetupCheckIcon(modelOK);
    ImGui::TextColored(title, "Speech model (" kSpeechModelSize ")");
    ImGui::Indent(24);
    ImGui::TextWrapped("Downloaded once; used to transcribe audio on-device.");
    if (!modelOK) {
        if (SetupChecker::isWhisperModelDownloading()) {
            ImGui::ProgressBar(SetupChecker::whisperModelDownloadProgress(), ImVec2(-1, 6), "");
        } else {
            if (OutlineButton("Download Model", green)) {
                SetupChecker::downloadWhisperModelAsync();
            }
            if (SetupChecker::didWhisperModelDownloadFail()) {
                ImGui::TextColored(red, "Download failed -- try again.");
            }
        }
    }
    ImGui::Unindent(24);
    ImGui::Spacing();

    // Row 4: Screen Recording, for the camera/"solve this" feature.
    // Required like every other row now -- asked here (once, like mic)
    // instead of only lazily on first camera-button click, so this app
    // doesn't surface an OS-level permission dialog mid-lecture the first
    // time someone tries it. macOS only: Windows has no such permission.
    if (SetupChecker::needsScreenRecordingPermission()) {
    DrawSetupCheckIcon(screenOK);
    ImGui::TextColored(title, "Screen Recording");
    ImGui::Indent(24);
    ImGui::TextWrapped("Needed for the camera \"solve this\" screenshot feature.");
    if (SetupChecker::hasScreenRecordingPermission() && !screenOK) {
        // Permission granted, but Sequoia's separate first-capture prompt
        // hasn't been answered yet: run the test capture on its own (only
        // here on the setup screen, where the text explains any prompt; never
        // at launch). The button stays as a retry after a failure.
        if (!SetupChecker::isScreenCaptureTestRunning() && !SetupChecker::didScreenCaptureTestFail()) {
            SetupChecker::testScreenCaptureAsync();
        }
        ImGui::BeginDisabled(SetupChecker::isScreenCaptureTestRunning());
        if (OutlineButton(SetupChecker::isScreenCaptureTestRunning() ? "Waiting for macOS...##screentest"
                                                                     : "Finish screen capture setup##screentest",
                          blue)) {
            SetupChecker::testScreenCaptureAsync();
        }
        ImGui::EndDisabled();
        ImGui::TextWrapped(SetupChecker::didScreenCaptureTestFail()
                               ? "That didn't go through. If macOS asked, click Allow, then press the button again."
                               : "macOS will ask once more to let LectureNotes capture the screen. Click Allow.");
    } else if (!screenOK) {
        if (!SetupChecker::hasRequestedScreenRecordingAccessBefore()) {
            if (OutlineButton("Grant Access##screen", blue)) {
                SetupChecker::requestScreenRecordingAccess();
            }
        } else if (OutlineButton("Open System Settings##screen", blue)) {
            SetupChecker::openSystemScreenRecordingSettings();
        }
        // Unlike mic, macOS doesn't apply a Screen Recording grant to an
        // already-running process -- toggling it on in System Settings
        // only takes effect the *next* time this app is launched, so
        // without this note it looks like the toggle silently did nothing.
        ImGui::TextWrapped("If you just enabled this in Settings, fully quit and reopen the app.");
    }
    ImGui::Unindent(24);
    ImGui::Spacing();
    }

    // Row 5: local AI backend (Ollama + the one model Q&A and camera share).
    // Without this, a fresh machine would pass every other row, launch
    // into the app, and then silently fail the first time someone asked
    // a question or used the camera feature -- "[error] could not reach
    // Ollama" well after Setup said everything was ready.
    DrawSetupCheckIcon(ollamaOK);
    ImGui::TextColored(title, "Local AI (Ollama)");
    ImGui::Indent(24);
    ImGui::TextWrapped("Runs Q&A and the camera feature on-device, no API key needed.");
    if (!ollamaOK) {
        if (!SetupChecker::isOllamaReachable()) {
            if (SetupChecker::isOllamaInstalled()) {
                // Installed but not running (e.g. just after a restart):
                // start it rather than sending anyone to re-download it.
                if (OutlineButton("Start Ollama", green)) {
                    std::thread([] { SetupChecker::startOllamaIfInstalled(); }).detach();
                }
                ImGui::TextWrapped("Ollama is installed but not running. This starts it; it checks automatically.");
            } else {
                if (OutlineButton("Download Ollama", green)) {
                    SetupChecker::openOllamaDownloadPage();
                }
                ImGui::TextWrapped("Install it, then come back; this checks automatically.");
            }
        } else if (SetupChecker::isOllamaModelDownloading()) {
            ImGui::ProgressBar(SetupChecker::ollamaModelDownloadProgress(), ImVec2(-1, 6), "");
        } else {
            if (OutlineButton("Download Model (~3.4 GB)", green)) {
                SetupChecker::downloadOllamaModelsAsync();
            }
            if (SetupChecker::didOllamaModelDownloadFail()) {
                ImGui::TextColored(red, "Download failed -- try again.");
            }
        }
    }
    ImGui::Unindent(24);

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // Optional, deliberately not part of the required checklist above
    // (never affects allOK) -- quality upgrades, not needed to use the app.
    // Claude Code (the user's own signed-in CLI) answers everything when
    // present; the API key and bigger local model only matter for Think
    // Harder when Claude Code isn't available.
    ImGui::TextColored(title, "Smarter answers (optional)");
    ImGui::Indent(24);
    ImGui::TextWrapped(
        "With Claude Code signed in, questions and screenshots are answered by Claude Opus; "
        "otherwise (or whenever Claude is unavailable) by the free on-device model. Every answer "
        "also has a \"Think Harder\" button that re-asks the strongest option available.");
    ImGui::Spacing();

    // Claude through the user's own signed-in Claude Code: no key needed,
    // and when present it answers every question, not just Think Harder.
    // Detection only -- signing in happens in Claude Code itself.
    const bool claudeCodeOK = ClaudeCodeClient::isAvailable();
    DrawSetupCheckIcon(claudeCodeOK);
    ImGui::TextColored(title, "Claude (optional, needs a Claude Pro or Max plan)");
    ImGui::Indent(24);
    if (claudeCodeOK) {
        ImGui::TextWrapped("Signed in. Questions, screenshots and notes are answered by Claude Opus.");
        _claudeSetupStartedAt = 0;
    } else {
        ImGui::TextWrapped(
            "Much stronger answers using your own Claude account. Without it, everything still works "
            "with the free on-device model. (To come back here later, hold " kSetupModifierKey " while opening "
            "LectureNotes.)");
        if (OutlineButton(ClaudeCodeClient::isInstalled() ? "Sign in to Claude" : "Set up Claude", green)) {
            if (ClaudeCodeClient::openSetupInTerminal()) {
                _claudeSetupStartedAt = NowSeconds();
            }
        }
        if (_claudeSetupStartedAt > 0) {
            ImGui::TextWrapped("Finish in the " kTerminalName " window and your browser; this updates automatically.");
            // Poll while they sign in, rather than waiting for the normal
            // re-check interval. refreshAsync() coalesces overlapping calls.
            const double now = NowSeconds();
            if (now - _lastClaudePoll > 2.0) {
                _lastClaudePoll = now;
                ClaudeCodeClient::refreshAsync();
            }
        }
    }
    ImGui::Unindent(24);
    ImGui::Spacing();

    if (ClaudeKeyStore::hasKey()) {
        DrawSetupCheckIcon(true);
        ImGui::TextColored(title, "Claude API key saved -- Think Harder uses Claude");
        if (OutlineButton("Remove Key", red)) {
            ClaudeKeyStore::clearKey();
        }
    } else {
        ImGui::TextWrapped("Paste an Anthropic API key (from console.anthropic.com) to use Claude instead:");
        ImGui::SetNextItemWidth(260);
        ImGui::InputText("##claude_key", _claudeKeyInputBuffer, sizeof(_claudeKeyInputBuffer),
                          ImGuiInputTextFlags_Password);
        ImGui::SameLine();
        if (OutlineButton("Save Key", blue)) {
            std::string enteredKey(_claudeKeyInputBuffer);
            if (!enteredKey.empty()) {
                ClaudeKeyStore::setKey(enteredKey);
            }
            std::memset(_claudeKeyInputBuffer, 0, sizeof(_claudeKeyInputBuffer));
        }
    }

    ImGui::Spacing();
    const bool thinkHarderModelReady = SetupChecker::isThinkHarderModelReady();
    DrawSetupCheckIcon(thinkHarderModelReady);
    ImGui::TextColored(title, "Bigger local model (optional, ~6.6 GB)");
    ImGui::TextWrapped("Used for Think Harder when Claude isn't available -- also free, just slower.");
#ifdef _WIN32
    // Reported totals run a little under the nominal size (16 GB -> ~15.8).
    const unsigned memoryGB = SetupChecker::physicalMemoryGB();
    const bool enoughMemory = memoryGB == 0 || memoryGB >= 15;
    if (!thinkHarderModelReady && !enoughMemory) {
        ImGui::TextColored(dim, "Needs about 16 GB of memory to run next to transcription; this PC has %u GB.",
                           memoryGB);
    }
#else
    const bool enoughMemory = true;
#endif
    if (!thinkHarderModelReady && enoughMemory) {
        if (SetupChecker::isThinkHarderModelDownloading()) {
            ImGui::ProgressBar(0.0f, ImVec2(-1, 6), "Downloading...");
        } else {
            if (OutlineButton("Download Model", green)) {
                SetupChecker::downloadThinkHarderModelAsync();
            }
            if (SetupChecker::didThinkHarderModelDownloadFail()) {
                ImGui::TextColored(red, "Download failed -- try again.");
            }
        }
    }
    ImGui::Unindent(24);

    ImGui::Spacing();
}
