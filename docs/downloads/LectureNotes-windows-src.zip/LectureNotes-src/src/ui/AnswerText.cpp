#include "AnswerText.h"

#include "summarize/Utf8.h"

#include <algorithm>
#include <utility>

namespace {

void ReplaceAll(std::string& s, const std::string& from, const std::string& to) {
    for (size_t pos = 0; (pos = s.find(from, pos)) != std::string::npos; pos += to.size()) {
        s.replace(pos, from.size(), to);
    }
}

// Unicode superscript/subscript for the characters that have one; returns
// "" if any character doesn't (the caller then falls back to ^(...)).
std::string ToScript(const std::string& in, bool super) {
    static const char* kSup[] = {"⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹"};
    static const char* kSub[] = {"₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"};
    // Letters with a Unicode subscript form (there's no complete set).
    static const std::pair<char, const char*> kSubLetters[] = {
        {'a', "ₐ"}, {'e', "ₑ"}, {'h', "ₕ"}, {'i', "ᵢ"}, {'j', "ⱼ"}, {'k', "ₖ"}, {'l', "ₗ"}, {'m', "ₘ"},
        {'n', "ₙ"}, {'o', "ₒ"}, {'p', "ₚ"}, {'r', "ᵣ"}, {'s', "ₛ"}, {'t', "ₜ"}, {'u', "ᵤ"}, {'v', "ᵥ"},
        {'x', "ₓ"},
    };
    std::string out;
    for (char c : in) {
        if (!super && c >= 'a' && c <= 'z') {
            const auto it = std::find_if(std::begin(kSubLetters), std::end(kSubLetters),
                                         [c](const auto& p) { return p.first == c; });
            if (it == std::end(kSubLetters)) return "";
            out += it->second;
            continue;
        }
        if (c >= '0' && c <= '9') out += (super ? kSup : kSub)[c - '0'];
        else if (c == '-') out += super ? "⁻" : "₋";
        else if (c == '+') out += super ? "⁺" : "₊";
        else if (c == 'n' && super) out += "ⁿ";
        else if (c == ' ') continue;
        else return "";
    }
    return out;
}

// Reads a {...} group starting at s[pos] == '{' (handles nesting), or a
// single character otherwise. Advances pos past it.
std::string ReadGroup(const std::string& s, size_t& pos) {
    while (pos < s.size() && s[pos] == ' ') ++pos;  // "\sqrt 3", "\frac 1 2"
    if (pos >= s.size()) return "";
    if (s[pos] != '{') {
        // A whole character, not a byte: symbols like \theta are already
        // multi-byte UTF-8 ("θ") by the time scripts are processed.
        const size_t len = Utf8::CharLength(s, pos);
        pos += len;
        return s.substr(pos - len, len);
    }
    int depth = 0;
    const size_t start = ++pos;
    for (; pos < s.size(); ++pos) {
        if (s[pos] == '{') ++depth;
        else if (s[pos] == '}' && depth-- == 0) break;
    }
    std::string group = s.substr(start, pos - start);
    if (pos < s.size()) ++pos;
    return group;
}

// Turns the LaTeX small local models write their math in (they score
// noticeably worse when told not to -- see LocalLLMClient.cpp) into
// readable text: \frac{a}{b} -> (a)/(b), 10^{-6} -> 10⁻⁶, C_{1} -> C₁,
// \Omega -> Ω, and drops the leftover markup.
std::string LatexToText(std::string s) {
    ReplaceAll(s, "\\dfrac", "\\frac");
    ReplaceAll(s, "\\tfrac", "\\frac");
    for (size_t pos; (pos = s.find("\\frac")) != std::string::npos;) {
        size_t p = pos + 5;
        const std::string num = ReadGroup(s, p);
        const std::string den = ReadGroup(s, p);
        s.replace(pos, p - pos, "(" + num + ")/(" + den + ")");
    }
    for (size_t pos; (pos = s.find("\\sqrt")) != std::string::npos;) {
        size_t p = pos + 5;
        const std::string arg = ReadGroup(s, p);
        s.replace(pos, p - pos, "√(" + arg + ")");
    }
    // Longest names first where one is a prefix of another (\rightarrow
    // before \right, \left before \le, \infty/\int before \in).
    const std::pair<const char*, const char*> symbols[] = {
        {"\\rightarrow", "→"}, {"\\Rightarrow", "⇒"}, {"\\leftarrow", "←"}, {"\\left", ""},
        {"\\right", ""},       {"\\leq", "≤"},        {"\\geq", "≥"},       {"\\neq", "≠"},
        {"\\le", "≤"},         {"\\ge", "≥"},         {"\\ne", "≠"},        {"\\approx", "≈"},
        {"\\times", "×"},      {"\\cdot", "·"},       {"\\pm", "±"},        {"\\infty", "∞"},
        {"\\int", "∫"},        {"\\sum", "∑"},        {"\\partial", "∂"},   {"\\hbar", "ℏ"},
        {"\\circ", "°"},       {"\\to", "→"},         {"\\varepsilon", "ε"}, {"\\epsilon", "ε"},
        {"\\alpha", "α"},      {"\\beta", "β"},       {"\\gamma", "γ"},     {"\\Delta", "Δ"},
        {"\\delta", "δ"},      {"\\theta", "θ"},      {"\\lambda", "λ"},    {"\\mu", "µ"},
        {"\\pi", "π"},         {"\\rho", "ρ"},        {"\\sigma", "σ"},     {"\\tau", "τ"},
        {"\\phi", "φ"},        {"\\omega", "ω"},      {"\\Omega", "Ω"},     {"\\Phi", "Φ"},
        {"\\mathcal", ""},     {"\\mathbf", ""},     {"\\vec", ""},       {"\\hat", ""},
        {"\\overline", ""},    {"\\bar", ""},        {"\\ell", "ℓ"},      {"\\oint", "∮"},
        {"\\text", ""},        {"\\mathrm", ""},      {"\\boxed", ""},      {"\\quad", " "},
        {"\\,", " "},          {"\\;", " "},         {"\\!", ""},          {"\\(", ""},
        {"\\)", ""},           {"\\[", ""},           {"\\]", ""},
    };
    for (const auto& [from, to] : symbols) ReplaceAll(s, from, to);
    // ^{...} / ^x and _{...} / _x into Unicode scripts where possible.
    std::string out;
    for (size_t i = 0; i < s.size();) {
        if ((s[i] == '^' || s[i] == '_') && i + 1 < s.size()) {
            const bool super = s[i] == '^';
            size_t p = i + 1;
            const std::string group = ReadGroup(s, p);
            const std::string script = ToScript(group, super);
            if (!script.empty()) {
                out += script;
            } else if (super) {
                out += "^(" + group + ")";
            } else {
                out += (group.size() == 1 ? "" : "_") + group;  // r_{int} -> r_int, C_{A} -> CA
            }
            i = p;
        } else {
            out += s[i++];
        }
    }
    ReplaceAll(out, "{", "");
    ReplaceAll(out, "}", "");
    return out;
}

// Models are told to answer in plain text (Claude via kPlainTextRule), but
// Markdown and LaTeX still show up -- the local model is deliberately
// allowed LaTeX -- and raw "**" or "\frac" mid-lecture is hard to read.
}  // namespace

namespace AnswerText {

std::string CleanLine(std::string line) {
    size_t indent = line.find_first_not_of(" \t");
    if (indent == std::string::npos) return "";
    std::string body = line.substr(indent);
    while (!body.empty() && body[0] == '#') body.erase(0, 1);
    if (body.rfind("- ", 0) == 0 || body.rfind("* ", 0) == 0) body = "• " + body.substr(2);
    for (const char* marker : {"**", "__", "`", "$$", "$"}) ReplaceAll(body, marker, "");
    body = LatexToText(body);
    const size_t start = body.find_first_not_of(' ');
    return start == std::string::npos ? "" : std::string(std::min(indent, size_t(4)), ' ') + body.substr(start);
}

}  // namespace AnswerText
