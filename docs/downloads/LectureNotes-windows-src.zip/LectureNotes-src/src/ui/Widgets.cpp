// Shared Dear ImGui look and widgets for the overlay and the Setup window,
// used by both the macOS (UIApp.mm) and Windows (WinApp.cpp) front ends.

#include "ui/Widgets.h"

#include <cctype>
#include <cmath>
#include <sys/stat.h>

#include "ui/AnswerText.h"

namespace {

bool fileExists(const std::string& path) {
    struct stat st{};
    return ::stat(path.c_str(), &st) == 0;
}

// Point size the UI is designed at; actual font atlas is baked at this
// times the display's Retina scale (see LoadModernFont) so glyphs stay
// crisp instead of a low-res bitmap getting stretched 2x.
constexpr float kBaseFontPointSize = 14.0f;

// Loads the system San Francisco font so the UI reads as clean, modern
// text instead of Dear ImGui's tiny default bitmap font. Falls back to the
// built-in font if the system font can't be found for some reason.
//
// `scale` should be the screen's backingScaleFactor (2.0 on Retina): the
// atlas is rasterized at kBaseFontPointSize * scale physical pixels, and
// the caller sets io.FontGlobalScale = 1/scale so it still lays out at
// kBaseFontPointSize logical points but samples from a high-res glyph
// instead of a blurry/pixelated stretched one.
// Dear ImGui 1.91 only bakes the glyphs listed here into its atlas, and its
// default is Latin-1 -- so answers full of 10⁻⁶, C₁, →, √, ≈, Ω, π rendered
// every one of those as "?". These are the blocks physics/math answers use.
const ImWchar kGlyphRanges[] = {
    0x0020, 0x00FF,  // Basic Latin + Latin-1 (µ × ± ° ²)
    0x0370, 0x03FF,  // Greek (Ω π λ Δ θ ε)
    0x1D62, 0x1D65,  // Subscript i, r, u, v (AnswerText writes r_{int} as rᵢₙₜ)
    0x2000, 0x206F,  // General punctuation (– — ’ … ′)
    0x2070, 0x209F,  // Superscripts and subscripts (10⁻⁶, C₁)
    0x2100, 0x214F,  // Letterlike symbols (ℏ Å)
    0x2190, 0x21FF,  // Arrows (→ ⇒)
    0x2200, 0x22FF,  // Mathematical operators (√ ≈ ≤ ∫ ∑ ∂ ∞)
    0x2300, 0x23FF,  // Miscellaneous technical
    0x25A0, 0x25FF,  // Geometric shapes
    0x2700, 0x27BF,  // Dingbats (✓ ✗)
    0x2C7C, 0x2C7C,  // Subscript j
    0,
};

// Fills in any of kGlyphRanges the primary font doesn't cover. In merge
// mode glyphs the primary font already has are kept, so this only adds
// what's missing.
void MergeSymbolFallback(float pixelSize) {
#ifdef _WIN32
    const char* fallbacks[] = {
        "C:\\Windows\\Fonts\\seguisym.ttf",   // Segoe UI Symbol: arrows, math, dingbats
        "C:\\Windows\\Fonts\\cambria.ttc",    // Cambria Math: operators, sub/superscripts
    };
#else
    const char* fallbacks[] = {
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/Apple Symbols.ttf",
    };
#endif
    for (const char* path : fallbacks) {
        if (!fileExists(path)) continue;
        ImFontConfig merge;
        merge.MergeMode = true;
        merge.OversampleH = 2;
        merge.OversampleV = 2;
        merge.PixelSnapH = false;
        ImGui::GetIO().Fonts->AddFontFromFileTTF(path, pixelSize, &merge, kGlyphRanges);
    }
}

}  // namespace

void LoadModernFont(float scale) {
    ImGuiIO& io = ImGui::GetIO();
#ifdef _WIN32
    const char* candidates[] = {
        "C:\\Windows\\Fonts\\segoeui.ttf",
        "C:\\Windows\\Fonts\\arial.ttf",
    };
#else
    const char* candidates[] = {
        "/System/Library/Fonts/SFNS.ttf",
        "/System/Library/Fonts/SFNSText.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    };
#endif
    ImFontConfig cfg;
    cfg.OversampleH = 2;
    cfg.OversampleV = 2;
    cfg.PixelSnapH = false;
    const float pixelSize = kBaseFontPointSize * scale;
    for (const char* path : candidates) {
        if (fileExists(path)) {
            if (io.Fonts->AddFontFromFileTTF(path, pixelSize, &cfg, kGlyphRanges)) {
                MergeSymbolFallback(pixelSize);
                io.FontGlobalScale = 1.0f / scale;
                return;
            }
        }
    }
    io.Fonts->AddFontDefault();
}


// Light frosted-glass UI for the overlay, like a native macOS panel: dark
// text, hairline borders, and tight padding/spacing.
void ApplyGlassStyle() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImGui::StyleColorsDark();

    style.WindowRounding = 0.0f;  // the NSWindow layer already clips the outer shape
    style.ChildRounding = kPanelRounding;
    style.FrameRounding = kControlRounding;
    style.PopupRounding = kPanelRounding;
    style.GrabRounding = kControlRounding;
    style.ScrollbarRounding = kControlRounding;
    style.WindowBorderSize = 0.0f;
    style.FrameBorderSize = 1.0f;
    style.ChildBorderSize = 1.0f;

    style.WindowPadding = ImVec2(10, 8);
    style.FramePadding = ImVec2(8, 3);
    style.ItemSpacing = ImVec2(6, 5);
    style.ScrollbarSize = 8.0f;

    ImVec4* colors = style.Colors;
    colors[ImGuiCol_Text]                 = Pal::Ink;
    colors[ImGuiCol_TextDisabled]         = Pal::Muted;
    colors[ImGuiCol_TextSelectedBg]       = ImVec4(0.08f, 0.40f, 0.88f, 0.25f);
    colors[ImGuiCol_WindowBg]             = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_ChildBg]              = ImVec4(1.00f, 1.00f, 1.00f, 0.45f);
    colors[ImGuiCol_Border]               = ImVec4(0.0f, 0.0f, 0.0f, 0.13f);
    colors[ImGuiCol_FrameBg]              = ImVec4(1.00f, 1.00f, 1.00f, 0.75f);
    colors[ImGuiCol_FrameBgHovered]       = ImVec4(1.00f, 1.00f, 1.00f, 0.88f);
    colors[ImGuiCol_FrameBgActive]        = ImVec4(1.00f, 1.00f, 1.00f, 0.95f);
    colors[ImGuiCol_Button]               = ImVec4(1.00f, 1.00f, 1.00f, 0.75f);
    colors[ImGuiCol_ButtonHovered]        = ImVec4(1.00f, 1.00f, 1.00f, 0.95f);
    colors[ImGuiCol_ButtonActive]         = ImVec4(0.90f, 0.91f, 0.93f, 1.00f);
    colors[ImGuiCol_PlotHistogram]        = ImVec4(0.08f, 0.40f, 0.88f, 0.85f);
    colors[ImGuiCol_ScrollbarBg]          = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_ScrollbarGrab]        = ImVec4(0.0f, 0.0f, 0.0f, 0.18f);
    colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.0f, 0.0f, 0.0f, 0.28f);
    colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.0f, 0.0f, 0.0f, 0.38f);
    colors[ImGuiCol_Separator]            = ImVec4(0.0f, 0.0f, 0.0f, 0.10f);
    colors[ImGuiCol_PopupBg]              = ImVec4(0.98f, 0.98f, 0.99f, 0.97f);
}

// Plain opaque light style for the Setup window — a normal-looking
// installer-style window, deliberately NOT styled like the transparent
// overlay so the two feel like separate, distinct pieces.
void ApplySetupStyle() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImGui::StyleColorsLight();

    style.WindowRounding = 0.0f;
    style.ChildRounding = 8.0f;
    style.FrameRounding = 6.0f;
    style.PopupRounding = 8.0f;
    style.GrabRounding = 6.0f;
    style.ScrollbarRounding = 6.0f;
    style.WindowBorderSize = 0.0f;
    style.FrameBorderSize = 1.0f;
    style.ChildBorderSize = 1.0f;

    style.WindowPadding = ImVec2(20, 18);
    style.FramePadding = ImVec2(10, 6);
    style.ItemSpacing = ImVec2(8, 8);
    style.ScrollbarSize = 10.0f;

    ImVec4* colors = style.Colors;
    colors[ImGuiCol_Text]           = ImVec4(0.10f, 0.10f, 0.12f, 1.00f);
    colors[ImGuiCol_TextDisabled]   = ImVec4(0.45f, 0.45f, 0.48f, 1.00f);
    colors[ImGuiCol_WindowBg]       = ImVec4(0.96f, 0.96f, 0.97f, 1.00f);
    colors[ImGuiCol_ChildBg]        = ImVec4(1.00f, 1.00f, 1.00f, 0.55f);
    colors[ImGuiCol_Border]         = ImVec4(0.0f, 0.0f, 0.0f, 0.12f);
    colors[ImGuiCol_FrameBg]        = ImVec4(0.0f, 0.0f, 0.0f, 0.05f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.0f, 0.0f, 0.0f, 0.08f);
    colors[ImGuiCol_FrameBgActive]  = ImVec4(0.0f, 0.0f, 0.0f, 0.12f);
    colors[ImGuiCol_Separator]      = ImVec4(0.0f, 0.0f, 0.0f, 0.12f);
    colors[ImGuiCol_ScrollbarBg]    = ImVec4(0, 0, 0, 0);
}

// Draws text twice — once offset by 1px in a faint light color, then the
// real color on top — a subtle lift so it stays crisp on the frosted glass. Only
// used by the overlay (AppViewController); the opaque Setup window has a
// known solid background and doesn't need it.
//
// The real text is laid out first and the shadow painted underneath it via
// a draw-list channel, so the shadow lands exactly where ImGui put the text.
// Drawing the shadow as a second Text() call instead left it several pixels
// off whenever AlignTextToFramePadding was in effect (the "Me"/"Them"
// labels showed up doubled).
void ShadowedText(const ImVec4& color, const char* text) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->ChannelsSplit(2);
    dl->ChannelsSetCurrent(1);
    ImGui::TextColored(color, "%s", text);
    const ImVec2 min = ImGui::GetItemRectMin();
    dl->ChannelsSetCurrent(0);
    dl->AddText(ImVec2(min.x, min.y + 1), IM_COL32(255, 255, 255, 110), text);
    dl->ChannelsMerge();
}

void ShadowedTextWrapped(const ImVec4& color, const char* text) {
    const ImVec2 pos = ImGui::GetCursorPos();
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 0.43f));
    ImGui::SetCursorPos(ImVec2(pos.x, pos.y + 1));
    ImGui::TextWrapped("%s", text);
    ImGui::PopStyleColor();
    ImGui::SetCursorPos(pos);
    ImGui::PushStyleColor(ImGuiCol_Text, color);
    ImGui::TextWrapped("%s", text);
    ImGui::PopStyleColor();
}

// Renders an answer line by line with the cleanup above, and highlights the
// final "Answer: ..." line so the result is findable at a glance.
void DrawAnswerText(const std::string& answer) {
    const ImVec4 normal = Pal::Ink;
    const ImVec4 highlight = Pal::Green;
    const ImVec4 heading = Pal::Blue;
    size_t start = 0;
    while (start <= answer.size()) {
        size_t end = answer.find('\n', start);
        if (end == std::string::npos) end = answer.size();
        const std::string line = AnswerText::CleanLine(answer.substr(start, end - start));
        if (line.empty()) {
            ImGui::Spacing();
        } else {
            std::string lower = line.substr(0, 7);
            for (char& c : lower) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            // Short "Title:" lines (the notes' section headers) get their
            // own color so a long notes tab is easy to scan.
            const bool isHeading = line.size() <= 24 && line.back() == ':' && line[0] != ' ';
            const ImVec4& color = lower.rfind("answer", 0) == 0 ? highlight : isHeading ? heading : normal;
            ShadowedTextWrapped(color, line.c_str());
        }
        start = end + 1;
    }
}

// Small "who's talking" indicator: a colored dot (lit when that stream's
// level is above a noise-floor threshold, dim gray otherwise) followed by
// a compact label — replaces a full-width labeled progress bar so the
// header stays a single thin row instead of eating a quarter of the
// window. Also (re)used by the Setup window's locked preview pane with a
// level that's always 0, for a permanently "dim/idle" mockup dot.
void DrawSpeakerDot(const char* label, float level, ImU32 activeColor, bool useShadow) {
    ImGui::AlignTextToFramePadding();
    const bool active = level > 0.012f;
    const float radius = 4.0f;
    const float lineHeight = ImGui::GetTextLineHeight();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    // AlignTextToFramePadding shifts the label down by FramePadding.y; the
    // dot has to move with it or it sits above the text.
    const ImVec2 center(p.x + radius, p.y + ImGui::GetStyle().FramePadding.y + lineHeight * 0.5f);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (active) {
        dl->AddCircleFilled(center, radius, activeColor, 16);
    } else {
        dl->AddCircle(center, radius, IM_COL32(110, 114, 122, 220), 16, 1.2f);
    }
    ImGui::Dummy(ImVec2(radius * 2.0f + 8.0f, lineHeight));
    ImGui::SameLine(0, 4);
    if (useShadow) {
        ShadowedText(Pal::Ink, label);
    } else {
        ImGui::TextDisabled("%s", label);
    }
}

// Outline-only button: faint tint fill, accent-colored border and text,
// instead of a solid filled shape. Used by both windows.
bool OutlineButton(const char* label, const ImVec4& accent, const ImVec2& size) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(accent.x, accent.y, accent.z, 0.08f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(accent.x, accent.y, accent.z, 0.16f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(accent.x, accent.y, accent.z, 0.24f));
    ImGui::PushStyleColor(ImGuiCol_Border, accent);
    ImGui::PushStyleColor(ImGuiCol_Text, accent);
    const bool clicked = ImGui::Button(label, size);
    ImGui::PopStyleColor(5);
    return clicked;
}

// Chrome-style tab: rounded top corners, an accent underline when
// selected, and a small "x" that only appears while hovering that tab
// (whether or not it's the selected one) -- clicking it closes the tab
// instead of selecting it. `closeable` is false for the permanent
// "script" (transcript) and "txt" tabs.
//
// Returns true if the tab body (not the close x) was clicked, meaning
// the caller should select it. Sets *closeRequested to true instead if
// the close x was what got clicked.

// Shared with the shrink-to-fit sizing pass in drawMainUI, so both agree
// on exactly how wide a given label will render.
float TabWidthForLabel(const std::string& label, bool closeable) {
    const ImVec2 textSize = ImGui::CalcTextSize(label.c_str());
    return textSize.x + kTabHorizontalPadding * 2.0f + (closeable ? kTabCloseReserve : 0.0f);
}

// `divider` draws a short hairline at the tab's right edge; the caller
// turns it off next to the selected tab, like Chrome.
bool DrawTab(const char* uniqueId, const std::string& label, bool isSelected, bool closeable, bool* closeRequested,
             bool divider) {
    ImGui::PushID(uniqueId);

    const ImVec2 textSize = ImGui::CalcTextSize(label.c_str());
    const float tabWidth = TabWidthForLabel(label, closeable);

    const ImVec2 p0 = ImGui::GetCursorScreenPos();
    const ImVec2 p1 = ImVec2(p0.x + tabWidth, p0.y + kTabHeight);

    ImGui::InvisibleButton("##tab", ImVec2(tabWidth, kTabHeight));
    const bool tabClicked = ImGui::IsItemClicked();
    const bool tabHovered = ImGui::IsItemHovered();

    // The selected tab is a solid light card whose outline runs up one
    // side, across the top, and down the other, leaving its bottom open so
    // it merges with the strip's baseline (drawn by the caller underneath).
    ImDrawList* dl = ImGui::GetWindowDrawList();
    constexpr float r = 6.0f;
    if (isSelected) {
        dl->AddRectFilled(p0, ImVec2(p1.x, p1.y + 1.0f), IM_COL32(255, 255, 255, 235), r, ImDrawFlags_RoundCornersTop);
        dl->PathLineTo(ImVec2(p0.x + 0.5f, p1.y + 0.5f));
        dl->PathArcToFast(ImVec2(p0.x + r + 0.5f, p0.y + r + 0.5f), r, 6, 9);
        dl->PathArcToFast(ImVec2(p1.x - r - 0.5f, p0.y + r + 0.5f), r, 9, 12);
        dl->PathLineTo(ImVec2(p1.x - 0.5f, p1.y + 0.5f));
        dl->PathStroke(IM_COL32(0, 0, 0, 120), 0, 1.0f);
    } else if (tabHovered) {
        dl->AddRectFilled(ImVec2(p0.x + 1, p0.y + 2), ImVec2(p1.x - 1, p1.y - 2), IM_COL32(0, 0, 0, 14), r);
    }
    if (divider) {
        dl->AddLine(ImVec2(p1.x - 0.5f, p0.y + 5), ImVec2(p1.x - 0.5f, p1.y - 4), IM_COL32(0, 0, 0, 55), 1.0f);
    }

    const ImU32 textColor = isSelected ? IM_COL32(28, 30, 36, 255) : IM_COL32(82, 86, 96, 255);
    dl->AddText(ImVec2(p0.x + kTabHorizontalPadding, p0.y + (kTabHeight - textSize.y) * 0.5f), textColor, label.c_str());

    bool closeClickedHere = false;
    if (closeable && tabHovered) {
        const ImVec2 xCenter(p1.x - kTabCloseReserve * 0.5f - 2.0f - 0.5f, p0.y + kTabHeight * 0.5f - 0.5f);  // AddLine adds +0.5
        const float xr = 3.5f;
        const bool overX = ImGui::IsMouseHoveringRect(ImVec2(xCenter.x - xr - 3, xCenter.y - xr - 3),
                                                        ImVec2(xCenter.x + xr + 3, xCenter.y + xr + 3));
        if (overX) {
            dl->AddCircleFilled(xCenter, xr + 3.5f, IM_COL32(0, 0, 0, 22), 16);
        }
        const ImU32 xColor = overX ? IM_COL32(200, 48, 44, 255) : IM_COL32(90, 94, 104, 255);
        dl->AddLine(ImVec2(xCenter.x - xr, xCenter.y - xr), ImVec2(xCenter.x + xr, xCenter.y + xr), xColor, 1.4f);
        dl->AddLine(ImVec2(xCenter.x - xr, xCenter.y + xr), ImVec2(xCenter.x + xr, xCenter.y - xr), xColor, 1.4f);
        if (overX && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            closeClickedHere = true;
        }
    }

    ImGui::SetCursorScreenPos(ImVec2(p0.x, p0.y));
    ImGui::Dummy(ImVec2(tabWidth, kTabHeight));

    ImGui::PopID();

    if (closeRequested) {
        *closeRequested = closeClickedHere;
    }
    return tabClicked && !closeClickedHere;
}

// Truncates to a Chrome-tab-like length so a long question doesn't blow
// out the tab bar's width.
std::string TruncateForTab(const std::string& text, size_t maxChars) {
    if (text.size() <= maxChars) {
        return text;
    }
    return text.substr(0, maxChars) + "...";
}

// Small checklist bullet: a filled checkmark circle once satisfied, a
// dim hollow ring while still pending.
void DrawSetupCheckIcon(bool satisfied) {
    const float radius = 8.0f;
    const float lineHeight = ImGui::GetTextLineHeight();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const ImVec2 center(p.x + radius, p.y + lineHeight * 0.5f);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (satisfied) {
        dl->AddCircleFilled(center, radius, IM_COL32(60, 200, 110, 255), 20);
        dl->AddLine(ImVec2(center.x - 3.5f, center.y), ImVec2(center.x - 0.5f, center.y + 3.5f),
                    IM_COL32(255, 255, 255, 255), 1.6f);
        dl->AddLine(ImVec2(center.x - 0.5f, center.y + 3.5f), ImVec2(center.x + 4.5f, center.y - 3.5f),
                    IM_COL32(255, 255, 255, 255), 1.6f);
    } else {
        dl->AddCircle(center, radius, IM_COL32(140, 140, 145, 255), 20, 1.4f);
    }
    ImGui::Dummy(ImVec2(radius * 2.0f + 10.0f, lineHeight));
    ImGui::SameLine(0, 4);
}

// Hand-drawn camera glyph for the screen-region "solve this" button --
// deliberately just two shapes (a rounded-rect body + a circular lens),
// simplified from an earlier version with an extra viewfinder-nub
// rectangle. There's no icon font loaded, so this is drawn with plain
// ImDrawList primitives the same way DrawSetupCheckIcon is.
void DrawCameraIcon(const ImVec2& center, ImU32 color) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRect(ImVec2(center.x - 7, center.y - 5), ImVec2(center.x + 7, center.y + 5), color, 2.5f, 0, 1.4f);
    dl->AddCircle(center, 3.2f, color, 16, 1.4f);
}


// Square icon button for the top-right cluster. The glyph is drawn by hand
// at the button's exact center (font glyphs like "+"/"x" sit off-center at
// this size). `tint` colors the icon and, when `active`, the fill.
bool CornerIconButton(const char* id, float size, CornerIcon icon, ImU32 tint, bool active,
                      bool dangerHover) {
    const ImVec2 p0 = ImGui::GetCursorScreenPos();
    const ImVec2 p1(p0.x + size, p0.y + size);
    const bool clicked = ImGui::InvisibleButton(id, ImVec2(size, size));
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImU32 fill = IM_COL32(255, 255, 255, 190);
    if (active) fill = IM_COL32(255, 255, 255, 250);
    if (hovered) fill = dangerHover ? IM_COL32(255, 228, 226, 250) : IM_COL32(255, 255, 255, 250);
    if (held) fill = dangerHover ? IM_COL32(250, 205, 202, 255) : IM_COL32(228, 230, 235, 255);
    dl->AddRectFilled(p0, p1, fill, kControlRounding);
    dl->AddRect(ImVec2(p0.x + 0.5f, p0.y + 0.5f), ImVec2(p1.x - 0.5f, p1.y - 0.5f), IM_COL32(0, 0, 0, 150),
                kControlRounding, 0, 1.0f);

    // True center for shapes; lines use `lc` because ImDrawList::AddLine
    // itself shifts every line by +0.5,+0.5.
    const ImVec2 c((p0.x + p1.x) * 0.5f, (p0.y + p1.y) * 0.5f);
    const ImVec2 lc(c.x - 0.5f, c.y - 0.5f);
    const ImU32 col = (hovered && dangerHover) ? IM_COL32(200, 48, 44, 255) : tint;
    switch (icon) {
        case CornerIcon::Camera:
            DrawCameraIcon(c, col);
            break;
        case CornerIcon::Check:
            dl->AddLine(ImVec2(lc.x - 4.0f, lc.y + 0.5f), ImVec2(lc.x - 1.0f, lc.y + 3.5f), col, 1.6f);
            dl->AddLine(ImVec2(lc.x - 1.0f, lc.y + 3.5f), ImVec2(lc.x + 4.5f, lc.y - 3.5f), col, 1.6f);
            break;
        case CornerIcon::Cancel:
        case CornerIcon::Close:
            dl->AddLine(ImVec2(lc.x - 3.5f, lc.y - 3.5f), ImVec2(lc.x + 3.5f, lc.y + 3.5f), col, 1.5f);
            dl->AddLine(ImVec2(lc.x - 3.5f, lc.y + 3.5f), ImVec2(lc.x + 3.5f, lc.y - 3.5f), col, 1.5f);
            break;
        case CornerIcon::Plus:
            dl->AddLine(ImVec2(lc.x - 4.5f, lc.y), ImVec2(lc.x + 4.5f, lc.y), col, 1.5f);
            dl->AddLine(ImVec2(lc.x, lc.y - 4.5f), ImVec2(lc.x, lc.y + 4.5f), col, 1.5f);
            break;
    }
    return clicked;
}

