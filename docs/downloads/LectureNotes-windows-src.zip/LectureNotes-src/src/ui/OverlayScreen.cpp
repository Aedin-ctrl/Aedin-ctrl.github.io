// The overlay's whole ImGui UI (tabs, corner buttons, transcript, the txt
// tab, answers, documents drawer, resize grip), shared by the macOS and
// Windows front ends. Everything platform-specific goes through OverlayHost.

#include "ui/OverlayScreen.h"

#include <algorithm>
#include <cstdio>

#include "imgui.h"

#include "app/App.h"
#include "asr/Speaker.h"
#include "ui/Widgets.h"

OverlayScreen::OverlayScreen(App& app, OverlayHost& host) : _app(&app), host_(host) {
    _genInput[0] = '\0';
}

void OverlayScreen::willSleep() {
    _wasRecordingBeforeSleep = _app->isRecording();
}

void OverlayScreen::didWake() {
    if (!_wasRecordingBeforeSleep) {
        return;
    }
    _wasRecordingBeforeSleep = false;
    // A full stop+restart is the safe recovery for audio devices that come
    // back from sleep in a zombie state -- same path as a dead-device
    // restart (see pollAudioHealthAndRecover).
    _app->stopRecording(/*userInitiated=*/false);
    _app->requestStart();
    _lastNotice = "Recording restarted after your computer woke up.";
}

void OverlayScreen::beginScreenCapture() {
    std::string error;
    if (host_.beginScreenCapture(error)) {
        _captureModeActive = true;
    } else if (!error.empty()) {
        _lastError = error;
    }
}

void OverlayScreen::confirmScreenCapture() {
    std::string error;
    // On failure capture mode stays on, so the user can fix the framing
    // (e.g. move the window onto one display) and click the check again.
    if (host_.confirmScreenCapture(_contentRectX, _contentRectY, _contentRectWidth, _contentRectHeight, error)) {
        _captureModeActive = false;
    } else if (!error.empty()) {
        _lastError = error;
    }
}

void OverlayScreen::draw() {
    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(io.DisplaySize);
    // NoScrollbar/NoScrollWithMouse: without these, ImGui lets the whole
    // outer window itself scroll via mouse wheel/trackpad the moment its
    // content is even a pixel taller than the window (only the inner
    // TranscriptScroll/AnswerScroll children below are meant to scroll).
    // That outer scroll was the cause of the reported "I can scroll on the
    // whole overlay" bug -- it shifts everything ImGui draws without the
    // window itself (or the blur views pinned to its measured content
    // rect) moving in a matching way, which is also what produced the
    // stray unblurred gaps.
    ImGui::Begin("LectureNotes", nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                      ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                      ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar |
                      ImGuiWindowFlags_NoScrollWithMouse);

    // Close/quit button, pinned to the top-right corner: borderless
    // windows have no titlebar close control otherwise. Drawn first, then
    // the cursor is reset to the top-left so it doesn't disturb the rest
    // of the layout. The "+" upload button sits immediately to its left,
    // and the camera/"solve this" button to the left of that.
    {
        const float closeSize = 20.0f;
        const float plusSize = 20.0f;
        const float cameraSize = 20.0f;
        constexpr float kButtonGap = 4.0f;
        const ImGuiStyle& s = ImGui::GetStyle();
        const float rightEdge = ImGui::GetWindowWidth() - s.WindowPadding.x;

        const uint64_t docVersion = _app->documentVersion();
        if (docVersion != _cachedDocVersion) {
            _cachedDocuments = _app->documentSnapshot();
            _cachedDocVersion = docVersion;
        }
        const std::vector<UploadedDocument>& docs = _cachedDocuments;

        // Camera / "solve this" button: camera icon that becomes a green
        // check (plus a red cancel X) once a capture is in progress --
        // see beginScreenCapture/confirmScreenCapture/cancelScreenCapture.
        //
        // All corner-button positions are computed here, right-to-left,
        // from one running cursor -- close, then +, then (while
        // capturing) the red cancel X, then the camera/check button --
        // so adding/removing a button from the cluster can never leave a
        // stale hardcoded position on another one out of sync (found via
        // screenshot: the "+" button used to have its own fixed formula
        // that never accounted for the camera button's width at all,
        // silently overlapping it).
        const bool capturing = _captureModeActive;
        const float plusCursorX = rightEdge - closeSize - kButtonGap - plusSize;
        float cursorX = plusCursorX;
        float cancelCursorX = 0.0f;
        if (capturing) {
            cursorX -= kButtonGap + cameraSize;
            cancelCursorX = cursorX;
        }
        cursorX -= kButtonGap + cameraSize;
        const float cameraCursorX = cursorX;
        ImGui::SetCursorPos(ImVec2(cameraCursorX, 0));
        const ImU32 iconInk = IM_COL32(40, 43, 50, 255);

        if (!capturing) {
            if (CornerIconButton("##camera", cameraSize, CornerIcon::Camera, iconInk)) {
                beginScreenCapture();
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Capture part of your screen and solve/explain it");
            }
        } else {
            if (CornerIconButton("##confirm_capture", cameraSize, CornerIcon::Check, IM_COL32(20, 133, 69, 255),
                                 /*active=*/true)) {
                confirmScreenCapture();
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Capture the selected region and solve/explain it");
            }

            ImGui::SetCursorPos(ImVec2(cancelCursorX, 0));
            if (CornerIconButton("##cancel_capture", cameraSize, CornerIcon::Cancel, IM_COL32(200, 48, 44, 255),
                                 /*active=*/false, /*dangerHover=*/true)) {
                _captureModeActive = false;
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Cancel");
            }
        }

        // "+" upload button: toggles the documents side panel (list +
        // delete + add + scan status) -- see drawDocumentsPanel.
        ImGui::SetCursorPos(ImVec2(plusCursorX, 0));
        if (CornerIconButton("##plus", plusSize, CornerIcon::Plus, iconInk, /*active=*/_showDocumentsPanel)) {
            _showDocumentsPanel = !_showDocumentsPanel;
        }
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(docs.empty() ? "Upload a resume or documents to help answer questions"
                                            : "Manage uploaded documents");
        }
        if (!docs.empty()) {
            // Small badge in the button's corner showing how many
            // documents are loaded -- otherwise there's no feedback at
            // all that an upload actually took.
            const ImVec2 btnMax = ImGui::GetItemRectMax();
            const ImVec2 btnMin = ImGui::GetItemRectMin();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            const ImVec2 badgeCenter(btnMax.x - 3.0f, btnMin.y + 3.0f);
            dl->AddCircleFilled(badgeCenter, 6.0f, IM_COL32(20, 133, 69, 255), 12);
            char countBuf[8];
            snprintf(countBuf, sizeof(countBuf), "%zu", docs.size());
            const ImVec2 textSize = ImGui::CalcTextSize(countBuf);
            dl->AddText(ImVec2(badgeCenter.x - textSize.x * 0.5f, badgeCenter.y - textSize.y * 0.5f),
                        IM_COL32(255, 255, 255, 255), countBuf);
        }

        ImGui::SetCursorPos(ImVec2(rightEdge - closeSize, 0));
        if (CornerIconButton("##close", closeSize, CornerIcon::Close, iconInk, /*active=*/false, /*dangerHover=*/true)) {
            if (_app->isRecording()) {
                _app->stopRecording(/*userInitiated=*/false);  // closing the app: no notes
            }
            host_.quitApp();
        }
        ImGui::SetCursorPos(ImVec2(0, 0));
    }

    drawMainUI();
    if (_showDocumentsPanel) {
        // Drawn after (and therefore visually and interactively on top
        // of) the rest of the UI -- an overlaid drawer, not a squeezed-in
        // sidebar, since the window is small enough that a permanent
        // sidebar would leave little room for anything else.
        drawDocumentsPanel();
    }
    drawResizeGrip();

    ImGui::End();
}

// Polled once per frame from drawMainUI while recording. A dead audio
// device (Bluetooth dropout, unplugged mic, etc.) used to mean silently
// "recording" nothing forever with zero indication anything was wrong;
// this restarts the pipeline once per episode and tells the user either
// way.
void OverlayScreen::pollAudioHealthAndRecover() {
    if (!_app->isRecording()) {
        _recoveringFromAudioProblem = false;
        return;
    }
    if (!_app->audioDeviceProblemDetected()) {
        _recoveringFromAudioProblem = false;
        return;
    }
    if (_recoveringFromAudioProblem) {
        return;  // already attempted for this episode; don't loop every frame
    }
    _recoveringFromAudioProblem = true;
    _app->stopRecording(/*userInitiated=*/false);
    _app->requestStart();
    _lastNotice = "An audio device disconnected -- restarting capture.";
}

// Borderless windows don't reliably get the standard edge/corner
// resize-drag cursor and hit-testing that titled windows do, so this
// draws and drives a small manual grip in the bottom-right corner
// instead: an invisible drag button, plus two diagonal lines as a visual
// affordance, that directly resizes the NSWindow's frame on drag.
void OverlayScreen::drawResizeGrip() {
    constexpr float kGripSize = 16.0f;
    constexpr float kMinWidth = 260.0f;
    constexpr float kMinHeight = 200.0f;

    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetCursorPos(ImVec2(io.DisplaySize.x - kGripSize, io.DisplaySize.y - kGripSize));
    ImGui::InvisibleButton("##resize_grip", ImVec2(kGripSize, kGripSize));

    // Window-frame math is platform-specific (see the front ends); anchors
    // are taken once at drag start, never accumulated from mouse deltas.
    host_.resizeFromGrip(ImGui::IsItemActivated(), ImGui::IsItemActive(), kMinWidth, kMinHeight);

    const ImVec2 p = ImGui::GetItemRectMin();
    const ImVec2 sz = ImGui::GetItemRectSize();
    const ImU32 col = IM_COL32(0, 0, 0, ImGui::IsItemHovered() || ImGui::IsItemActive() ? 170 : 90);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddLine(ImVec2(p.x + 4, p.y + sz.y - 2), ImVec2(p.x + sz.x - 2, p.y + 4), col, 1.5f);
    dl->AddLine(ImVec2(p.x + 9, p.y + sz.y - 2), ImVec2(p.x + sz.x - 2, p.y + 9), col, 1.5f);
}

void OverlayScreen::drawMainUI() {
    pollAudioHealthAndRecover();

    const uint64_t qaVersion = _app->qaVersion();
    if (qaVersion != _cachedQAVersion) {
        std::vector<QAEntry> freshQA = _app->qaSnapshot();
        // Auto-select whichever entry is newly present that wasn't in the
        // previous snapshot -- covers a spoken/detected question and a
        // screenshot capture the same way, so the user always lands on
        // whatever question just came in instead of having to notice a
        // new tab appeared and click over to it themselves. An answer
        // arriving for an existing question, or a tab being closed,
        // changes the version too but never introduces an id that wasn't
        // already in _cachedQA, so neither triggers this.
        for (const auto& entry : freshQA) {
            const bool existedBefore =
                std::any_of(_cachedQA.begin(), _cachedQA.end(), [&](const QAEntry& old) { return old.id == entry.id; });
            if (!existedBefore && !_genInputActive) {
                _selectedTabId = entry.id;
            }
        }
        _cachedQA = std::move(freshQA);
        _cachedQAVersion = qaVersion;
    }
    const std::vector<QAEntry>& qaEntries = _cachedQA;

    // Tab bar, Chrome-style: permanent "script" (transcript) and "txt" (typed
    // questions) tabs plus one tab per active question, in the order they
    // were detected. Closing a tab that's currently selected falls back to
    // script.
    //
    // Shrinks every question tab's truncation length together as more
    // tabs are open, the same way a browser's tab strip narrows tabs
    // instead of scrolling -- otherwise a handful of questions overflow
    // this window's width and the later tabs become unreachable (this
    // window has no horizontal scroll of its own). Found by measuring
    // against the actual available width every frame rather than a fixed
    // char count, so it keeps working across window resizes too.
    {
        ImGui::SetCursorPosX(8.0f);  // small inset so the first tab isn't glued to the window edge
        constexpr size_t kMaxTabChars = 22;
        constexpr size_t kMinTabChars = 3;
        const float reserve = kTopRightControlsReserve + (_captureModeActive ? kTopRightControlsReserveCapturing : 0.0f);
        const float available = ImGui::GetContentRegionAvail().x - reserve;

        size_t maxChars = kMaxTabChars;
        for (; maxChars > kMinTabChars; --maxChars) {
            float total = TabWidthForLabel("script", false) + kTabSpacing + TabWidthForLabel("txt", false);
            for (const auto& qa : qaEntries) {
                std::string label = TruncateForTab(qa.question.empty() ? "Question" : qa.question, maxChars);
                total += kTabSpacing + TabWidthForLabel(label, true);
            }
            if (total <= available) break;
        }

        // Tab order, for the dividers: none next to the selected tab.
        std::vector<std::string> order{"transcript", "general"};
        for (const auto& qa : qaEntries) order.push_back(qa.id);
        auto dividerAfter = [&](size_t i) {
            return i + 1 < order.size() && order[i] != _selectedTabId && order[i + 1] != _selectedTabId;
        };

        // Baseline under the whole strip; the selected tab covers its span.
        {
            const ImVec2 start = ImGui::GetCursorScreenPos();
            const float y = start.y + kTabHeight + 0.5f;
            const float left = ImGui::GetWindowPos().x;
            ImGui::GetWindowDrawList()->AddLine(ImVec2(left, y), ImVec2(left + ImGui::GetWindowWidth(), y),
                                                IM_COL32(0, 0, 0, 120), 1.0f);
        }

        bool closeRequested = false;
        if (DrawTab("tab-transcript", "script", _selectedTabId == "transcript", /*closeable=*/false, nullptr,
                    dividerAfter(0))) {
            _selectedTabId = "transcript";
        }
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Transcript");
        }
        ImGui::SameLine(0, kTabSpacing);
        if (DrawTab("tab-general", "txt", _selectedTabId == "general", /*closeable=*/false, nullptr,
                    dividerAfter(1))) {
            if (_selectedTabId != "general") {
                _genFocusInput = true;
            }
            _selectedTabId = "general";
        }
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("General: type any question");
        }
        for (size_t qi = 0; qi < qaEntries.size(); ++qi) {
            const QAEntry& qa = qaEntries[qi];
            ImGui::SameLine(0, kTabSpacing);
            std::string label = TruncateForTab(qa.question, maxChars);
            if (label.empty()) {
                label = "Question";
            }
            const bool isSelected = (_selectedTabId == qa.id);
            if (DrawTab(qa.id.c_str(), label, isSelected, /*closeable=*/true, &closeRequested, dividerAfter(qi + 2))) {
                _selectedTabId = qa.id;
            }
            if (closeRequested) {
                _app->closeQuestion(qa.id);
                if (isSelected) {
                    _selectedTabId = "transcript";
                }
                closeRequested = false;
            }
        }
    }

    // Slim chrome: the Start row sits just under the tab strip's baseline.
    ImGui::SetCursorPosY(kTabHeight + 6.0f);

    const bool starting = _app->isStarting();
    const bool recording = _app->isRecording();
    if (starting) {
        ImGui::BeginDisabled(true);
        OutlineButton("Starting...", Pal::Muted, ImVec2(84, 20));
        ImGui::EndDisabled();
    } else if (!recording) {
        if (OutlineButton("Start", Pal::Green, ImVec2(56, 20))) {
            _app->requestStart();
        }
    } else {
        if (OutlineButton("Stop", Pal::Red, ImVec2(56, 20))) {
            _app->stopRecording();
        }
    }

    // takeStartError() clears as it reads, so only call it once per
    // frame and cache the result -- not every branch above runs every
    // frame, but this one line always should.
    const std::string startError = _app->takeStartError();
    if (!startError.empty()) {
        _lastError = startError;
    }
    const std::string startNotice = _app->takeStartNotice();
    if (!startNotice.empty()) {
        _lastNotice = startNotice;
    }

    ImGui::SameLine(0, 16);
    DrawSpeakerDot("Me", _app->meLevel(), IM_COL32(20, 102, 224, 255), /*useShadow=*/true);
    ImGui::SameLine(0, 12);
    DrawSpeakerDot("Them", _app->themLevel(), IM_COL32(24, 160, 80, 255), /*useShadow=*/true);

    if (!_lastError.empty()) {
        ImGui::Spacing();
        ShadowedTextWrapped(Pal::Red, ("Error: " + _lastError).c_str());
    }
    if (!_lastNotice.empty()) {
        ImGui::Spacing();
        ShadowedTextWrapped(Pal::Green, _lastNotice.c_str());
    }

    // Content-area rect (top-left origin, points -- the same screen-space
    // ImGui itself uses, i.e. exactly the MTKView's local coordinates) --
    // refreshed every frame regardless of capture mode, so
    // confirmScreenCapture always reads a fresh value and
    // chromeBlurView/contentBlurView stay in sync with wherever ImGui's
    // own layout actually put things (an error message above pushes this
    // down a line, for instance).
    {
        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const ImVec2 avail = ImGui::GetContentRegionAvail();
        _contentRectX = pos.x;
        _contentRectY = pos.y;
        _contentRectWidth = avail.x;
        _contentRectHeight = avail.y;

        // The Mac front end lays its blur views out to match; both use the
        // rect for the screenshot region.
        host_.contentRectChanged(_contentRectX, _contentRectY, _contentRectWidth, _contentRectHeight,
                                 _captureModeActive);
    }

    if (_captureModeActive) {
        // Left intentionally blank here -- no ImGui fill, no text,
        // contentBlurView hidden -- so it's genuinely see-through for
        // framing the capture (reframe by moving/resizing this window
        // itself), not just frosted. The outline is drawn 2px *outside*
        // the actual capture rect so the line itself never ends up in
        // the captured pixels.
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 p0(_contentRectX - 2.0f, _contentRectY - 2.0f);
        const ImVec2 p1(_contentRectX + _contentRectWidth + 2.0f, _contentRectY + _contentRectHeight + 2.0f);
        dl->AddRect(p0, p1, IM_COL32(20, 150, 75, 230), 4.0f, 0, 1.5f);
        return;
    }

    if (_selectedTabId == "transcript") {
        const uint64_t transcriptVersion = _app->transcriptVersion();
        if (transcriptVersion != _cachedTranscriptVersion) {
            _cachedTranscript = _app->transcriptSnapshot();
            _cachedTranscriptVersion = transcriptVersion;
        }
        // Only reserve bottom space for the "Saved to:" line when it's
        // actually going to render -- an unconditional fixed reserve left
        // a permanent gap under the Transcript tab even when there was
        // nothing to show there, both looking like an oversized bottom
        // margin and making this tab's content box a different size than
        // every other tab's (AnswerScroll below always fills the full
        // rect) and than the camera capture rect (which always uses the
        // full, un-reduced content rect) -- the exact size mismatch
        // reported between "the camera screen" and "the regular
        // transcript screen".
        const bool showSavedLine = !recording && !_app->lastSavedPath().empty();
        const float bottomReserve = showSavedLine ? 26.0f : 0.0f;
        ImGui::BeginChild("TranscriptScroll", ImVec2(0, -bottomReserve), true);
        for (const auto& seg : _cachedTranscript) {
            const ImVec4 tagColor =
                (seg.speaker == Speaker::Me) ? Pal::Blue : Pal::Green;
            ShadowedText(tagColor, speakerLabel(seg.speaker));
            ImGui::SameLine();
            ShadowedTextWrapped(Pal::Ink, seg.text.c_str());
        }
        if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5.0f) {
            ImGui::SetScrollHereY(1.0f);
        }
        ImGui::EndChild();

        if (showSavedLine) {
            ImGui::Spacing();
            ShadowedText(Pal::Green, ("Saved to: " + _app->lastSavedPath()).c_str());
        }
        return;
    }

    if (_selectedTabId == "general") {
        drawGeneralTab();
        return;
    }
    _genInputActive = false;

    // A question tab: find it fresh each frame (it may have just answered
    // or may vanish if closed from another code path).
    const QAEntry* selected = nullptr;
    for (const auto& qa : qaEntries) {
        if (qa.id == _selectedTabId) {
            selected = &qa;
            break;
        }
    }
    if (!selected) {
        _selectedTabId = "transcript";
        return;
    }

    ShadowedText(Pal::Ink, selected->question.c_str());
    ImGui::Spacing();

    // "Think Harder": re-asks this same question through a stronger
    // backend (Claude if configured, else a bigger local model) instead
    // of the fast default -- deliberately a different, stronger model
    // doing the retry rather than the same fast model re-checking its
    // own work, which tends to just repeat whatever mistake it made the
    // first time. Only shown once an answer (or failure) actually
    // exists -- doesn't make sense to double-check something that
    // hasn't been answered yet.
    if (!selected->pending) {
        if (selected->canThinkHarder) {
            ImGui::BeginDisabled(selected->rechecking || selected->streaming);
            if (OutlineButton(selected->rechecking ? "Thinking harder..." : "Think Harder",
                               Pal::Blue)) {
                _app->requestThinkHarder(selected->id);
            }
            ImGui::EndDisabled();
            ImGui::SameLine();
        }
        if (selected->streaming) {
            ShadowedText(Pal::Muted, "(answering...)");
        } else if (!selected->answeredBy.empty()) {
            const std::string label = "(answered by " + selected->answeredBy + ")";
            ShadowedText(Pal::Green, label.c_str());
        }
        ImGui::Spacing();
    }

    ImGui::Separator();
    ImGui::Spacing();

    ImGui::BeginChild("AnswerScroll", ImVec2(0, 0), true);
    if (selected->pending) {
        ShadowedText(Pal::Muted, "Thinking...");
    } else if (selected->rechecking) {
        ShadowedTextWrapped(Pal::Muted,
                             ("Previous answer: " + selected->answer).c_str());
    } else if (selected->failed) {
        ShadowedTextWrapped(Pal::Red, selected->answer.c_str());
    } else {
        DrawAnswerText(selected->answer);
    }
    ImGui::EndChild();
}

// The "txt" tab: every typed question so far with its answer, oldest first,
// and an input box pinned to the bottom. Enter (or Ask) sends the question.
void OverlayScreen::drawGeneralTab() {
    const uint64_t version = _app->generalVersion();
    bool changed = false;
    if (version != _cachedGeneralVersion) {
        _cachedGeneral = _app->generalSnapshot();
        _cachedGeneralVersion = version;
        changed = true;
    }

    const ImGuiStyle& style = ImGui::GetStyle();
    const float inputRowHeight = ImGui::GetFrameHeight() + style.ItemSpacing.y + 2.0f;
    ImGui::BeginChild("GeneralScroll", ImVec2(0, -inputRowHeight), true);
    const bool wasAtBottom = ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5.0f;
    if (_cachedGeneral.empty()) {
        ShadowedTextWrapped(Pal::Muted,
                             "Type any question below and press Enter. It's answered on its own, "
                             "without the lecture transcript.");
    }
    for (size_t i = 0; i < _cachedGeneral.size(); ++i) {
        const QAEntry& qa = _cachedGeneral[i];
        ImGui::PushID(qa.id.c_str());
        if (i > 0) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
        }
        ShadowedTextWrapped(Pal::Blue, qa.question.c_str());
        ImGui::Spacing();
        if (qa.pending) {
            ShadowedText(Pal::Muted, "Thinking...");
        } else if (qa.failed) {
            ShadowedTextWrapped(Pal::Red, qa.answer.c_str());
        } else {
            DrawAnswerText(qa.answer);
            if (qa.streaming) {
                ShadowedText(Pal::Muted, "(answering...)");
            } else if (!qa.answeredBy.empty()) {
                ShadowedText(Pal::Green, ("(answered by " + qa.answeredBy + ")").c_str());
            }
        }
        ImGui::PopID();
    }
    if (changed && (wasAtBottom || _genScrollToNewest)) {
        ImGui::SetScrollHereY(1.0f);
        _genScrollToNewest = false;
    }
    ImGui::EndChild();

    const float askWidth = 44.0f;
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - askWidth - style.ItemSpacing.x);
    if (_genFocusInput) {
        ImGui::SetKeyboardFocusHere();
        _genFocusInput = false;
    }
    const bool entered = ImGui::InputTextWithHint("##gen_input", "Ask anything...", _genInput, sizeof(_genInput),
                                                  ImGuiInputTextFlags_EnterReturnsTrue);
    _genInputActive = ImGui::IsItemActive();
    if (ImGui::IsItemActivated()) {
        host_.takeKeyboardFocus();
    }
    ImGui::SameLine();
    const bool askClicked = OutlineButton("Ask", Pal::Blue, ImVec2(askWidth, 0));
    if (entered || askClicked) {
        std::string question(_genInput);
        const size_t first = question.find_first_not_of(" \t\r\n");
        const size_t last = question.find_last_not_of(" \t\r\n");
        if (first != std::string::npos) {
            _app->askGeneral(question.substr(first, last - first + 1));
            _genInput[0] = '\0';
            // A new question always scrolls into view, even if the user had
            // scrolled up to reread something.
            _genScrollToNewest = true;
        }
        _genFocusInput = true;  // keep typing without clicking back in
    }
}

// Overlaid drawer for managing uploaded resume/reference documents:
// list + per-document delete, an "+ Add" row to upload more, and a scan
// button + status line making explicit that a document contributes
// nothing to answers until it's been scanned (see DocumentScanStatus).
// Drawn last in drawInMTKView so it's both visually and interactively on
// top of the tab bar/transcript beneath it.
void OverlayScreen::drawDocumentsPanel() {
    const uint64_t docVersion = _app->documentVersion();
    if (docVersion != _cachedDocVersion) {
        _cachedDocuments = _app->documentSnapshot();
        _cachedDocVersion = docVersion;
    }
    const std::vector<UploadedDocument>& docs = _cachedDocuments;

    ImGuiIO& io = ImGui::GetIO();
    constexpr float kPanelTop = 32.0f;
    constexpr float kPanelMargin = 8.0f;
    const float panelWidth = std::min(240.0f, io.DisplaySize.x - kPanelMargin * 2.0f);
    const float panelHeight = io.DisplaySize.y - kPanelTop - kPanelMargin;
    const ImVec2 panelPos(io.DisplaySize.x - panelWidth - kPanelMargin, kPanelTop);

    ImGui::SetNextWindowPos(panelPos);
    ImGui::SetNextWindowSize(ImVec2(panelWidth, panelHeight));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.985f, 0.985f, 0.99f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.0f, 0.0f, 0.0f, 0.18f));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 10.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
    ImGui::BeginChild("##documents_panel", ImVec2(panelWidth, panelHeight), true,
                       ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

    // Header: title + an explicit close control (in addition to toggling
    // the "+" again) since a floating drawer over the rest of the UI
    // should never leave the user unsure how to dismiss it.
    ShadowedText(Pal::Ink, "Documents");
    ImGui::SameLine(ImGui::GetWindowWidth() - 28.0f);
    if (CornerIconButton("##close_docs", 20.0f, CornerIcon::Close, IM_COL32(40, 43, 50, 255), /*active=*/false,
                         /*dangerHover=*/true)) {
        _showDocumentsPanel = false;
    }

    ImGui::Spacing();
    ShadowedTextWrapped(Pal::Muted,
                         "Uploaded documents (e.g. a resume) help answer personal/behavioral "
                         "questions. Nothing is used until you scan below.");
    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // Document list -- its own scrollable region so a long list doesn't
    // push the Add/Scan controls below off the bottom of the panel.
    const float listHeight = ImGui::GetContentRegionAvail().y - 92.0f;
    ImGui::BeginChild("##documents_list", ImVec2(0, std::max(listHeight, 40.0f)), false);
    if (docs.empty()) {
        ShadowedTextWrapped(Pal::Muted, "No documents yet.");
    } else {
        for (const auto& doc : docs) {
            ImGui::PushID(doc.id.c_str());
            ShadowedText(Pal::Ink, TruncateForTab(doc.filename, 24).c_str());
            ImGui::SameLine(ImGui::GetWindowWidth() - 28.0f);
            if (CornerIconButton("##remove_doc", 20.0f, CornerIcon::Close, IM_COL32(40, 43, 50, 255),
                                 /*active=*/false, /*dangerHover=*/true)) {
                _app->removeDocument(doc.id);
            }
            ImGui::PopID();
        }
    }
    ImGui::EndChild();

    ImGui::Spacing();
    if (OutlineButton("+ Add Document", Pal::Green, ImVec2(-1, 24))) {
        host_.presentDocumentUploadPanel();
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    const DocumentScanStatus status = _app->documentScanStatus();
    const bool busy = (status == DocumentScanStatus::Scanning || status == DocumentScanStatus::Processing);
    const bool canScan = !docs.empty() && !busy;

    if (!canScan) ImGui::BeginDisabled(true);
    if (OutlineButton("Scan Documents", Pal::Blue, ImVec2(-1, 24))) {
        _app->requestDocumentScan();
    }
    if (!canScan) ImGui::EndDisabled();

    ImGui::Spacing();
    const char* statusText = "Not scanned";
    ImVec4 statusColor(0.62f, 0.64f, 0.69f, 0.95f);
    switch (status) {
        case DocumentScanStatus::NotScanned:
            statusText = "Not scanned";
            break;
        case DocumentScanStatus::Scanning:
            statusText = "Scanning...";
            statusColor = Pal::Amber;
            break;
        case DocumentScanStatus::Processing:
            statusText = "Processing...";
            statusColor = Pal::Amber;
            break;
        case DocumentScanStatus::Ready:
            statusText = "Scanned - Ready";
            statusColor = Pal::Green;
            break;
        case DocumentScanStatus::Failed:
            statusText = "Scan failed";
            statusColor = Pal::Red;
            break;
    }
    ShadowedText(statusColor, statusText);
    if (status == DocumentScanStatus::Failed) {
        const std::string err = _app->documentScanError();
        if (!err.empty()) {
            ShadowedTextWrapped(Pal::Red, err.c_str());
        }
    }

    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
}
