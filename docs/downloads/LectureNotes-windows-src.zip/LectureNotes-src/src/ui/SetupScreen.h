#pragma once

// The first-run Setup checklist's ImGui UI, shared by the macOS and Windows
// front ends. The front end owns the window and frame loop and calls draw()
// between ImGui::NewFrame() and ImGui::Render().

class SetupScreen {
public:
    SetupScreen();

    // Draws the full-window checklist. Returns true on the frame the user
    // clicks Launch with everything satisfied.
    bool draw();

private:
    void drawChecklist(bool micOK, bool bhOK, bool modelOK, bool screenOK, bool ollamaOK, bool allOK);

    // Set when "Set up Claude" is clicked; drives fast polling until the
    // sign-in completes. Seconds on a steady clock.
    double _claudeSetupStartedAt = 0;
    double _lastClaudePoll = 0;
    // Scratch buffer for the optional Claude API key field -- zeroed right
    // after a save so the key doesn't linger in memory as plain text.
    char _claudeKeyInputBuffer[256];
};
