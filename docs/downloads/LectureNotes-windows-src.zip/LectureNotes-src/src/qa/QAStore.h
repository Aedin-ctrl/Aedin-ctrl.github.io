#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <vector>

// One detected question and (once it comes back) its Claude-generated
// answer. `id` is stable for the lifetime of the entry, used by the UI to
// know which tab is which across frames and by ClaudeClient's background
// thread to know which entry to update when it finishes.
struct QAEntry {
    std::string id;
    std::string question;
    std::string answer;
    bool pending = true;
    bool failed = false;

    // "Think harder" re-answer support: retries a question through a
    // stronger backend (Claude, if the user configured a key, else a
    // larger local model) instead of the default fast/local one --
    // deliberately a *different* model doing the retry, not the same one
    // re-checking its own work, since a model re-verifying its own answer
    // tends to just repeat the same mistake.
    bool rechecking = false;         // a think-harder retry is in flight
    bool answeredWithThinkHarder = false;  // current answer came from the retry, not the fast pass

    // Which backend produced the current answer, shown under it (e.g.
    // "Claude Opus", "local model"). Empty while pending.
    std::string answeredBy;

    // What was said just before the question (same speaker), sent to the
    // model alongside it but kept out of the tab label. Questions often
    // lean on the previous sentence ("...what's the charge on each?").
    std::string context;

    // Answer text is arriving incrementally (streamed from Claude); the
    // final updateAnswer() clears it.
    bool streaming = false;

    // Only spoken/typed questions can be re-asked by Think Harder: a
    // screenshot tab doesn't keep its image, and a notes tab's "question" is
    // just its label, so re-asking either would send Claude nonsense.
    bool canThinkHarder = true;
};

// Mutex-guarded list of in-flight/answered questions, one per detected
// question (from either speaker). Backs the browser-tab-style Q&A UI:
// each tab is one entry here.
class QAStore {
public:
    // Adds a new pending entry and returns its id.
    std::string addPending(const std::string& question, const std::string& context = "",
                           bool canThinkHarder = true);

    // No-ops if `id` is no longer present -- e.g. the user closed that
    // tab before the answer came back. Safe to call from any thread.
    void updateAnswer(const std::string& id, const std::string& answer, bool failed,
                       bool viaThinkHarder = false, const std::string& answeredBy = "");

    // Marks an already-answered entry as being re-asked through the
    // stronger backend -- keeps the old answer visible (so the UI can
    // still show it) while a "Thinking harder..." state renders. No-op if
    // `id` isn't present.
    void beginRecheck(const std::string& id);

    // Replaces the answer text-so-far while it streams in. Leaves the entry
    // non-pending so the text shows, but marked `streaming` until
    // updateAnswer() delivers the final result.
    void updatePartial(const std::string& id, const std::string& textSoFar);

    void close(const std::string& id);

    std::vector<QAEntry> snapshot() const;

    // Bumped on every addPending()/updateAnswer()/close() -- see
    // TranscriptStore::version() for why: lets the UI skip re-copying
    // the whole entry list on frames where nothing changed.
    uint64_t version() const { return version_.load(std::memory_order_acquire); }

private:
    mutable std::mutex mutex_;
    std::vector<QAEntry> entries_;
    uint64_t nextId_ = 1;
    std::atomic<uint64_t> version_{0};
};
