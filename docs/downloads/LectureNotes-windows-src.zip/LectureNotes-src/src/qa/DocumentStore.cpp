#include "DocumentStore.h"

#include <algorithm>

namespace {
// ~4000 chars is roughly 1000 tokens -- leaves room for the summarization
// step's own system prompt plus its output within a 2048-token context
// without raising num_ctx (see DocumentStore.h for why not).
constexpr size_t kMaxContextChars = 4000;
}  // namespace

std::string DocumentStore::add(std::string filename, std::string text) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string id = std::to_string(nextId_++);
    documents_.push_back(UploadedDocument{id, std::move(filename), std::move(text)});
    version_.fetch_add(1, std::memory_order_release);
    return id;
}

void DocumentStore::remove(const std::string& id) {
    std::lock_guard<std::mutex> lock(mutex_);
    documents_.erase(std::remove_if(documents_.begin(), documents_.end(),
                                     [&](const UploadedDocument& d) { return d.id == id; }),
                      documents_.end());
    version_.fetch_add(1, std::memory_order_release);
}

void DocumentStore::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    documents_.clear();
    version_.fetch_add(1, std::memory_order_release);
}

std::vector<UploadedDocument> DocumentStore::snapshot() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return documents_;
}

std::string DocumentStore::combinedContext() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string combined;
    for (const auto& doc : documents_) {
        if (combined.size() >= kMaxContextChars) break;
        if (!combined.empty()) combined += "\n\n";
        combined += "[" + doc.filename + "]\n" + doc.text;
    }
    if (combined.size() > kMaxContextChars) {
        combined.resize(kMaxContextChars);
        combined += "...";
    }
    return combined;
}
