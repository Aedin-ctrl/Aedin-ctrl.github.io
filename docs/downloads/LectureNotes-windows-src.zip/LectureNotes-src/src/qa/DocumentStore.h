#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

struct UploadedDocument {
    std::string id;
    std::string filename;
    std::string text;
};

// Where an uploaded document set stands relative to the local LLM actually
// using it. Deliberately a manual, visible step (not automatic on upload)
// -- see App::requestDocumentScan -- so what's grounding the model's
// answers is never a surprise: a document sits in the "Not scanned" state,
// contributing nothing, until the user explicitly asks for it to be read.
enum class DocumentScanStatus {
    NotScanned,
    Scanning,
    Processing,
    Ready,
    Failed,
};

// Holds resume/reference documents the user has uploaded. Mutex-guarded
// like QAStore/TranscriptStore; in practice this holds at most a handful
// of documents (a resume, maybe a cover letter or job posting), so no
// attempt at incremental diffing.
class DocumentStore {
public:
    // Returns the new entry's id, used by the UI to key its per-document
    // delete button.
    std::string add(std::string filename, std::string text);
    void remove(const std::string& id);
    void clear();

    std::vector<UploadedDocument> snapshot() const;

    // Concatenation of all uploaded documents' text -- the *input* to
    // App::requestDocumentScan's summarization step, not what's handed to
    // the model directly (see LocalLLMClient::summarizeDocuments). Capped
    // well under the local model's ~2048-token default context window
    // (see LocalLLMClient.cpp) -- this app deliberately doesn't raise
    // num_ctx to make more room, since that trades away the memory
    // headroom that was the whole reason llama3.2:3b was chosen over a
    // bigger model (see LocalLLMClient.h). Truncates from the end (keeps
    // earlier-uploaded documents intact) if over the cap.
    std::string combinedContext() const;

    uint64_t version() const { return version_.load(std::memory_order_acquire); }

private:
    mutable std::mutex mutex_;
    std::vector<UploadedDocument> documents_;
    size_t nextId_ = 1;
    std::atomic<uint64_t> version_{0};
};
