#include "QAStore.h"

#include <algorithm>

std::string QAStore::addPending(const std::string& question, const std::string& context, bool canThinkHarder) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string id = std::to_string(nextId_++);
    QAEntry entry;
    entry.id = id;
    entry.question = question;
    entry.context = context;
    entry.canThinkHarder = canThinkHarder;
    entry.pending = true;
    entries_.push_back(std::move(entry));
    version_.fetch_add(1, std::memory_order_release);
    return id;
}

void QAStore::updateAnswer(const std::string& id, const std::string& answer, bool failed,
                            bool viaThinkHarder, const std::string& answeredBy) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& entry : entries_) {
        if (entry.id == id) {
            entry.answer = answer;
            entry.pending = false;
            entry.failed = failed;
            entry.rechecking = false;
            entry.answeredWithThinkHarder = viaThinkHarder;
            entry.answeredBy = answeredBy;
            entry.streaming = false;
            version_.fetch_add(1, std::memory_order_release);
            return;
        }
    }
    // Tab was closed before the answer arrived -- nothing to update.
}

void QAStore::beginRecheck(const std::string& id) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& entry : entries_) {
        if (entry.id == id) {
            entry.rechecking = true;
            version_.fetch_add(1, std::memory_order_release);
            return;
        }
    }
}

void QAStore::updatePartial(const std::string& id, const std::string& textSoFar) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& entry : entries_) {
        if (entry.id == id) {
            entry.answer = textSoFar;
            entry.pending = false;
            entry.streaming = true;
            version_.fetch_add(1, std::memory_order_release);
            return;
        }
    }
}

void QAStore::close(const std::string& id) {
    std::lock_guard<std::mutex> lock(mutex_);
    entries_.erase(std::remove_if(entries_.begin(), entries_.end(),
                                   [&](const QAEntry& e) { return e.id == id; }),
                   entries_.end());
    version_.fetch_add(1, std::memory_order_release);
}

std::vector<QAEntry> QAStore::snapshot() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return entries_;
}
