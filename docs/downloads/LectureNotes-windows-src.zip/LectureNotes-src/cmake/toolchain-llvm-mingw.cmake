# Cross-compiles the Windows build on macOS with llvm-mingw
# (https://github.com/mstorsjo/llvm-mingw). Pass:
#   -DLLVM_MINGW_ROOT=<toolchain dir> -DLN_WIN_ARCH=x86_64|aarch64
set(CMAKE_SYSTEM_NAME Windows)
if(NOT LN_WIN_ARCH)
    set(LN_WIN_ARCH x86_64)
endif()
set(CMAKE_SYSTEM_PROCESSOR ${LN_WIN_ARCH})
set(_triple ${LN_WIN_ARCH}-w64-mingw32)

set(CMAKE_C_COMPILER   ${LLVM_MINGW_ROOT}/bin/${_triple}-clang)
set(CMAKE_CXX_COMPILER ${LLVM_MINGW_ROOT}/bin/${_triple}-clang++)
set(CMAKE_RC_COMPILER  ${LLVM_MINGW_ROOT}/bin/${_triple}-windres)
set(CMAKE_AR           ${LLVM_MINGW_ROOT}/bin/llvm-ar)
set(CMAKE_RANLIB       ${LLVM_MINGW_ROOT}/bin/llvm-ranlib)

set(CMAKE_FIND_ROOT_PATH ${LLVM_MINGW_ROOT}/${_triple})
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
