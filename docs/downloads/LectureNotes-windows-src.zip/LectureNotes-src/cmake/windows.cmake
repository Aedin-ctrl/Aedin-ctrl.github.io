# Windows target: included from the root CMakeLists.txt after the shared
# dependencies (whisper.cpp, Dear ImGui, nlohmann/json) are fetched.

add_library(imgui STATIC
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_demo.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_win32.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_dx11.cpp
)
target_include_directories(imgui PUBLIC
    ${imgui_SOURCE_DIR}
    ${imgui_SOURCE_DIR}/backends
)
target_compile_definitions(imgui PUBLIC UNICODE _UNICODE)

add_executable(lecturenotes WIN32
    src/main.cpp
    src/app/App.cpp
    src/audio/AudioCaptureWin.cpp
    src/audio/OutputRouterWin.cpp
    src/audio/Resampler.cpp
    src/asr/QuestionDetector.cpp
    src/asr/TranscriptStore.cpp
    src/asr/WhisperWorker.cpp
    src/capture/ScreenCaptureWin.cpp
    src/qa/DocumentStore.cpp
    src/qa/QAStore.cpp
    src/setup/ClaudeKeyStoreWin.cpp
    src/setup/SetupCheckerWin.cpp
    src/storage/SessionWriter.cpp
    src/summarize/ClaudeClient.cpp
    src/summarize/ClaudeCodeClient.cpp
    src/summarize/LocalLLMClient.cpp
    src/summarize/OllamaClient.cpp
    src/summarize/VisionLLMClient.cpp
    src/ui/AnswerText.cpp
    src/ui/Widgets.cpp
    src/ui/OverlayScreen.cpp
    src/ui/SetupScreen.cpp
    src/ui/WinApp.cpp
    src/net/HttpWin.cpp
    src/platform/win/WinUtil.cpp
    resources/windows/LectureNotes.rc
)

target_include_directories(lecturenotes PRIVATE src)
target_compile_definitions(lecturenotes PRIVATE UNICODE _UNICODE NOMINMAX _WIN32_WINNT=0x0A00 WINVER=0x0A00)

target_link_libraries(lecturenotes PRIVATE
    whisper
    imgui
    nlohmann_json::nlohmann_json
    d3d11 dxgi dcomp dwmapi d3dcompiler_47
    ole32 oleaut32 uuid shell32 user32 gdi32 imm32 advapi32
    winhttp windowscodecs
)

# One self-contained exe: the C++ runtime and unwinder linked in statically,
# so nothing extra has to be installed on a classmate's PC.
target_link_options(lecturenotes PRIVATE -static)
set_target_properties(lecturenotes PROPERTIES OUTPUT_NAME "LectureNotes")
