#!/bin/bash
# Codesigns the given .app bundle with the pinned "Apple Development"
# certificate, with the hardened runtime enabled.
#
# Why a fixed certificate: macOS ties each Mic / Screen Recording grant to
# the app's signing identity. A build signed differently (a different or
# renewed certificate, or ad-hoc) looks like a new app, so every user who
# installs it gets asked for every permission again. Picking "whichever
# Apple Development identity is listed first", with a silent ad-hoc
# fallback, could ship that by accident, so a missing pinned identity now
# fails the build instead.
#
# Why the hardened runtime: without it, other software on the Mac could
# inject code into LectureNotes (e.g. DYLD_INSERT_LIBRARIES) and record the
# mic and screen under its permissions. The signing identity, and so every
# existing permission, is unchanged by turning it on.
#
# Overrides:
#   LN_SIGN_IDENTITY=<sha1 or name>  sign with a different identity
#   LN_ALLOW_ADHOC=1                  local experiments only: ad-hoc signing
set -e
BUNDLE="$1"
HERE="$(cd "$(dirname "$0")" && pwd)"
ENTITLEMENTS="$HERE/LectureNotes.entitlements"

# "Apple Development: aedinlai@gmail.com (Z84TTJ356V)", Team N2XQ4P7AN5,
# expires 2027-07-11. When it's renewed, update this and expect every user
# to be asked for permissions once more.
PINNED_IDENTITY="815E10F6BBF01ECC72B27A0C4D11704C85FA2D08"
IDENTITY="${LN_SIGN_IDENTITY:-$PINNED_IDENTITY}"

xattr -cr "$BUNDLE"

if [ "${LN_ALLOW_ADHOC:-0}" = "1" ]; then
    codesign --force --deep --sign - "$BUNDLE"
    echo "WARNING: ad-hoc signed (LN_ALLOW_ADHOC=1). Never distribute this build."
    exit 0
fi

if ! security find-identity -v -p codesigning | grep -q "$IDENTITY"; then
    echo "error: signing identity $IDENTITY is not in this keychain." >&2
    echo "       Distributing a build signed any other way re-asks every user for permissions." >&2
    echo "       Set LN_SIGN_IDENTITY to the right certificate, or LN_ALLOW_ADHOC=1 for a throwaway local build." >&2
    exit 1
fi

sign() {
    codesign --force --deep --options runtime --entitlements "$ENTITLEMENTS" "$@" --sign "$IDENTITY" "$BUNDLE"
}
# A secure timestamp keeps the signature valid to check even after the
# certificate expires; it needs Apple's timestamp server, so sign without
# one when offline rather than failing the build.
if ! sign --timestamp 2>/dev/null; then
    echo "note: timestamp server unreachable; signing without a secure timestamp."
    sign
fi
echo "Codesigned lecturenotes.app with: $(security find-identity -v -p codesigning | grep "$IDENTITY" | sed -E 's/.*"(.*)"/\1/') (hardened runtime)"
