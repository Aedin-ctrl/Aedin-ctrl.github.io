# Reviews

Two rounds of independent review shaped this project. Kept because the
reasoning is worth more than the conclusions — several decisions here look
arbitrary without it.

- **`council-01-the-plan.md`** — reviewed the plan before any code existed.
  Killed a two-tier MediaPipe + RTMW stack, an orientation *estimator* that
  would have latched onto wrong answers, and a "one schema across models"
  promise that could not have been kept.
- **Round two** reviewed the shipped code. Its findings are recorded where they
  belong rather than as a transcript: the bugs in `CHANGELOG.md`, the licence
  and accuracy ceiling in `docs/commercial-use.md`, and the failed attempts at
  wrong-pose detection in `docs/can-we-detect-a-wrong-pose.md`.

Both rounds were same-model panels playing different roles, so agreement
between members is a shared prior, not corroboration. They were useful for
coverage, not for consensus.
