<!-- Moved here from the site repo, where it did not belong. This is the first
     of two reviews: it reviewed the PLAN, before any code existed. The second
     reviewed the shipped code and its findings are in CHANGELOG.md and
     docs/commercial-use.md. -->

# Local Council — full-body pose tracking library

**Local council** — these perspectives all come from Claude playing different roles,
not from different AI vendors. Treat agreement as a shared starting point to
pressure-test, not as independent confirmation.

Plan reviewed: posekit-plan.md (two-tier MediaPipe + RTMW browser pose library for
non-upright physical-therapy poses, with orientation-normalization layer, debug
harness, download button, Links-tab placement).

Members: Devil's Advocate, Simplicity Champion, Security Auditor,
Scalability Architect, Maintainability Advocate.

---

## Devil's Advocate

**Position:** Both questions are premature. The licensing workaround (don't bundle,
hotlink upstream) is self-defeating for Tier B because no upstream RTMW ONNX artifact
exists — converting one makes YOU the publisher of the derived weight. Cut Tier B,
the plugin interface, the stable schema, the zip.

Key claims:
- MMPose publishes PyTorch checkpoints, not ONNX, and almost certainly without CORS
  headers. A browser fetch of "the upstream default URL" fails before licensing is
  even reached. To ship RTMW you must export, quantize and host your own .onnx —
  i.e. distribute a derivative of COCO-WholeBody-trained weights.
- "Configurable URL, default upstream" hands the copying act to the downstream
  integrator while making it look sanctioned. A trap set for the developer the
  library is meant to serve.
- The missed option is MediaPipe's own task family: Pose + Hand + Face = 33 + 21x2
  + 478 points, one vendor, one license, no COCO-WholeBody. The licensing poison is
  specifically the *WholeBody* extension; plain COCO keypoints are CC-BY-4.0.
- The orientation layer re-implements what BlazePose already does, from outside,
  with less information. The Tasks API does not expose the ROI, so an external
  rotation is a no-op at best, a double rotation at worst.
- Rotate-upright assumes rotation is the whole domain gap. It isn't: foreshortening,
  mat/floor context, self-occlusion, invisible face when prone are all out of
  distribution and rotation fixes none of them.
- "Stable schema" manufactures false portability: a COCO wrist and a GHUM wrist are
  different anatomical definitions. Swap tiers and the joint angles change silently.
- ONNX Runtime Web multithreaded wasm needs SharedArrayBuffer -> COOP/COEP ->
  breaks third-party embeds. Never mentioned in the plan.
- The download button promises something false: a zip of a library whose weights are
  deliberately not bundled does not run offline.

---

## Simplicity Champion

**Position:** This builds a two-tier, pluggable, schema-abstracted framework to solve
a problem nobody has confirmed exists. Cut Tier B, the plugin interface and the
cross-model schema; ship one ES module plus one HTML page.

Key claims:
- Tier B is unverified three ways at once: no browser latency figure from any source,
  no evidence int8 RTMW stays accurate or fits (only existing port is 370MB), and a
  documented non-commercial restriction plus two unanswered MMPose issues.
- The licensing risk IS decisive, but decisive the easy way: delete Tier B and the
  entire licensing section disappears with it.
- "Pluggable backend + stable schema" is abstraction for exactly one implementation,
  and the promise is unkeepable: 33 and 133 keypoints are not swappable behind one
  interface.
- The orientation layer's geometry is fine; its ESTIMATOR will fail. Bbox aspect
  ratio is 180-degree ambiguous by construction. Replace with brute force: run
  0/90/180/270, keep highest mean landmark confidence, cache the winner, re-search
  when confidence drops. Subsumes the 180 TTA merge for free.
- The pipeline assumes step 1 succeeds, and step 1 is what the cited evidence says
  breaks — detection dropping out entirely on inverted subjects. You cannot rotate a
  crop you failed to find.
- Cheapest fix isn't in the plan at all: MOVE THE CAMERA. An overhead camera turns a
  person on a mat into an upright person in frame. Zero code, zero inference cost.
  A page of camera-placement guidance may be the highest-value deliverable.
- No acceptance criterion anywhere. No target FPS, no target PCK. That absence is
  what lets a 92M-param quality tier look justified.
- Internal tension: "highest quality available" and "make no clinical claims" are in
  conflict, and the second one wins. Nobody needs 70.2 vs 67.2 mAP for a product
  forbidden from acting on the difference.
- Labeling every point simultaneously is unreadable — 11 of MediaPipe's 33 landmarks
  are in the head cluster. Use hover-to-label plus a side table.

---

## Security Auditor

**Position:** The two genuinely dangerous decisions are (a) fetching weights at
runtime from a configurable unpinned third-party URL — remote code loading into a
WASM/WebGPU parser dressed as a licensing workaround — and (b) a download button and
PT framing that turn pose output into retained biometric/health data in deployments
the author will never see.

Key claims:
- The author ALREADY self-hosts MediaPipe weights in three live projects
  (hand_landmarker.task 7.5M, face_landmarker.task 3.6M, gesture_recognizer.task
  8.0M) and docs/licenses.txt carries no MediaPipe notice. The redistribution
  exposure the plan tries to dodge is already live on the site.
- An .onnx is a protobuf graph, a .task is a zip of TFLite flatbuffers; both are
  parsed by C++ compiled to WASM, and with WebGPU the model drives shader generation.
  "Fetch bytes from an integrator-controlled URL and hand them to ORT" is an
  arbitrary-model-load primitive. If runtime fetch stays, hash with SHA-256 against a
  pinned digest BEFORE the bytes reach the runtime. `integrity=` does not apply to
  `fetch()`.
- Every runtime weight fetch is a third-party beacon at the start of every patient
  session: leaks IP, UA, Referer (which can carry the clinic's URL) and timing. In a
  HIPAA setting that's a disclosure with no BAA; under GDPR a third-country transfer.
- The strong privacy property — video never leaves the device — is never stated as a
  contract or enforced. Make it an invariant: zero network I/O after weight load, no
  telemetry, no persistence; ship a CSP meta on the harness so it's checkable.
- GitHub Pages cannot set response headers, so no COOP/COEP, so ORT Web's
  multithreaded WASM path is unavailable on the author's own host.
- Cut the download button. Joint-trajectory and gait kinematics are re-identifying =
  biometric data under GDPR Art. 9, and PHI the moment anyone adds a session label.
- Hosting the camera harness on www.aedinlai.com is an origin mistake: camera
  permission is per-origin and persists, so granting it to the pose demo grants it to
  /us/, /devices/, /secret/, /arb. Use a separate subdomain.
- Regulatory classification is set by the README, not the code. Avoid identifiers
  like `rom`, `assessment`, `normalRange`, `deviation`.
- The 180 TTA merge has a SAFETY failure mode: silently swapped laterality — "left
  knee" drawn on the right leg — is a wrong-side error in a rehab context. Refuse to
  emit rather than average when branches disagree on handedness.
- Gate RTMW behind an explicit `acknowledgeNonCommercial: true` with a console
  warning naming the dataset. Ship a machine-readable provenance manifest per model.

---

## Scalability Architect

**Position:** The plan is upside-down: it spends the entire per-frame compute budget
and the entire first-load bandwidth budget on a tier that cannot hold real-time
framerates, cannot be hosted from the site it is listed on, and carries a defect that
cannot be patched once propagated. Split by latency class, not by "quality".

Key claims:
- The frame budget does not close. Detect -> orient -> crop -> pose -> unrotate is
  serial, so latency is the SUM. At 30fps you have 33ms. The only measured browser
  datapoint is 200ms/frame on WASM threads. Tier B realtime is ~5-15fps on good
  hardware, ~1-5fps on WASM fallback.
- 180 TTA is triggered BY LOW CONFIDENCE, which is exactly what non-upright poses
  produce. The cost spike correlates with the hard frames: framerate goes bimodal and
  jitters hardest in the supine cases the library exists for.
- There are four operating points, not two: WebGPU+discrete, WebGPU+integrated,
  WASM-SIMD-threads, WASM-single-threaded. The last is ~600ms-1s/frame and is the
  default for anyone who can't change server headers.
- Missing and worth more than the orientation layer: Worker + OffscreenCanvas,
  a drop-to-latest-frame policy, decoupled inference-rate vs render-rate.
- GitHub Pages hard-blocks files >100MB and soft-caps bandwidth ~100GB/month = ~1000
  first-loads of a 100MB model. Use Hugging Face Hub resolve/<revision>/ URLs:
  built for weights, CORS-enabled, revision-pinned, and the model card forces the
  license question into the open.
- MediaPipe Tasks stack (pose ~9MB + hand ~8MB x2 + face ~4MB ~= 25MB) gives MORE
  points than RTMW's 133 (33 + 42 + 478), one vendor, quarter the bytes.
- Rotation costs the resolution the 133-keypoint promise depends on: arbitrary-angle
  rotation of a tight bbox needs up to sqrt(2) expansion, so the subject occupies up
  to ~2x fewer pixels, resampled twice. Face and hand keypoints are the smallest
  features in frame.
- The orientation prior closes a feedback loop with no hysteresis: a left/right swap
  flips the estimate, which rotates the next crop 180, which makes the flip
  self-consistent. It latches into the wrong basin and stays.
- Harness memory: 133kp x (x,y,score) x 30fps as JS objects is ~10x 3KB/frame live;
  a 10-minute session is hundreds of MB to ~1GB in-tab, and the download button
  JSON.stringifies it in one shot. Needs a columnar Float32Array ring buffer.
- Capability detection must be MEASURED, not declared. requestAdapterInfo() is
  redacted; "WebGPU present" says nothing about throughput.

---

## Maintainability Advocate

**Position:** The plan commits a single unpaid maintainer, on behalf of an unnamed
downstream team, to two runtimes, two licenses, an unkeepable schema promise and an
unvalidated research hypothesis, with no automated tests and no named successor.

Key claims:
- The stable-schema promise is the one mistake that is unfixable after publication.
  Confidence numbers aren't the same quantity across backends, so a consumer
  thresholding at 0.5 gets different behavior per backend.
  Fix: declared optional PARTS (body/feet/hands/face) with provenance on every
  result and explicit absence rather than nulls. Promise "you get a declared subset
  you can check", not "nothing changes".
- The orientation layer is aimed at a different failure than the evidence cited for
  it. Bench press 73.6% and OpenPose occlusion failures are about foreshortening,
  self-occlusion and OUT-OF-PLANE rotation. An IN-PLANE rotate-crop-unrotate fixes
  none of those.
- MediaPipe's world landmarks come out in a frame tied to a gravity assumption;
  feeding a rotated crop means the world coordinates need a correction Google does
  not document.
- A URL has no lockfile. When Google renames a .task path, the library breaks at the
  consumer's runtime, in front of users, with no code change to bisect — after
  handoff. Minimum: pinned versioned URLs + published SHA-256 + loud specific error.
- THERE ARE NO TESTS, and a debug harness is not a substitute. Rotation round-trip,
  keypoint mapping tables, angle computation, smoothing, coordinate conversions are
  deterministic and are ~60% of the code. For the fuzzy part: 20-40 committed JPEGs
  covering supine/prone/side-lying/quadruped with committed expected keypoints and CI
  asserting mean PCK above a threshold. Without that nobody can ever bump a model
  version, so nobody will, and the library freezes on whatever shipped.
- Threading is an API-SHAPE decision, not an optimization. Whether inference runs in
  a Worker must be decided before the public API exists; retrofitting is breaking.
- Write MAINTAINING.md FIRST, not last. If it can't be written, the pluggable
  backend interface isn't real yet. Also: pick a license for your own code (the plan
  never mentions one) and start at 0.x.
- "Zero required dependencies" is not true when the only way to get keypoints is
  loading tasks-vision or onnxruntime-web. Call them peer dependencies.
- Ship ESM only. Two build outputs to keep in sync forever is not worth it.
- Honest minimum sequence: (1) answer the five open questions; (2) record ~30 min of
  real non-upright footage, hand-label a few hundred frames, measure baseline
  MediaPipe PCK with and without 90-degree snapping; (3) only then build.
  If normalization doesn't beat baseline, the claimed contribution doesn't exist and
  the right deliverable is a thin wrapper plus a written-up negative finding —
  which is still worth publishing.

---

## Synthesis

### Shared starting points (a common prior to stress-test, NOT corroboration)

All five members independently reached four conclusions. Because they are all Claude,
this is a shared prior, not five-way confirmation:

1. **Cut Tier B (RTMW) from v1.** Unanimous. Reasons differ and stack: no browser
   latency number exists anywhere; COCO-WholeBody is non-commercial; no upstream ONNX
   exists so you become the publisher; GitHub Pages can't serve it or set the headers
   ORT Web needs; the frame budget doesn't close.
2. **The orientation-normalization layer is not the contribution it was billed as.**
   BlazePose already rotates its ROI upright internally (CONFIRMED from the paper).
   The estimator described (bbox aspect ratio + temporal prior) is 180-degree
   ambiguous and latches. The simpler brute-force variant (try 0/90/180/270, keep
   best confidence) is strictly better and was independently proposed twice.
3. **"One stable schema across models" is unkeepable and should be replaced** with
   declared optional parts plus per-frame provenance, so a tier swap is observable
   downstream rather than silent.
4. **Measure before building.** Every member said the same first deliverable:
   real non-upright footage through stock MediaPipe, count usable frames.

### What they might ALL be missing, for the same reason

- **They all accepted "browser library" as given.** Nobody asked whether a browser is
  the right platform. If quality genuinely is paramount and this is for someone
  else's project, a Python/desktop tool could run Sapiens (82.3 mAP on challenging
  poses) and be far better than anything that fits in a tab. The browser constraint
  was inherited from Hand Playground, not derived from the requirement.
- **They converge on cutting, which is the safe recommendation.** The owner asked for
  "the best" and something transportable and impressive. A thin MediaPipe wrapper is
  defensible engineering and may still underdeliver against the actual brief.
- **Nobody engaged with the SLP dataset** (109 in-bed subjects, multimodal,
  pretrained model zoo, from the Ostadabbas lab at Northeastern — the owner's own
  university). It is the closest existing work to the actual problem and it did not
  appear in any member's reasoning.
- **Only one member raised camera placement**, and it may be the highest-value,
  lowest-cost intervention in the whole problem.

### Genuine tensions

- **Security vs. the download button.** Security says cut it outright (biometric
  data, GDPR Art. 9, exfiltration ergonomics). The owner explicitly asked for it.
  Resolution: data export is fine if opt-in, in-memory, frame-free and unlabeled; the
  "download the library" reading is better served by a repo + release link.
- **Links tab placement.** Four members called it a category error — a bookmark list
  is not how developers consume dependencies. The owner explicitly chose it.
  Resolution that satisfies both: the artifact is a repo + npm package; the Links
  entry is a link to it, exactly like Football Tracker.
- **"Label everything" vs. legibility.** The literal requirement produces an unusable
  screen at 33 points, let alone 133. Hover-to-label + a side table of
  name/index/confidence/xyz meets the real need.

### Suggested direction

Ship one tier: MediaPipe, composed (Pose + Hands + Face, or the unified Holistic
Landmarker = 553 landmarks). This satisfies "track everything including fingers",
collapses the licensing question to a single benign one, matches the owner's own
existing self-hosting pattern, and is ~25MB instead of ~370MB.

Before any of it: 20-30 clips of real supine/prone/side-lying/quadruped movement
through stock MediaPipe, with the harness as the measuring instrument. That test is
the gate. If MediaPipe holds up, most of the plan evaporates — the good outcome. If it
fails, the measurement tells you precisely what the orientation layer has to beat,
and you will have the first honest numbers anyone in this thread has seen.
