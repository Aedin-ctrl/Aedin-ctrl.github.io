# If this goes commercial, read this first

Written when the intended use changed from research/coursework to commercial.
That change invalidates the reasoning the current build rests on.

## 1. The weights we ship have no licence. Verified, not inferred.

`vendor/mediapipe/holistic_landmarker.task` is a zip. Unpacked, it contains
exactly seven `.tflite` files and nothing else — no LICENSE, no NOTICE, not even
a copyright string:

    hand_landmarks_detector.tflite    hand_roi_refinement.tflite
    face_detector.tflite              face_landmarks_detector.tflite
    face_blendshapes.tflite           pose_detector.tflite
    pose_landmarks_detector.tflite

The MediaPipe *framework* is Apache-2.0. The model bundles are not covered by
that, and Google has never published terms for them. The issue asking for
exactly this — google-ai-edge/mediapipe#6306, "Clarify Web Tasks Vision
telemetry and Pose Landmarker model redistribution terms" — was still
unanswered when checked. One compliance write-up notes some official Google
models ship under CC-BY-4.0 rather than Apache-2.0, which would be a different
obligation again.

We self-host and redistribute these weights. For research that is a documented
gap. For a commercial product it is an unquantified liability, and it belongs to
whoever ships it.

**This is a question for a lawyer or for Google, not for a model benchmark.**

## 2. "Perfect" is not available from one camera. This is physics.

Measured in the literature, monocular markerless against marker-based capture:

| | error |
|---|---|
| 2D joint position | 72–122 mm |
| **3D joint position** | **146–249 mm** |
| good joints, angles | ~10° RMS |
| knee valgus (MediaPipe) | −19° bias |

For scale: the minimal detectable change for shoulder goniometry — the threshold
below which a clinician treats a difference as noise — is 5–10°.

A single camera cannot resolve depth. No model fixes that, because it is not a
model problem. Anything promising clinical-grade accuracy from one webcam is
either measuring something easier than it sounds, or overclaiming.

## 3. The model is not the bottleneck. Two cheaper things beat it.

From a 2026 rehabilitation-monitoring study:

- **Camera placement**: an optimally placed camera improved separability by
  **16.9%** over the usual frontal view. Cost: moving a tripod.
- **A second camera**: up to **13.1%** further improvement. Cost: a second phone.

Both are larger than the gap between any two models on this list. Spending the
budget on a model swap before fixing camera placement is spending it in the
wrong place.

## 4. What the market actually did

Sword Health — the leading digital MSK company — ships **FDA-listed wearable
IMUs**, not cameras. In January 2026 it acquired Kaia Health, whose product was
the camera-based one. A 2026 Frontiers paper puts the reason plainly: IMU-based
estimation is more reliable for recovering joint kinematics, while vision-based
methods give reasonable spatial tracking but lack consistency in joint-angle
reconstruction.

If the product needs joint angles a clinician will act on, the serious answer is
sensors, and the market has already run that experiment.

## 5. Commercially-clean model options, ranked

| model | licence | commercial? | keypoints | notes |
|---|---|---|---|---|
| **RF-DETR Keypoint** | Apache-2.0, **code and weights** | **Yes, explicitly** — Roboflow states closed-source deployment is fine | 17 (COCO) | COCO AP 71.8 @ 9.7 ms. Still "Preview". **No documented browser path** — an open issue requests an ORT Web recipe. Body only: no hands, no face. |
| MoveNet | Apache-2.0 stated | Probably | 17 | TF Hub card adds "if you intend to use it beyond permissible usage, consult the model owners", which leaves the boundary undefined. MultiPose card carries no licence line. |
| MediaPipe (current) | framework Apache-2.0, **weights undocumented** | **Unresolved** | 33 + 21×2 + 478 | What we ship today. See §1. |
| ML Kit Pose | Google ML Kit ToS | Check the ToS | 33 | Still **beta**, explicitly no SLA and no deprecation policy. Mobile only, not web. |
| ViTPose / RTMPose | Apache-2.0 code | Weights unclear | 17 / 133 | Checkpoint licensing unanswered (MMPose issues #3273, #3275, #3277). |
| **RTMW / any 133-kp whole-body** | — | **No** | 133 | Trained on COCO-WholeBody: "research and non-commercial use only" (SenseTime). The hands-and-face extension is precisely the poisoned part. SDPose-Wholebody is MIT but trained in the same format. |
| Sapiens | CC-BY-**NC**-4.0 | **No** | 308 | Sapiens2 has a custom Meta licence — read it before assuming. |
| Ultralytics YOLO (any) | **AGPL-3.0** | **No**, without an enterprise licence | 17 | Viral: forces every integrator to open-source or buy a licence. Worse than COCO-WholeBody for a redistributable library. |
| OpenPose | academic/non-profit | **No** | — | ~$25,000/yr commercial royalty. |
| AlphaPose | non-commercial | **No** | — | Commercial use requires an agreement with SJTU. |

**There is no commercially-clean whole-body (hands + face) model.** Every
133-keypoint option traces back to COCO-WholeBody. If hands and face are
required commercially, the options are: compose separate models whose licences
you have individually cleared, license a commercial SDK, or train on data you
own.

## 6. Regulatory: intended use decides, and it is set by your marketing

The FDA's January 2026 General Wellness guidance is the current version.
Secondary summaries of it agree on the shape: the product must be intended only
for general wellness *and* be low risk, and intended use is judged from
labelling, advertising, **user interface** and functionality — not from a
disclaimer. Adding a disclaimer to a product that measures range of motion and
tells a patient whether it improved does not make it a wellness product.

Practical consequence for this codebase: avoid API and UI language like `rom`,
`assessment`, `normalRange`, `deviation`, `improvement`. Emit coordinates, and
let whoever makes a clinical claim own that claim. Read the primary guidance at
fda.gov/media/90652/download rather than any summary, including this one.

## 7. Recommendation

1. **Do not ship the current build commercially** until §1 is resolved — either
   written confirmation from Google, or a different model.
2. **Fix the camera before the model.** Placement and a second view are worth
   more than any swap here, and cost nothing to test.
3. **Decide what the product actually claims.** If it needs clinician-grade
   joint angles, cameras are the wrong sensor and the market has already said
   so. If it needs movement visualisation, coaching, or adherence, a single
   camera is fine and the current accuracy is fine.
4. **If browser + commercial + body-only is acceptable**, RF-DETR Keypoint is
   the clean swap. Budget real time for the ONNX Runtime Web path; nobody has
   documented it.
5. **Get the licensing reviewed by someone qualified.** Nothing in this document
   is legal advice, and the most expensive mistake available here is a
   licensing one, not an accuracy one.
