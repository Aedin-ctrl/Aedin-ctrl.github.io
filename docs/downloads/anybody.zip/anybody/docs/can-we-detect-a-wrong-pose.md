# Can we detect a confidently-wrong pose? — five experiments, all negative

Ground truth established visually: prone.jpg detected at 0 deg has the leg chain
in empty floor (WRONG). prone90.jpg at 90 deg, un-rotated, lands correctly
(CORRECT). upright.jpg at 0 deg is correct; at 90 deg it returns a different,
high-confidence pose that disagrees by 0.21-0.34 of the frame (WRONG).

| signal tried | wrong | correct | discriminates? |
|---|---|---|---|
| mean visibility (core joints) | 0.802 / 0.996 | 0.818 / 0.994 | NO |
| mean presence (core joints)   | 0.995 / 0.998 | 0.997 / 0.999 | NO |
| bilateral bone-length symmetry| mean err 0.082 | -- | NO |
| pose segmentation mask, landmarks inside silhouette | legs 100% inside | legs 100% inside | NO (mask comes from the same wrong hypothesis) |
| cross-rotation consensus (medoid of un-rotated passes) | picks 90 on upright | correct is 0 | NO |
| world-landmark proportions femur/torso | 0.71 / 0.69 | 0.70 / 0.73 | NO |
| shin/femur | 1.09 / 1.19 | 1.06 / 1.12 | NO |

## Why none of them work

BlazePose regresses GHUM, a parametric body model. Its output is a fitted human
body, so it is ALWAYS anatomically plausible and always scores well on
self-consistency. The failure mode is not "implausible skeleton", it is
"plausible skeleton fitted to the wrong image evidence". Any check derived from
the model's own output is therefore blind to it by construction. visibility
answers roughly "is this landmark inside the frame", not "is this pose right".

Corollary: the search CAN reliably detect total detection failure (0 landmarks vs
33+), which is what makes it valuable on prone90. It CANNOT rank two rotations
that both returned a pose.

## What is left, in order of expected value

1. TEMPORAL CONSISTENCY — needs real video, which does not exist yet. A correct
   track is smooth; a wrong fit jumps and flickers. This is the only cheap signal
   that is genuinely independent of the model's own self-belief. Untestable on
   still images, which is exactly why all of the above were tried first.
2. AN INDEPENDENT SECOND MODEL — disagreement between two different
   architectures IS outside evidence. Costly (a second model download + pass).
3. INDEPENDENT IMAGE EVIDENCE — person segmentation from a model that is NOT
   the pose model, then check landmarks against that silhouette.
4. HUMAN IN THE LOOP — the harness already shows the skeleton; let the operator
   mark bad frames, and use those marks as the label set everything else lacks.

## Consequence for the library as written

`scoreBody` in src/orient.js is doing something it cannot do. It should be
documented as a found/not-found detector, not a quality ranking, and the README
should stop implying the search picks the "best" rotation when several succeed.
