# Test fixtures

- `upright.jpg` — Google's own MediaPipe pose test image
  (storage.googleapis.com/mediapipe-assets/pose.jpg)
- `prone.jpg` — Bhujangasana, a prone floor pose. Wikimedia Commons,
  "Bhujangasana Yoga-Asana Nina-Mel.jpg" by Nina Mel, CC BY 3.0.
- `prone90.jpg` — `prone.jpg` rotated 90 degrees clockwise. Because it is an
  exact rotation of another fixture, the pair is its own ground truth: a correct
  detection on one, un-rotated, must land on the same joints as a correct
  detection on the other. No hand labelling required.
- `person.mp4`, `person-prone90.mp4` — still-image clips for the e2e test.

The e2e fixture used to be an ffmpeg colour-bar pattern with no person in it.
That let "no landmarks found" pass as success and hid two bugs that made the
page render nothing at all. Fixtures must contain a person.
