# Changelog

## 0.1.1 — unreleased

Fixes found by a code review of the shipped v0.1.0. Several were invisible
because the tests could not observe the page.

### Fixed
- **The camera was never released.** `stop()` left `srcObject` live, so loading a
  video after using the camera leaked the stream with the hardware still on, and
  there was no way to turn it off short of closing the tab. Added
  `releaseCamera()` and a **Stop camera** button.
- **A recording was destroyed by switching source.** `stop()` nulled the live
  result while leaving Save enabled; saving then threw inside the export header.
  Provenance is now captured when recording *starts*.
- **Export columns were derived from frame one**, so a part that appeared later
  was dropped from the whole recording with nothing in the file to say so —
  and "arms at your sides, hands not yet found" is the normal opening of supine
  work. Columns now come from the configured parts.
- **A four-way orientation search cost five inference passes.** The cached
  rotation was run once up front and then again inside the sweep.
- **A landmark with `visibility === 0` was given confidence 1.0** — the exact
  inversion of its meaning.
- **World landmarks were never un-rotated.** They are camera-aligned, so a
  rotated input returned a skeleton rotated about the optical axis; any angle
  measured against an external axis jumped 90 degrees when the lock changed.
- **Two render loops could run at once.** An `estimate()` in flight resumed
  after `stop()` and scheduled itself again alongside the new loop.
- Changing orientation could close the landmarker out from under an in-flight
  `detect()`.
- `pointermove` ran a full canvas redraw and a forced layout per event.
- Object URLs for loaded videos were never revoked.
- Removed dead state: `#lastScores`, the backend's `found` map.

### Changed
- `createTracker` accepts a backend **function**, so the real `estimate()` can
  be driven in node with a fake backend. The previous regression test
  reimplemented `estimate()` and could not have caught a regression in it.
- `createTracker` rejects unknown `parts` instead of ignoring them.
- `toCSV()` returns rows rather than one concatenated string; `download()` hands
  the array to `Blob` directly, so the join never exists in JS heap.
- `emptyResult()` declares `world`, which the README already documented.
- `deploy-site.sh` now gates on the browser e2e as well as the unit tests, and
  re-verifies the SHA-256 of the **copied** vendor files.
- `tests/e2e.mjs` no longer depends on another project's `node_modules` or a
  session temp directory; it starts its own server and uses `fixtures/`.

### Documentation
- Corrected three claims that were false as deployed: that privacy was
  "enforced" (CSP is per-document, and the live demo is framed by a same-origin
  parent with no CSP), that hashes pin the vendored files (build/deploy-time
  only — the browser verifies nothing), and the implication that the export is
  de-identified (body landmarks 0–10 are facial; hand geometry is a biometric).
- Added `docs/can-we-detect-a-wrong-pose.md`: six signals tried against a known
  wrong detection, all negative, and why.

## 0.1.0

First release. MediaPipe Holistic, 0/90/180/270 orientation search, declared-parts
result schema, test harness, JSON/CSV export.
