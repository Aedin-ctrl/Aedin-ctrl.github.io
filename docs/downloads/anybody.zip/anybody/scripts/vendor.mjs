// Copies the pinned MediaPipe runtime into vendor/ and downloads the model.
//
// Everything is self-hosted. The library makes no network request at runtime, so
// a deployment cannot leak a request-time beacon — IP, user agent and Referer —
// to a third party at the moment someone steps in front of the camera.
//
// Every file is checked against vendor/HASHES.json. The first run writes the
// hashes (commit them); later runs fail if anything changed underneath us.
//   npm run vendor              copy + verify
//   npm run vendor -- --update  rewrite HASHES.json after an intentional bump
import { createHash } from 'node:crypto';
import { copyFile, mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const pkg = join(root, 'node_modules/@mediapipe/tasks-vision');
const out = join(root, 'vendor/mediapipe');

// Pinned to revision 1, not "latest": a silent upstream reweight would change
// every number this harness reports with nothing in the diff to show it.
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/1/holistic_landmarker.task';

// The nosimd fallback is deliberately not shipped: it is 12 MB, and WebAssembly
// SIMD has been baseline since Safari 16.4 (March 2023).
const COPY = [
  'vision_bundle.mjs',
  'wasm/vision_wasm_internal.js',
  'wasm/vision_wasm_internal.wasm',
];

const exists = (p) => access(p).then(() => true, () => false);
const sha256 = async (p) => createHash('sha256').update(await readFile(p)).digest('hex');

await mkdir(join(out, 'wasm'), { recursive: true });
for (const f of COPY) await copyFile(join(pkg, f), join(out, f));

const modelPath = join(out, 'holistic_landmarker.task');
if (!(await exists(modelPath))) {
  console.log('downloading holistic_landmarker.task (13 MB) …');
  const res = await fetch(MODEL_URL);
  if (!res.ok) throw new Error(`model download failed: ${res.status}`);
  await writeFile(modelPath, Buffer.from(await res.arrayBuffer()));
}

const files = [...COPY, 'holistic_landmarker.task'];
const hashes = {};
for (const f of files) hashes[f] = await sha256(join(out, f));

const hashFile = join(root, 'vendor/HASHES.json');
const update = process.argv.includes('--update');
if (!update && (await exists(hashFile))) {
  const expected = JSON.parse(await readFile(hashFile, 'utf8'));
  const bad = files.filter((f) => expected[f] !== hashes[f]);
  if (bad.length) {
    console.error('HASH MISMATCH:', bad.join(', '));
    console.error('If this is an intentional upgrade, run: npm run vendor -- --update');
    process.exit(1);
  }
  console.log(`verified ${files.length} files against vendor/HASHES.json`);
} else {
  await writeFile(hashFile, JSON.stringify(hashes, null, 2) + '\n');
  console.log(`wrote vendor/HASHES.json (${files.length} files)`);
}
