#!/bin/sh
# Copies the harness into the aedinlai.com site repo (served from docs/).
#   scripts/deploy-site.sh      then commit + push the site repo
set -e
cd "$(dirname "$0")/.."

npm test >/dev/null && echo "unit tests ok"
# The unit tests cannot observe a blank page -- that is exactly how the blank
# canvas shipped last time. The browser test is part of the gate now.
npm run test:e2e >/dev/null 2>&1 && echo "browser e2e ok" || { echo "e2e FAILED -- not deploying" >&2; exit 1; }
npm run vendor >/dev/null && echo "vendor hashes ok"

SITE="${SITE:-$HOME/Desktop/all/Aedin-ctrl.github.io}"
[ -d "$SITE/docs" ] || { echo "site repo not found at $SITE" >&2; exit 1; }

# Written out in full rather than assembled from a variable, and guarded on the
# directory actually being the one we expect, because an rm -rf built from a
# shell variable is how a repo gets deleted.
DEST="$SITE/docs/anybody"
case "$DEST" in
  "$HOME"/Desktop/all/Aedin-ctrl.github.io/docs/anybody) ;;
  *) echo "refusing to remove unexpected path: $DEST" >&2; exit 1 ;;
esac
rm -rf "$DEST"

mkdir -p "$DEST/src/backends" "$DEST/src/harness" "$DEST/vendor/mediapipe/wasm"
cp index.html README.md LICENSE LICENSES.txt "$DEST/"
cp src/anybody.js src/schema.js src/orient.js "$DEST/src/"
cp src/backends/mediapipe.js "$DEST/src/backends/"
cp src/harness/main.js src/harness/draw.js src/harness/export.js src/harness/style.css "$DEST/src/harness/"
cp vendor/mediapipe/vision_bundle.mjs vendor/mediapipe/holistic_landmarker.task "$DEST/vendor/mediapipe/"
cp vendor/mediapipe/wasm/vision_wasm_internal.js vendor/mediapipe/wasm/vision_wasm_internal.wasm "$DEST/vendor/mediapipe/wasm/"
cp vendor/HASHES.json "$DEST/vendor/"

# Re-verify the COPIED bytes. `npm run vendor` only checks the source tree, so
# without this the hash story stopped at the dev machine while the live site
# served whatever cp happened to put there.
node -e '
  const { createHash } = require("node:crypto");
  const { readFileSync } = require("node:fs");
  const { join } = require("node:path");
  const dest = process.argv[1];
  const want = JSON.parse(readFileSync(join(dest, "vendor/HASHES.json"), "utf8"));
  let bad = 0;
  for (const [f, h] of Object.entries(want)) {
    const p = join(dest, "vendor/mediapipe", f);
    let got;
    try { got = createHash("sha256").update(readFileSync(p)).digest("hex"); }
    catch { console.error("MISSING in deploy:", f); bad++; continue; }
    if (got !== h) { console.error("HASH MISMATCH in deploy:", f); bad++; }
  }
  if (bad) { console.error(bad + " deployed vendor file(s) failed verification"); process.exit(1); }
  console.log("deployed vendor files verified (" + Object.keys(want).length + ")");
' "$DEST"

# The Links tab hands out the whole project as a zip. Build it from the same
# tree in the same run, so the download can never drift from what is live.
ZIPDIR="$SITE/docs/downloads"
mkdir -p "$ZIPDIR"
STAGE="$(mktemp -d)"
case "$STAGE" in
  /*/tmp.*|/var/folders/*|/tmp/*) ;;
  *) echo "refusing to use unexpected temp dir: $STAGE" >&2; exit 1 ;;
esac
mkdir -p "$STAGE/anybody"
tar -cf - --exclude node_modules --exclude .git --exclude .debug --exclude clips \
          --exclude .DS_Store . | (cd "$STAGE/anybody" && tar -xf -)
rm -f "$ZIPDIR/anybody.zip"
( cd "$STAGE" && zip -r -q -X "$ZIPDIR/anybody.zip" anybody )
rm -rf "$STAGE"
ls -lh "$ZIPDIR/anybody.zip" | awk '{print "download zip: " $5}'

du -sh "$DEST"
echo "deployed to $DEST"
