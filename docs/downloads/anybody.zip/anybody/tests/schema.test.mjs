import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  SCHEMA_VERSION, PARTS, BODY_NAMES, HAND_NAMES, BODY_EDGES, HAND_EDGES,
  sideOf, partInfo, emptyResult, makePoint,
} from '../src/schema.js';
import { boxOf } from '../src/anybody.js';

test('landmark name lists match the models they describe', () => {
  assert.equal(BODY_NAMES.length, 33, 'BlazePose has 33 body landmarks');
  assert.equal(HAND_NAMES.length, 21, 'MediaPipe hands have 21 landmarks');
  assert.equal(new Set(BODY_NAMES).size, 33, 'body names must be unique');
  assert.equal(new Set(HAND_NAMES).size, 21, 'hand names must be unique');
});

test('every skeleton edge refers to a landmark that exists', () => {
  for (const [a, b] of BODY_EDGES) {
    assert.ok(a >= 0 && a < 33 && b >= 0 && b < 33, `body edge ${a}-${b} out of range`);
    assert.notEqual(a, b, 'an edge must join two different landmarks');
  }
  for (const [a, b] of HAND_EDGES) {
    assert.ok(a >= 0 && a < 21 && b >= 0 && b < 21, `hand edge ${a}-${b} out of range`);
    assert.notEqual(a, b);
  }
});

test('left and right landmarks are symmetric', () => {
  const left = BODY_NAMES.filter((n) => n.startsWith('left_')).map((n) => n.slice(5));
  const right = BODY_NAMES.filter((n) => n.startsWith('right_')).map((n) => n.slice(6));
  assert.deepEqual(left.sort(), right.sort(), 'each left landmark needs a right twin');
});

test('sideOf classifies every body landmark', () => {
  assert.equal(sideOf('left_knee'), 'left');
  assert.equal(sideOf('right_knee'), 'right');
  assert.equal(sideOf('nose'), 'centre');
  for (const n of BODY_NAMES) assert.ok(['left', 'right', 'centre'].includes(sideOf(n)));
});

test('partInfo covers every declared part and rejects unknown ones', () => {
  for (const p of PARTS) {
    const info = partInfo(p);
    assert.ok(info.count > 0, `${p} should have landmarks`);
  }
  assert.equal(partInfo('body').count, 33);
  assert.equal(partInfo('leftHand').count, 21);
  assert.equal(partInfo('face').count, 478);
  assert.throws(() => partInfo('tail'), /unknown part/);
});

test('an empty result is well formed and carries its provenance', () => {
  const r = emptyResult({ modelId: 'x', modelRevision: '1' });
  assert.equal(r.schemaVersion, SCHEMA_VERSION);
  assert.equal(r.modelId, 'x');
  assert.equal(r.modelRevision, '1');
  assert.deepEqual(r.parts, {}, 'absent parts are absent, not zero-filled');
  assert.deepEqual(r.points, []);
  assert.equal(r.box, null);
});

test('a point records presence explicitly rather than using a sentinel', () => {
  const p = makePoint({ part: 'body', index: 0, name: 'nose', x: 0.5, y: 0.5, z: 0, score: 0.9, present: true });
  assert.equal(p.present, true);
  assert.equal(p.name, 'nose');
  assert.ok('score' in p);
});

// --- boxOf -----------------------------------------------------------------

const pt = (x, y, score = 1, part = 'body') => ({ part, x, y, score });

test('boxOf bounds the confident body points', () => {
  const box = boxOf([pt(0.2, 0.1), pt(0.8, 0.5), pt(0.4, 0.9)]);
  assert.deepEqual(box, { x: 0.2, y: 0.1, w: 0.6000000000000001, h: 0.8 });
});

test('boxOf ignores low-confidence points and other parts', () => {
  const box = boxOf([pt(0.4, 0.4), pt(0.6, 0.6), pt(0.0, 0.0, 0.01), pt(1, 1, 1, 'face')]);
  assert.ok(box.x >= 0.4 && box.y >= 0.4, 'a 0.01-confidence point must not widen the box');
  assert.ok(box.x + box.w <= 0.6 + 1e-9, 'a face point must not widen a body box');
});

test('boxOf returns null when nothing is confident enough', () => {
  assert.equal(boxOf([]), null);
  assert.equal(boxOf([pt(0.5, 0.5, 0.0)]), null);
});
