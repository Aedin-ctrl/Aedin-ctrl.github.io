import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  ROTATIONS, rotatePoint, unrotatePoint, rotatedSize, scoreBody, OrientationSearch,
} from '../src/orient.js';

const close = (a, b, eps = 1e-12) =>
  assert.ok(Math.abs(a - b) < eps, `expected ${a} ~= ${b}`);

test('rotate then unrotate is the identity, for every rotation', () => {
  const pts = [[0, 0], [1, 1], [0.25, 0.75], [0.5, 0.5], [0.01, 0.99]];
  for (const deg of ROTATIONS) {
    for (const [x, y] of pts) {
      const r = rotatePoint(x, y, deg);
      const back = unrotatePoint(r.x, r.y, deg);
      close(back.x, x);
      close(back.y, y);
    }
  }
});

test('rotation matches the pixel convention it claims (90 is clockwise)', () => {
  // Source top-left must land at the top-right of a 90-degree clockwise rotation.
  const r = rotatePoint(0, 0, 90);
  close(r.x, 1);
  close(r.y, 0);
  // Source top-right must land at the bottom-right.
  const r2 = rotatePoint(1, 0, 90);
  close(r2.x, 1);
  close(r2.y, 1);
});

test('270 is the inverse rotation of 90', () => {
  for (const [x, y] of [[0.3, 0.7], [0, 1], [0.9, 0.1]]) {
    const a = rotatePoint(x, y, 90);
    const b = rotatePoint(a.x, a.y, 270);
    close(b.x, x);
    close(b.y, y);
  }
});

test('180 applied twice is the identity', () => {
  const a = rotatePoint(0.2, 0.8, 180);
  const b = rotatePoint(a.x, a.y, 180);
  close(b.x, 0.2);
  close(b.y, 0.8);
});

test('rotatedSize swaps axes only on the quarter turns', () => {
  assert.deepEqual(rotatedSize(640, 480, 0), { w: 640, h: 480 });
  assert.deepEqual(rotatedSize(640, 480, 90), { w: 480, h: 640 });
  assert.deepEqual(rotatedSize(640, 480, 180), { w: 640, h: 480 });
  assert.deepEqual(rotatedSize(640, 480, 270), { w: 480, h: 640 });
});

test('a rotation that is not a quarter turn is rejected', () => {
  assert.throws(() => rotatePoint(0, 0, 45), /multiple of 90/);
  assert.throws(() => unrotatePoint(0, 0, 1), /multiple of 90/);
});

// --- scoring ---------------------------------------------------------------

const bodyWith = (score) =>
  Array.from({ length: 33 }, (_, i) => ({ part: 'body', index: i, score }));

test('scoreBody ignores non-body parts and empty input', () => {
  assert.equal(scoreBody([]), 0);
  assert.equal(scoreBody(null), 0);
  assert.equal(scoreBody([{ part: 'face', index: 0, score: 1 }]), 0);
});

test('scoreBody scores torso and limbs, not the face cluster', () => {
  const pts = bodyWith(0);
  // Head landmarks 0..10 are confident; the core joints are not.
  for (let i = 0; i <= 10; i++) pts[i].score = 1;
  assert.equal(scoreBody(pts), 0, 'a confident face must not mask lost limbs');
});

// --- search ----------------------------------------------------------------

/** A fake backend that only "works" at one rotation. */
const fakeRunner = (goodAt, good = 0.9, bad = 0.1) => async (deg) =>
  bodyWith(deg === goodAt ? good : bad);

test('auto search finds the rotation the model actually understands', async () => {
  const search = new OrientationSearch({ mode: 'auto' });
  const got = await search.pick(fakeRunner(180));
  assert.equal(got.rotation, 180);
  assert.equal(got.searched, true);
  assert.deepEqual(Object.keys(got.scores).map(Number).sort((a, b) => a - b), [0, 90, 180, 270]);
});

test('once locked, a good frame costs one pass, not four', async () => {
  const search = new OrientationSearch({ mode: 'auto' });
  await search.pick(fakeRunner(90));
  let calls = 0;
  const counting = async (deg) => { calls++; return bodyWith(deg === 90 ? 0.9 : 0.1); };
  const got = await search.pick(counting);
  assert.equal(calls, 1, 'should reuse the cached rotation');
  assert.equal(got.searched, false);
  assert.equal(got.rotation, 90);
});

test('a forced recheck stops a confidently wrong lock from persisting', async () => {
  // Lock onto 0, then change the world so 180 is correct. Even though the cached
  // rotation still scores above keepAbove, the recheck must re-evaluate.
  const search = new OrientationSearch({ mode: 'auto', recheckEvery: 2 });
  await search.pick(fakeRunner(0));
  await search.pick(fakeRunner(0));
  const got = await search.pick(async (deg) => bodyWith(deg === 180 ? 0.95 : 0.6));
  assert.equal(got.searched, true, 'recheckEvery must force a full search');
  assert.equal(got.rotation, 180);
});

test('hysteresis keeps a marginal challenger from flipping the skeleton', async () => {
  const search = new OrientationSearch({ mode: 'auto', margin: 0.2, keepAbove: 0.99 });
  await search.pick(fakeRunner(0, 0.8, 0.1));
  // 90 is better, but not by the margin: stay put.
  const got = await search.pick(async (deg) => bodyWith(deg === 90 ? 0.85 : 0.8));
  assert.equal(got.rotation, 0);
});

test("mode 'none' never searches and never rotates", async () => {
  const search = new OrientationSearch({ mode: 'none' });
  let seen = [];
  await search.pick(async (deg) => { seen.push(deg); return bodyWith(0.1); });
  assert.deepEqual(seen, [0]);
});

test('a pinned rotation is used verbatim', async () => {
  const search = new OrientationSearch({ mode: 270 });
  let seen = [];
  const got = await search.pick(async (deg) => { seen.push(deg); return bodyWith(0.2); });
  assert.deepEqual(seen, [270]);
  assert.equal(got.rotation, 270);
  assert.equal(got.searched, false);
});

test('an invalid orientation mode is rejected at construction', () => {
  assert.throws(() => new OrientationSearch({ mode: 45 }), /orientation must be/);
  assert.throws(() => new OrientationSearch({ mode: 'sideways' }), /orientation must be/);
});

// --- partial framing -------------------------------------------------------

/** A body where only the upper half is in frame — a webcam head-and-shoulders. */
const upperBodyOnly = () => {
  const b = Array.from({ length: 33 }, (_, i) => ({ part: 'body', index: i, score: 0.95 }));
  // hips, knees, ankles, heels, toes: extrapolated below the frame
  for (const i of [23, 24, 25, 26, 27, 28, 29, 30, 31, 32]) b[i].score = 0.03;
  return b;
};

test('scoring does not collapse when half the body is out of frame', () => {
  // A flat mean over all twelve core joints sinks below any sensible
  // `keepAbove` on a webcam crop, which fired a four-pass rotation search on
  // every frame for a subject that was being tracked perfectly.
  const s = scoreBody(upperBodyOnly());
  assert.ok(s > 0.8, `an upper-body shot should still score well, got ${s}`);
});

test('scoring still bottoms out when the body is genuinely lost', () => {
  const lost = Array.from({ length: 33 }, (_, i) => ({ part: 'body', index: i, score: 0.02 }));
  assert.ok(scoreBody(lost) < 0.1);
  assert.equal(scoreBody([]), 0);
});

test('a fully visible body still outscores a partially visible one', () => {
  const full = Array.from({ length: 33 }, (_, i) => ({ part: 'body', index: i, score: 0.99 }));
  assert.ok(scoreBody(full) >= scoreBody(upperBodyOnly()));
});

test('an upper-body shot does not trigger an endless rotation search', async () => {
  const search = new OrientationSearch({ mode: 'auto', cooldown: 0 });
  await search.pick(async () => upperBodyOnly());   // first frame: forced search
  let passes = 0;
  const got = await search.pick(async () => { passes++; return upperBodyOnly(); });
  assert.equal(passes, 1, 'a well-tracked upper body must cost one pass, not four');
  assert.equal(got.searched, false);
});
