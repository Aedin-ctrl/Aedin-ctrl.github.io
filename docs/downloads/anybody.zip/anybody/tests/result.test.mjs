// Regression tests for how a result is assembled.
//
// These drive the REAL createTracker()/estimate() with an injected fake
// backend. The previous version of this file reimplemented estimate() and
// asserted against the copy — so the exact bug it was written for could have
// been reintroduced in src/anybody.js with every test still green.
//
// The bug: `parts` was built from whichever rotation the backend ran LAST,
// while `points` came from the rotation that WON. On any frame where the final
// pass found nothing, `parts` came back empty while `points` was full — and the
// harness draws its skeleton and its table from `parts`, so the page rendered
// nothing at all.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createTracker, boxOf, unrotatePoint } from '../src/anybody.js';
import { BODY_NAMES, HAND_NAMES, SCHEMA_VERSION } from '../src/schema.js';

globalThis.performance ??= { now: () => Date.now() };

const mk = (part, names, score) =>
  names.map((name, i) => ({
    part, index: i, name, x: 0.5, y: 0.5, z: 0, score, present: true,
  }));

/** Build a fake backend from a (deg) => {points, world} function. */
const fake = (run) => async () => ({
  id: 'fake', revision: '0', declaredParts: ['body'], connections: {},
  run: (source, deg) => run(deg),
  close() {},
});

test('parts reflect the winning pass, not the last one run', async () => {
  // 0 degrees succeeds; the LAST rotation searched finds nothing.
  const t = await createTracker({
    orientation: 'auto',
    backend: fake((deg) => deg === 0
      ? { points: [...mk('body', BODY_NAMES, 0.95), ...mk('leftHand', HAND_NAMES, 0.9)], world: [{ index: 0 }] }
      : { points: [], world: null }),
  });
  const r = await t.estimate({}, 0);
  assert.equal(r.orientation.applied, 0);
  assert.ok(r.points.length > 0, 'points should be found');
  assert.deepEqual(Object.keys(r.parts).sort(), ['body', 'leftHand'],
    'parts must come from the winning pass');
});

test('parts partition points exactly, and each holds only its own', async () => {
  const t = await createTracker({
    orientation: 'none',
    backend: fake(() => ({
      points: [...mk('body', BODY_NAMES, 0.9), ...mk('leftHand', HAND_NAMES, 0.8)], world: null,
    })),
  });
  const r = await t.estimate({}, 0);
  const total = Object.values(r.parts).reduce((n, a) => n + a.length, 0);
  assert.equal(total, r.points.length);
  for (const [name, arr] of Object.entries(r.parts)) {
    for (const p of arr) assert.equal(p.part, name);
  }
});

test('a part array is indexed by landmark index', async () => {
  // draw.js does pts[a] for an edge [a,b]; out-of-order parts would join the
  // wrong joints together.
  const t = await createTracker({ orientation: 'none', backend: fake(() => ({ points: mk('body', BODY_NAMES, 0.9), world: null })) });
  const r = await t.estimate({}, 0);
  r.parts.body.forEach((p, i) => assert.equal(p.index, i));
});

test('world landmarks come from the winning rotation', async () => {
  const t = await createTracker({
    orientation: 'auto',
    backend: fake((deg) => deg === 90
      ? { points: mk('body', BODY_NAMES, 0.95), world: [{ index: 0, name: 'nose', x: 1, y: 2, z: 3 }] }
      : { points: mk('body', BODY_NAMES, 0.1), world: [{ index: 0, name: 'nose', x: 9, y: 9, z: 9 }] }),
  });
  const r = await t.estimate({}, 0);
  assert.equal(r.orientation.applied, 90);
  assert.equal(r.world[0].x, 1);
});

test('the winning rotation maps its points back into source coordinates', async () => {
  const t = await createTracker({
    orientation: 'auto',
    backend: fake((deg) => deg === 90
      ? { points: [{ part: 'body', index: 0, name: 'nose', x: 0.25, y: 0.75, z: 0, score: 0.95, present: true },
                   ...mk('body', BODY_NAMES, 0.95).slice(1)], world: null }
      : { points: mk('body', BODY_NAMES, 0.05), world: null }),
  });
  const r = await t.estimate({}, 0);
  assert.equal(r.orientation.applied, 90);
  const want = unrotatePoint(0.25, 0.75, 90);
  assert.ok(Math.abs(r.parts.body[0].x - want.x) < 1e-12);
  assert.ok(Math.abs(r.parts.body[0].y - want.y) < 1e-12);
});

test('a four-way search costs four passes, not five', async () => {
  // The cached rotation used to be run once up front and then AGAIN inside the
  // sweep, so the worst case was 5 inferences for a "four-way" search.
  let passes = 0;
  const t = await createTracker({
    orientation: 'auto',
    cooldown: 0,
    backend: fake(() => { passes++; return { points: mk('body', BODY_NAMES, 0.1), world: null }; }),
  });
  await t.estimate({}, 0);
  assert.equal(passes, 4, 'initial forced search');
  passes = 0;
  await t.estimate({}, 1);
  assert.equal(passes, 4, 'a later search must not re-run the cached rotation');
});

test('a search that changes nothing backs off instead of refiring every frame', async () => {
  // Low confidence -> four passes -> subject has moved and blurred -> low
  // confidence again. Without a cooldown that pins the frame rate at its worst
  // value for exactly the subjects this library exists for.
  let passes = 0;
  const t = await createTracker({
    orientation: 'auto',
    cooldown: 3,
    backend: fake(() => { passes++; return { points: mk('body', BODY_NAMES, 0.1), world: null }; }),
  });
  await t.estimate({}, 0);           // forced search, 4 passes, rotation unchanged
  passes = 0;
  for (let i = 0; i < 3; i++) await t.estimate({}, i + 1);
  assert.equal(passes, 3, 'one pass per frame while cooling down, not four');
  passes = 0;
  await t.estimate({}, 9);
  assert.equal(passes, 4, 'searching resumes once the cooldown expires');
});

test('a search reports the runner-up rotation and how far it disagrees', async () => {
  // The measured fact this exists for: two rotations can both return a
  // confident body and disagree by a seventh of the frame. Confidence does not
  // show that; this does. It is a warning, not a selector.
  const t = await createTracker({
    orientation: 'auto',
    backend: fake((deg) => {
      if (deg === 0) return { points: mk('body', BODY_NAMES, 0.9).map((p) => ({ ...p, x: 0.5, y: 0.5 })), world: null };
      if (deg === 90) return { points: mk('body', BODY_NAMES, 0.8).map((p) => ({ ...p, x: 0.5, y: 0.5 })), world: null };
      return { points: [], world: null };
    }),
  });
  const r = await t.estimate({}, 0);
  assert.ok(r.agreement, 'two candidates found a body, so agreement must be reported');
  assert.equal(typeof r.agreement.disagreement, 'number');
  assert.ok(r.rival, 'the runner-up pose is exposed so it can be drawn');
  assert.notEqual(r.rival.rotation, r.orientation.applied);
});

test('agreement is null when only one rotation found anything', async () => {
  const t = await createTracker({
    orientation: 'auto',
    backend: fake((deg) => (deg === 0
      ? { points: mk('body', BODY_NAMES, 0.9), world: null }
      : { points: [], world: null })),
  });
  const r = await t.estimate({}, 0);
  assert.equal(r.agreement, null, 'nothing to disagree with');
  assert.equal(r.rival, null);
});

test('every frame is stamped with model provenance and schema version', async () => {
  const t = await createTracker({ orientation: 'none', backend: fake(() => ({ points: mk('body', BODY_NAMES, 0.9), world: null })) });
  const r = await t.estimate({}, 0);
  assert.equal(r.schemaVersion, SCHEMA_VERSION);
  assert.equal(r.modelId, 'fake');
  assert.equal(r.modelRevision, '0');
});

test('when nothing is found, parts and points are empty together', async () => {
  const t = await createTracker({ orientation: 'none', backend: fake(() => ({ points: [], world: null })) });
  const r = await t.estimate({}, 0);
  assert.deepEqual(r.parts, {});
  assert.deepEqual(r.points, []);
  assert.equal(r.box, null);
});

test('an unknown part is rejected rather than silently ignored', async () => {
  await assert.rejects(
    () => createTracker({ parts: ['Body'], backend: fake(() => ({ points: [], world: null })) }),
    /unknown part/);
});

test('boxOf ignores low-confidence points and foreign parts', () => {
  const pt = (x, y, score = 1, part = 'body') => ({ part, x, y, score });
  const box = boxOf([pt(0.4, 0.4), pt(0.6, 0.6), pt(0, 0, 0.01), pt(1, 1, 1, 'face')]);
  assert.ok(box.x >= 0.4 && box.x + box.w <= 0.6 + 1e-9);
  assert.equal(boxOf([]), null);
});
