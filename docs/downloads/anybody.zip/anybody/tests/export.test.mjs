import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Recorder } from '../src/harness/export.js';
import { BODY_NAMES, HAND_NAMES } from '../src/schema.js';

const mkPart = (part, names) =>
  names.map((name, i) => ({
    part, index: i, name, x: i / names.length, y: 1 - i / names.length,
    z: 0.01 * i, score: 0.9, present: true,
  }));

/** @param parts which parts this frame actually found */
const frame = ({ rot = 0, parts = ['body', 'leftHand'] } = {}) => {
  const p = {};
  if (parts.includes('body')) p.body = mkPart('body', BODY_NAMES);
  if (parts.includes('leftHand')) p.leftHand = mkPart('leftHand', HAND_NAMES);
  if (parts.includes('rightHand')) p.rightHand = mkPart('rightHand', HAND_NAMES);
  return {
    schemaVersion: 1, modelId: 'test-model', modelRevision: '1.0',
    parts: p, points: Object.values(p).flat(),
    orientation: { applied: rot, score: 0.8, searched: false, scores: null },
    timings: { totalMs: 12.5, inferenceMs: 10, passes: 1 },
  };
};
const rows = (r) => r.toCSV().filter((l) => !l.startsWith('#'));

test('a recorder captures the frames it is given', () => {
  const r = new Recorder();
  const f = frame();
  r.start(f);
  for (let i = 0; i < 10; i++) r.push(f, i * 33);
  assert.equal(r.stop(), 10);
});

test('columns cover every CONFIGURED part, not just those in frame one', () => {
  // The bug this replaces: layout was derived from frame one, so a hand that
  // was not yet visible vanished from the whole recording. Supine with arms at
  // the sides is exactly that opening.
  const r = new Recorder({ parts: ['body', 'leftHand', 'rightHand'] });
  const layout = r.start(frame({ parts: ['body'] })); // no hands in frame one
  assert.deepEqual(layout.parts, ['body', 'leftHand', 'rightHand']);
  assert.equal(layout.columns.length, 33 + 21 + 21);
  assert.ok(layout.columns.some((c) => c.part === 'rightHand'),
    'a part absent from frame one must still get columns');
});

test('a part that appears late is captured, not silently dropped', () => {
  const r = new Recorder({ parts: ['body', 'leftHand'] });
  r.start(frame({ parts: ['body'] }));
  r.push(frame({ parts: ['body'] }), 0);
  r.push(frame({ parts: ['body', 'leftHand'] }), 33); // hand appears now
  r.stop();
  const out = rows(r);
  const col = out[0].split(',').indexOf('leftHand.wrist.x');
  assert.ok(col > 0, 'the late hand must have a column');
  assert.equal(out[1].split(',')[col], '', 'absent in frame 1');
  assert.notEqual(out[2].split(',')[col], '', 'present in frame 2 and recorded');
});

test('a part that disappears is recorded as blank, never as zero', () => {
  const r = new Recorder({ parts: ['body', 'leftHand'] });
  r.start(frame());
  r.push(frame(), 0);
  r.push(frame({ parts: ['body'] }), 33);
  r.stop();
  const out = rows(r);
  const col = out[0].split(',').indexOf('leftHand.thumb_tip.x');
  assert.ok(col > 0);
  assert.equal(out[2].split(',')[col], '', 'a missing joint must be blank, not 0');
  assert.notEqual(out[1].split(',')[col], '');
});

test('the face mesh is excluded by default', () => {
  const r = new Recorder();
  const layout = r.start(frame());
  assert.ok(!layout.parts.includes('face'));
  assert.equal(layout.columns.length, 33 + 21 + 21);
});

test('provenance is captured when recording STARTS, not when saving', () => {
  // The bug this replaces: the header was built at save time from whatever
  // result was live then — which was the wrong model after a source switch,
  // and threw outright when it was null.
  const r = new Recorder();
  r.start(frame());
  r.push(frame(), 0);
  r.stop();
  const out = JSON.parse(r.toJSON());
  assert.equal(out.model.id, 'test-model');
  assert.equal(out.schemaVersion, 1);
  assert.ok(out.recordedAt, 'recordedAt must be the start time, not absent');
});

test('saving after the live result is gone does not throw', () => {
  const r = new Recorder();
  r.start(frame());
  r.push(frame(), 0);
  r.stop();
  assert.doesNotThrow(() => r.toJSON());
  assert.doesNotThrow(() => r.toCSV());
});

test('pushing without starting does nothing', () => {
  const r = new Recorder();
  assert.equal(r.push(frame(), 0), false);
  assert.equal(r.frames, 0);
});

test('the frame cap is enforced rather than growing without bound', () => {
  const r = new Recorder({ maxFrames: 5 });
  const f = frame();
  r.start(f);
  for (let i = 0; i < 12; i++) r.push(f, i);
  assert.equal(r.frames, 5);
  assert.equal(r.droppedForLimit, 7);
});

test('recording spans several chunks correctly', () => {
  const r = new Recorder();
  const f = frame();
  r.start(f);
  for (let i = 0; i < 200; i++) r.push(f, i * 33);
  r.stop();
  const out = rows(r);
  assert.equal(out.length, 201, 'header + 200 rows');
  assert.equal(Number(out.at(-1).split(',')[0]), 199);
});

test('JSON export carries every frame and its rotation', () => {
  const r = new Recorder();
  const f = frame({ rot: 90 });
  r.start(f);
  for (let i = 0; i < 3; i++) r.push(f, i * 33);
  r.stop();
  const out = JSON.parse(r.toJSON());
  assert.equal(out.frameCount, 3);
  assert.equal(out.frames.length, 3);
  for (const fr of out.frames) assert.equal(fr.rot, 90);
  assert.equal(out.frames[1].t, 33);
});

test('CSV is returned as rows, never one concatenated string', () => {
  // Blob joins an array itself; building the join in JS was the peak-memory
  // step of the whole export.
  const r = new Recorder();
  r.start(frame());
  r.push(frame(), 0);
  r.stop();
  const csv = r.toCSV();
  assert.ok(Array.isArray(csv), 'toCSV must return rows');
  const head = csv.find((l) => l.startsWith('frame,')).split(',');
  assert.equal(head.length, 7 + 75 * 4);
  assert.ok(head.includes('body.nose.x'));
  assert.ok(head.includes('body.left_knee.score'));
  assert.ok(head.includes('rotation_deg'));
});

test('a landmark the model guessed off-frame is exported blank, not as a number', () => {
  // The pose model always emits all 33 body landmarks, extrapolating the ones
  // it cannot see. On a webcam crop the knees land below the picture. Those are
  // guesses; writing them as measurements is invisible to a consumer.
  const r = new Recorder({ parts: ['body'] });
  const f = frame({ parts: ['body'] });
  for (const i of [25, 26, 27, 28]) { f.parts.body[i].present = false; }
  r.start(f);
  r.push(f, 0);
  r.stop();
  const out = rows(r);
  const head = out[0].split(',');
  const knee = head.indexOf('body.left_knee.x');
  const shoulder = head.indexOf('body.left_shoulder.x');
  assert.ok(knee > 0 && shoulder > 0);
  assert.equal(out[1].split(',')[knee], '', 'an absent landmark must be blank');
  assert.notEqual(out[1].split(',')[shoulder], '', 'a present one must be recorded');
});
