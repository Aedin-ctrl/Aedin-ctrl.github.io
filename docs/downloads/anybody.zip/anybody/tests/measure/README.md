# Measurement pages

The numbers in the project README's "What has actually been measured" section
came from these pages. They are committed so the claims are reproducible rather
than anecdotes — and so that when a model revision changes the answer, the
change is visible instead of silently making a comment untrue.

    npm run serve
    # then open, in a browser with a real GPU (headless Chrome falls back to a
    # software rasteriser and roughly doubles the frame times):
    #   /tests/measure/rotation-matrix.html   every fixture at every pinned rotation
    #   /tests/measure/model-state.html       is IMAGE mode stateless? (it is not)

Both print their results to `window.OUT` and to the page.

Note the constraint that makes these fiddly: MediaPipe carries state between
`detect()` calls, so a page that measures several fixtures in one landmarker
gets different answers than one that creates a fresh landmarker per fixture.
Each page says which it does. Do not "tidy" that away.
