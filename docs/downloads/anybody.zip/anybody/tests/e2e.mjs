// End-to-end smoke test: load the harness, feed it a video file, and assert the
// pipeline runs without console errors. Uses system Chrome via playwright-core.
//
//   node tests/e2e.mjs [path-to-video]
import { chromium } from 'playwright-core';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

// A clip with an actual person in it. The earlier fixture was a colour-bar test
// pattern, which let 'no landmarks found' pass as success and hid two bugs that
// made the page render nothing at all. Resolved relative to this file so the
// test runs on any machine, not just the one it was written on.
const VIDEO = process.argv[2] ?? fileURLToPath(new URL('../fixtures/person.mp4', import.meta.url));
const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PORT = Number(process.env.PORT ?? 5173);
const URL_ = process.env.URL ?? `http://localhost:${PORT}/index.html`;

// Start our own static server unless pointed at something already running.
let server = null;
if (!process.env.URL) {
  server = spawn('python3', ['-m', 'http.server', String(PORT)], { cwd: ROOT, stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 1200));
}
const shutdown = () => server?.kill();
process.on('exit', shutdown);

const browser = await chromium.launch({ channel: 'chrome', headless: true });
const page = await browser.newPage();

const errors = [];
const logs = [];
page.on('console', (m) => {
  logs.push(`${m.type()}: ${m.text()}`);
  if (m.type() === 'error') errors.push(m.text());
});
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
const missing = [];
page.on('response', (r) => { if (r.status() === 404) missing.push(r.url()); });

await page.goto(URL_, { waitUntil: 'networkidle' });

const fail = (msg) => { console.error('FAIL:', msg); process.exitCode = 1; };
const ok = (msg) => console.log('  ok  ', msg);

// --- static checks ---------------------------------------------------------
const title = await page.title();
title.includes('Anybody') ? ok('page title') : fail(`title was ${title}`);

const hasCSP = await page.$eval('meta[http-equiv="Content-Security-Policy"]', (m) => m.content);
hasCSP.includes("connect-src 'self'") ? ok("CSP pins connect-src to 'self'") : fail('CSP missing connect-src');

// --- feed it a video -------------------------------------------------------
await page.setInputFiles('#file', VIDEO);

// Model load is a 13 MB fetch plus wasm init; give it room.
await page.waitForFunction(
  () => document.getElementById('status')?.textContent?.startsWith('Tracking'),
  null, { timeout: 90_000 },
).then(() => ok('model loaded and tracking started'))
 .catch(async () => fail(`never started tracking (status: ${await page.textContent('#status')})`));

// Let a few frames go through.
await page.waitForTimeout(4000);

const stats = await page.evaluate(() => {
  const dl = document.getElementById('stats');
  const out = {};
  const dts = [...dl.querySelectorAll('dt')];
  dts.forEach((dt) => { out[dt.textContent] = dt.nextElementSibling?.textContent; });
  return out;
});

Object.keys(stats).length ? ok(`stats populated (${Object.keys(stats).join(', ')})`) : fail('no stats rendered');
stats.model === 'mediapipe-holistic' ? ok('model id reported on every frame') : fail(`model id was ${stats.model}`);
stats.schema === 'v1' ? ok('schema version reported') : fail(`schema was ${stats.schema}`);
if (stats.passes) ok(`inference ran (passes=${stats.passes}, frame=${stats.frame})`);
if (stats.rotation) ok(`orientation reported: ${stats.rotation}`);

// The whole point of the harness. A clip with a person in it MUST yield
// landmarks, a skeleton, and table rows -- anything less is a broken page.
const found = String(stats.parts ?? '');
found.includes('body') ? ok(`body landmarks found (${found})`) : fail(`no body landmarks: "${found}"`);
Number(stats.points) >= 33 ? ok(`${stats.points} points reported`) : fail(`only ${stats.points} points`);

const rows = await page.$$eval('#table tbody tr', (trs) => trs.length);
rows >= 33 ? ok(`landmark table populated (${rows} rows)`) : fail(`table has ${rows} rows`);

// The overlay must actually have ink on it -- the canvas threw silently once.
const painted = await page.evaluate(() => {
  const c = document.getElementById('overlay');
  const ctx = c.getContext('2d');
  const d = ctx.getImageData(0, 0, c.width, c.height).data;
  let on = 0;
  for (let i = 3; i < d.length; i += 4) if (d[i] > 8) on++;
  return on;
});
painted > 500 ? ok(`overlay painted (${painted} px)`) : fail(`overlay is blank (${painted} px drawn)`);

// --- canvas is actually being drawn into -----------------------------------
const canvasOk = await page.evaluate(() => {
  const c = document.getElementById('overlay');
  return c.width > 0 && c.height > 0;
});
canvasOk ? ok('overlay canvas sized to its element') : fail('overlay canvas has no backing store');

// --- pixel transform vs coordinate transform -------------------------------
// Only against a local checkout: tests/ is deliberately not deployed, so this
// page does not exist on the live site.
if (!process.env.URL) {
  const tp = await browser.newPage();
  await tp.goto(URL_.replace(/index\.html$/, 'tests/transform.html'));
  await tp.waitForFunction(() => window.TRANSFORM_READY, null, { timeout: 20_000 });
  const t = await tp.evaluate(() => window.TRANSFORM);
  t.failures.length
    ? fail(`drawRotated and rotatePoint disagree:\n    ${t.failures.join('\n    ')}`)
    : ok(`pixel and coordinate rotations agree (${t.checks} checks)`);
  await tp.close();
} else {
  console.log('  skip  transform agreement (tests/ is not deployed)');
}

// --- no errors -------------------------------------------------------------
// MediaPipe logs INFO lines to console.error on some builds; only fail on ours.
if (missing.length) console.log('  404s:', missing.join('\n        '));
const real = errors.filter((e) => !/TensorFlow Lite|XNNPACK|Created TensorFlow|GL version|feedback loop/i.test(e));
real.length ? fail(`console errors:\n    ${real.join('\n    ')}`) : ok('no unexpected console errors');

await browser.close();
shutdown();
console.log(process.exitCode ? '\nE2E FAILED' : '\nE2E PASSED');
